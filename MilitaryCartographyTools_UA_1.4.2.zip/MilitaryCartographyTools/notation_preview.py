"""Visible notation modes and read-only live previews of native QGIS attribute forms."""
import re
from qgis.core import (
    QgsSettings,QgsProject,QgsVectorLayer,QgsField,QgsFeature,QgsGeometry,QgsPointXY,
    QgsRectangle,QgsMapSettings,QgsMapRendererCustomPainterJob,QgsWkbTypes,Qgis,
    QgsMarkerSymbol,QgsSvgMarkerSymbolLayer,QgsSingleSymbolRenderer,QgsLayoutItemLabel,
    QgsExpressionContext,QgsExpressionContextUtils,
)
from qgis.gui import QgsAttributeForm,QgsEditorWidgetWrapper
from qgis.PyQt import sip
from qgis.PyQt.QtCore import QObject,QEvent,QTimer,Qt,QSize,QMetaType
from qgis.PyQt.QtGui import QColor,QPainter,QImage,QPixmap,QBitmap,QRegion,QPen
from qgis.PyQt.QtWidgets import (
    QApplication,QWidget,QLabel,QVBoxLayout,QHBoxLayout,QComboBox,QCheckBox,
    QSpinBox,QSizePolicy,QSplitter,QDialog,QDialogButtonBox,QLineEdit,
)

SETTING='MilitaryCartographyTools/symbol_source'
MODE_PROPERTY='MilitaryCartographyTools/notation_mode'
MODES={'nato':'НАТО — MIL-STD / APP-6','vkdp':'Українська — ВКДП','png':'Мої зображення PNG','zones':'Довільні зони'}

def alive(obj):
    return obj is not None and not sip.isdeleted(obj)

def form_token(form):
    return int(sip.unwrapinstance(form))

def as_form(widget):
    if isinstance(widget,QgsAttributeForm): return widget
    if isinstance(widget,QWidget) and widget.inherits('QgsAttributeForm'):
        return sip.cast(widget,QgsAttributeForm)
    return None

def layer_mode(layer):
    if layer is None: return None
    if layer.customProperty('MilitaryCartographyTools/free_zones',False): return 'zones'
    if layer.customProperty('MilitaryCartographyTools/ukrainian_native',False): return 'vkdp'
    flag=layer.customProperty('MilitaryCartographyTools/vkdp_profile','')
    if flag in ('points','lines','areas'): return 'vkdp'
    if bool(layer.customProperty('MilitaryCartographyTools/user_png_layer',False)): return 'png'
    fields={field.name() for field in layer.fields()}
    if 'affiliation' in fields and 'unique_designation' in fields and bool(fields & {'entity','measure_type'}):
        return 'nato'
    return None

def record_modes(layers):
    from .field_dependencies import configure
    for layer in layers:
        if isinstance(layer,QgsVectorLayer):
            mode=layer_mode(layer)
            if mode and layer.customProperty(MODE_PROPERTY,'')!=mode: layer.setCustomProperty(MODE_PROPERTY,mode)
            if mode: configure(layer)
            if mode in ('png','vkdp'):
                # Update display metadata of layers created by earlier versions.
                if layer.name()=='Ігрові знаки — мої PNG': layer.setName('Умовні знаки — мої PNG')
                for index in range(len(layer.fields())):
                    if layer.attributeAlias(index)=='Ігрова примітка': layer.setFieldAlias(index,'Примітка')

def normalize_layout_labels(*args):
    for layout in QgsProject.instance().layoutManager().layouts():
        if not hasattr(layout,'items'): continue
        previous='Умовні позначення — ігрова карта'
        if layout.name().startswith(previous):
            base=layout.name().replace(previous,'Умовні позначення — ВКДП',1); name=base; index=2
            while QgsProject.instance().layoutManager().layoutByName(name) not in (None,layout):
                name=base+' '+str(index); index+=1
            layout.setName(name)
        for item in layout.items():
            if isinstance(item,QgsLayoutItemLabel) and item.text()=='ІГРОВА КАРТА': item.setText('ВКДП 5(3)-00(01).02')

def mode_caption(layer):
    mode=layer_mode(layer)
    caption=MODES.get(mode,'Оформлення об’єкта')
    if mode=='nato':
        edition=re.search(r'2525[DE]/6[DE]',layer.name())
        if edition: caption+=' · '+edition[0]
    return caption

def _extent(geometry,crs):
    bbox=geometry.boundingBox()
    if geometry.type()==Qgis.GeometryType.Point or max(bbox.width(),bbox.height())<=0:
        centre=bbox.center(); span=0.005 if crs.isGeographic() else 100
        return QgsRectangle(centre.x()-span,centre.y()-span,centre.x()+span,centre.y()+span)
    margin=max(bbox.width(),bbox.height())*0.35
    return QgsRectangle(bbox.xMinimum()-margin,bbox.yMinimum()-margin,bbox.xMaximum()+margin,bbox.yMaximum()+margin)

def _sample_geometry(layer):
    span=0.005 if layer.crs().isGeographic() else 100
    kind=layer.geometryType()
    if kind==Qgis.GeometryType.Line:
        return QgsGeometry.fromPolylineXY([QgsPointXY(-span,0),QgsPointXY(0,span/3),QgsPointXY(span,0)])
    if kind==Qgis.GeometryType.Polygon:
        return QgsGeometry.fromPolygonXY([[QgsPointXY(-span,-span/2),QgsPointXY(span,-span/2),QgsPointXY(span,span/2),QgsPointXY(-span,span/2),QgsPointXY(-span,-span/2)]])
    return QgsGeometry.fromPointXY(QgsPointXY(0,0))

def map_context(settings,layer):
    context=QgsExpressionContext()
    context.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(layer))
    context.appendScope(QgsExpressionContextUtils.mapSettingsScope(settings))
    return context

class LivePreview(QWidget):
    """Render one private memory feature using the source layer's actual renderer."""
    def __init__(self,parent=None):
        super().__init__(parent)
        self.setObjectName('mctLiveSymbolPreview')
        self.setMinimumWidth(330)
        self.source=None; self.snapshot=None; self.memory=None; self.last_image=None
        self.render_count=0; self.last_attributes=[]; self.last_error=''
        self.title=QLabel('Попередній перегляд')
        self.title.setStyleSheet('font-weight:600;font-size:14px;')
        self.badge=QLabel(); self.badge.setWordWrap(True)
        self.badge.setStyleSheet('color:#345b47;')
        self.image=QLabel('Заповніть параметри знака')
        self.image.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.image.setMinimumSize(300,240)
        self.image.setSizePolicy(QSizePolicy.Policy.Ignored,QSizePolicy.Policy.Expanding)
        self.image.setStyleSheet('background:white;border:1px solid #ccd5cf;')
        self.zoom=QSpinBox(); self.zoom.setRange(50,400); self.zoom.setSingleStep(25); self.zoom.setValue(175); self.zoom.setSuffix(' %')
        self.anchor=QCheckBox('Показати точку прив’язки'); self.anchor.setChecked(True)
        self.description=QLabel(); self.description.setWordWrap(True)
        self.description.setStyleSheet('color:#4b5952;')
        controls=QHBoxLayout(); controls.addWidget(QLabel('Збільшення:')); controls.addWidget(self.zoom); controls.addStretch()
        layout=QVBoxLayout(self); layout.addWidget(self.title); layout.addWidget(self.badge)
        layout.addWidget(self.image,1); layout.addLayout(controls); layout.addWidget(self.anchor); layout.addWidget(self.description)
        self.timer=QTimer(self); self.timer.setSingleShot(True); self.timer.setInterval(130); self.timer.timeout.connect(self.refresh)
        self.zoom.valueChanged.connect(self.schedule); self.anchor.toggled.connect(self.schedule)

    def schedule(self,*args):
        self.timer.start()

    def resizeEvent(self,event):
        super().resizeEvent(event)
        if hasattr(self,'timer'): self.schedule()

    def set_feature(self,layer,feature):
        self.source=layer; self.snapshot=QgsFeature(feature)
        self.badge.setText(mode_caption(layer)); self.schedule()

    def _prepare(self):
        layer=self.source
        if not alive(layer) or self.snapshot is None: return False
        if self.memory is None or self.memory.customProperty('preview_source_id','')!=layer.id():
            name=QgsWkbTypes.displayString(layer.wkbType())
            if name in ('Unknown','NoGeometry',''): name='Point'
            self.memory=QgsVectorLayer(name+'?crs='+layer.crs().authid(),'Перегляд — тимчасова копія','memory')
            self.memory.setCrs(layer.crs())
            self.memory.dataProvider().addAttributes([QgsField(field) for field in layer.fields()]); self.memory.updateFields()
            for key in layer.customPropertyKeys(): self.memory.setCustomProperty(key,layer.customProperty(key))
            self.memory.setCustomProperty('preview_source_id',layer.id())
        if layer.renderer() is None: raise ValueError('Для шару не задано оформлення.')
        self.memory.setRenderer(layer.renderer().clone())
        if layer.labeling() is not None: self.memory.setLabeling(layer.labeling().clone())
        self.memory.setLabelsEnabled(layer.labelsEnabled())
        feature=QgsFeature(self.memory.fields()); feature.setAttributes(self.snapshot.attributes())
        geometry=QgsGeometry(self.snapshot.geometry())
        self.using_sample=geometry.isNull() or geometry.isEmpty()
        if self.using_sample: geometry=_sample_geometry(layer)
        feature.setGeometry(geometry)
        self.memory.dataProvider().truncate()
        if not self.memory.dataProvider().addFeatures([feature])[0]: raise ValueError('Не вдалося побудувати копію об’єкта для перегляду.')
        self.memory.updateExtents(); self.geometry=geometry
        return True

    def refresh(self):
        self.timer.stop()
        try:
            if not self._prepare(): return
            size=QSize(max(300,min(self.image.width()-6,900)),max(240,min(self.image.height()-6,720)))
            dpi=96*self.zoom.value()/100
            fitted=False
            for attempt in range(5):
                settings=QgsMapSettings(); settings.setLayers([self.memory]); settings.setDestinationCrs(self.source.crs())
                settings.setOutputSize(size); settings.setOutputDpi(dpi)
                settings.setExtent(_extent(self.geometry,self.source.crs())); settings.setBackgroundColor(QColor(255,255,255,0))
                settings.setExpressionContext(map_context(settings,self.memory))
                image=QImage(size,QImage.Format.Format_ARGB32_Premultiplied); image.fill(Qt.GlobalColor.transparent)
                painter=QPainter(image)
                job=QgsMapRendererCustomPainterJob(settings,painter)
                try: job.renderSynchronously()
                finally: painter.end()
                if job.errors(): raise ValueError('; '.join(error.message for error in job.errors())[:400])
                bounds=QRegion(QBitmap.fromImage(image.createAlphaMask())).boundingRect()
                clipped=not bounds.isEmpty() and (bounds.left()<8 or bounds.top()<8 or bounds.right()>size.width()-9 or bounds.bottom()>size.height()-9)
                if not clipped or dpi<=48: break
                dpi=max(48,dpi*0.72); fitted=True
            output=QImage(size,QImage.Format.Format_ARGB32_Premultiplied); output.fill(QColor('white'))
            painter=QPainter(output); painter.drawImage(0,0,image)
            if self.anchor.isChecked() and self.geometry.type()==Qgis.GeometryType.Point:
                point=self.geometry.asPoint() if not self.geometry.isMultipart() else self.geometry.asMultiPoint()[0]
                position=settings.mapToPixel().transform(point.x(),point.y())
                pen=QPen(QColor('#9ca9a0')); pen.setWidthF(0.8); painter.setPen(pen)
                x,y=int(position.x()),int(position.y()); painter.drawLine(x-6,y,x+6,y); painter.drawLine(x,y-6,x,y+6)
            painter.end()
            self.last_image=output; self.last_attributes=list(self.snapshot.attributes()); self.last_error=''; self.render_count+=1
            self.image.setPixmap(QPixmap.fromImage(output))
            values={field.name():self.snapshot[index] for index,field in enumerate(self.source.fields())}
            rotation=values.get('rotation',0)
            notes=[]
            if 'frame_mm' in values: notes.append('Рамка: '+str(values['frame_mm'])+' мм')
            elif 'size_mm' in values: notes.append('Розмір: '+str(values['size_mm'])+' мм')
            if 'rotation' in values: notes.append('Поворот: '+str(rotation)+'°')
            if 'scale' in values: notes.append('Масштаб знака: '+str(values['scale'])+' %')
            if fitted: notes.append('Зображення вписано у вікно')
            if self.using_sample and self.geometry.type()!=Qgis.GeometryType.Point: notes.append('Умовна геометрія для перегляду')
            self.description.setText(' · '.join(notes)+'\nПерегляд не зберігає зміни об’єкта.')
        except Exception as error:
            self.last_error=str(error); self.image.clear(); self.image.setText('Не вдалося показати знак')
            self.description.setText(self.last_error)

class LayoutPreview(LivePreview):
    """Preview the same SVG selected for insertion into a NATO print layout."""
    def __init__(self,dialog):
        super().__init__(dialog)
        self.dialog=dialog
        self.layer=QgsVectorLayer('Point?crs=EPSG:3857','НАТО — вставлення в макет','memory')
        self.layer.dataProvider().addAttributes([
            QgsField('affiliation',QMetaType.Type.QString),QgsField('entity',QMetaType.Type.QString),
            QgsField('unique_designation',QMetaType.Type.QString),QgsField('size_mm',QMetaType.Type.Double)])
        self.layer.updateFields()
        for combo in [dialog.affiliation_combo,dialog.symbol_set_combo,dialog.entity_combo]:
            combo.currentIndexChanged.connect(self.update_selection)
        self.update_selection()

    def update_selection(self,*args):
        if not self.dialog.entity_combo.currentData(): return
        try:
            from .military_symbology.symbol_engine import render_symbol_base64_path
            path=self.dialog.picture_path()
            from .vkdp_symbols import using_profile
            self.layer.setCustomProperty('MilitaryCartographyTools/ukrainian_native',using_profile())
            symbol=QgsMarkerSymbol(); symbol.changeSymbolLayer(0,QgsSvgMarkerSymbolLayer(path,20))
            self.layer.setRenderer(QgsSingleSymbolRenderer(symbol))
            feature=QgsFeature(self.layer.fields())
            feature.setAttributes([self.dialog.affiliation_combo.currentData(),self.dialog.entity_combo.currentData(),'',20.0])
            feature.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(0,0)))
            self.set_feature(self.layer,feature)
        except Exception as error:
            self.last_error=str(error); self.description.setText(self.last_error)


class FormController(QObject):
    def __init__(self,form,owner):
        super().__init__(form)
        self.form=form; self.owner=owner; self.splitter=None; self.old_parent=None; self.parent_layout=None; self.window=None
        self.panel=LivePreview()
        if layer_mode(form.layer())=='zones':
            from .free_zones import prepare_form
            prepare_form(form)
        form.setProperty('mct_preview_attached',True)
        for box in form.window().findChildren(QDialogButtonBox):
            for standard,caption in [(QDialogButtonBox.StandardButton.Ok,'Гаразд'),
                (QDialogButtonBox.StandardButton.Cancel,'Скасувати'),
                (QDialogButtonBox.StandardButton.Apply,'Застосувати')]:
                button=box.button(standard)
                if button is not None:
                    if standard==QDialogButtonBox.StandardButton.Ok and button.text().replace('&','') not in ('OK','Ok','ОК','Гаразд'): continue
                    button.setText(caption)
        self.timer=QTimer(self); self.timer.setSingleShot(True); self.timer.setInterval(100); self.timer.timeout.connect(self.update)
        self.connections=[]; self.clear_connections=[]
        for signal_name in ['widgetValueChanged','featureChanged']:
            signal=getattr(form,signal_name,None)
            if signal is not None:
                signal.connect(self.schedule); self.connections.append(signal)
        # Completer editors expose a valid selection before the form commits its cached value.
        for editor in form.findChildren(QLineEdit):
            completer=editor.completer()
            if completer is not None:
                completer.setFilterMode(Qt.MatchFlag.MatchContains); completer.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
                wrapper=QgsEditorWidgetWrapper.fromWidget(editor)
                if wrapper is not None:
                    setup=form.layer().editorWidgetSetup(wrapper.fieldIdx())
                    if wrapper.field().name()=='ua_png_key' and setup.type()=='ValueRelation' and setup.config().get('AllowNull',False):
                        callback=lambda text='',w=wrapper:self.commit_optional_clear(w,text)
                        editor.textEdited.connect(callback); self.clear_connections.append((editor.textEdited,callback))
                        cleared=getattr(editor,'cleared',None)
                        if cleared is not None:
                            cleared.connect(callback); self.clear_connections.append((cleared,callback))
            editor.textChanged.connect(self.schedule); self.connections.append(editor.textChanged)
        try:
            self._embed()
            form.destroyed.connect(self.panel.deleteLater)
            self.update()
        except Exception:
            self.detach()
            raise

    def _embed(self):
        form=self.form; parent=form.parentWidget()
        window=form.window()
        if isinstance(window,QDialog) and form.minimumSizeHint().width()+390>window.screen().availableGeometry().width():
            self._floating(); return
        while parent is not None:
            layout=parent.layout()
            if layout is not None:
                split=QSplitter(Qt.Orientation.Horizontal,parent)
                item=layout.replaceWidget(form,split,Qt.FindChildOption.FindChildrenRecursively)
                if item is not None:
                    self.old_parent=form.parentWidget(); self.parent_layout=layout; self.splitter=split
                    split.setChildrenCollapsible(False); split.addWidget(form); split.addWidget(self.panel)
                    split.setStretchFactor(0,3); split.setStretchFactor(1,2); split.setSizes([560,380])
                    window=split.window()
                    if isinstance(window,QDialog):
                        available=window.screen().availableGeometry()
                        window.resize(min(max(window.width(),960),available.width()-30),min(max(window.height(),620),available.height()-40))
                    form.show(); self.panel.show(); return
                split.deleteLater()
            parent=parent.parentWidget()
        # Embedded table editors without a replaceable form layout get a companion window.
        self._floating()

    def _floating(self):
        self.window=QDialog(self.form.window(),Qt.WindowType.Tool); self.window.setWindowTitle('Перегляд умовного знака')
        layout=QVBoxLayout(self.window); layout.addWidget(self.panel); self.window.resize(410,520); self.window.show()

    def schedule(self,*args): self.timer.start()

    def commit_optional_clear(self,wrapper,text=''):
        # Clearing an optional completer otherwise leaves its old key in the
        # QGIS form buffer, even while the preview already shows a vector.
        # Select the real empty-key (vector) catalogue row. A bare invalid
        # QVariant from an empty completer is ignored by QGIS when saving.
        # No provider write occurs before the normal form Save.
        if str(text).strip() or not alive(self.form) or not alive(wrapper) or getattr(self,'_clearing_png',False): return
        if not self.form.editable() or getattr(self.form.mode(),'name','') not in ('SingleEditMode','AddFeatureMode'): return
        config=self.form.layer().editorWidgetSetup(wrapper.fieldIdx()).config()
        lookup=QgsProject.instance().mapLayer(config.get('Layer',''))
        if lookup is None: return
        caption=next((str(row[config['Value']]) for row in lookup.getFeatures() if row[config['Key']]==''),None)
        editor=wrapper.widget()
        if caption is None or not isinstance(editor,QLineEdit) or editor.completer() is None: return
        self._clearing_png=True
        try:
            editor.setText(caption); editor.completer().activated[str].emit(caption); editor.selectAll()
        finally: self._clearing_png=False

    def update(self):
        self.timer.stop()
        if not alive(self.form): return
        if not self.form.isVisible():
            if alive(self.window): self.window.hide()
            return
        if alive(self.window) and not self.window.isVisible(): self.window.show()
        if 'MultiEdit' in getattr(self.form.mode(),'name',''):
            self.panel.image.clear(); self.panel.image.setText('Для точного перегляду відкрийте один об’єкт.'); return
        if 'Search' in getattr(self.form.mode(),'name',''):
            self.panel.image.clear(); self.panel.image.setText('Перегляд доступний у формі одного об’єкта.'); return
        feature=self.form.currentFormFeature()
        seen=set(); wrappers=[]
        for widget in self.form.findChildren(QWidget):
            wrapper=QgsEditorWidgetWrapper.fromWidget(widget)
            if wrapper is None: continue
            token=int(sip.unwrapinstance(wrapper))
            if token in seen: continue
            seen.add(token); wrappers.append(wrapper); index=feature.fields().indexFromName(wrapper.field().name())
            if index>=0:
                value=wrapper.value()
                feature.setAttribute(index,value)
        from .field_dependencies import refresh_form
        refresh_form(self.form,feature,wrappers)
        self.panel.set_feature(self.form.layer(),feature)

    def detach(self):
        self.timer.stop(); self.panel.timer.stop()
        if alive(self.form):
            for signal,callback in self.clear_connections:
                try: signal.disconnect(callback)
                except (TypeError,RuntimeError): pass
            for signal in self.connections:
                try: signal.disconnect(self.schedule)
                except (TypeError,RuntimeError): pass
            self.form.setProperty('mct_preview_attached',False)
            if alive(self.splitter) and alive(self.old_parent):
                self.form.setParent(self.old_parent)
                self.parent_layout.replaceWidget(self.splitter,self.form,Qt.FindChildOption.FindChildrenRecursively)
                self.form.show(); self.splitter.deleteLater()
        if alive(self.window): self.window.close(); self.window.deleteLater()
        if alive(self.panel): self.panel.deleteLater()
        self.deleteLater()

class PreviewFilter(QObject):
    def __init__(self,parent=None):
        super().__init__(parent); self.controllers={}; self.pending=set(); self.active=True

    def attach(self,form,token=None):
        if token is not None: self.pending.discard(token)
        if not self.active or not alive(form) or not form.isVisible(): return
        token=form_token(form); self.pending.discard(token)
        if form.property('mct_preview_attached') or layer_mode(form.layer()) is None: return
        try:
            controller=FormController(form,self); self.controllers[token]=controller
            form.destroyed.connect(lambda *args,t=token:self.controllers.pop(t,None))
        except Exception as error:
            if alive(form): form.setProperty('mct_preview_attached',False)
            from qgis.core import QgsMessageLog
            QgsMessageLog.logMessage('Перегляд форми: '+str(error),'Military Cartography Tools')

    def eventFilter(self,obj,event):
        if not self.active or event.type() not in (QEvent.Type.Show,QEvent.Type.Hide): return False
        form=as_form(obj)
        if form is None: return False
        if event.type()==QEvent.Type.Hide:
            controller=self.controllers.get(form_token(form))
            if controller is not None and alive(controller.window): controller.window.hide()
        if event.type()==QEvent.Type.Show:
            token=form_token(form)
            if token not in self.pending and not form.property('mct_preview_attached'):
                self.pending.add(token); QTimer.singleShot(0,lambda form=form,token=token:self.attach(form,token))
            elif token in self.controllers: self.controllers[token].schedule()
        return False

    def stop(self):
        self.active=False
        for controller in list(self.controllers.values()):
            if alive(controller): controller.detach()
        self.controllers.clear()
        self.pending.clear()

def install(plugin):
    settings=QgsSettings(); current=settings.value(SETTING,'vkdp')
    systems=('nato','vkdp')
    if current not in systems: current='vkdp'; settings.setValue(SETTING,current)
    holder=QWidget(plugin.toolbar); holder.setObjectName('mctNotationModeSelector')
    row=QHBoxLayout(holder); row.setContentsMargins(7,0,5,0); row.addWidget(QLabel('Система для нових шарів:'))
    combo=QComboBox(holder); combo.setObjectName('mctNotationModeCombo'); combo.setMinimumWidth(240)
    for code in systems: combo.addItem(MODES[code],code)
    combo.setCurrentIndex(max(0,combo.findData(current)))
    combo.setToolTip('Змінюється система позначень для нових шарів. Категорії меню, нанесення, редагування й збереження залишаються штатними. Наявні шари зберігають свою систему. PNG — окрема необов’язкова бібліотека.')
    row.addWidget(combo); plugin.toolbar.addSeparator(); plugin.toolbar.addWidget(holder)
    host=plugin.group_menus['nato_symbols']; source=None
    for action in host.actions():
        child=action.menu()
        if child is not None and child.title() in ('Джерело нових знаків','Режим позначень'): source=child; break
    actions={}
    if source is not None:
        source.setTitle('Режим позначень')
        for action in source.actions():
            text=action.text()
            code='vkdp' if text.startswith('ВКДП') else 'nato' if text.startswith('Стандартні') else 'png' if text.startswith('Мої PNG') else None
            if code=='png':
                if action.actionGroup() is not None: action.actionGroup().removeAction(action)
                source.removeAction(action); continue
            if code:
                actions[code]=action; action.setText(MODES[code]); action.setData(code)
    def sync(code,write=True):
        if code not in systems: return
        if write: settings.setValue(SETTING,code)
        combo.blockSignals(True); combo.setCurrentIndex(combo.findData(code)); combo.blockSignals(False)
        for key,action in actions.items():
            action.setChecked(key==code)
    combo.currentIndexChanged.connect(lambda index:sync(combo.itemData(index)))
    for code,action in actions.items(): action.triggered.connect(lambda checked=False,k=code:sync(k))
    sync(current,False)
    plugin._notation_combo=combo; plugin._notation_mode_widget=holder
    preview_filter=PreviewFilter(plugin.toolbar); QApplication.instance().installEventFilter(preview_filter)
    plugin._notation_preview_filter=preview_filter
    record_modes(list(QgsProject.instance().mapLayers().values()))
    normalize_layout_labels()
    QgsProject.instance().layersAdded.connect(record_modes)
    QgsProject.instance().readProject.connect(normalize_layout_labels)
    for widget in QApplication.allWidgets():
        form=as_form(widget)
        if form is not None and form.isVisible(): preview_filter.attach(form)

def uninstall(plugin):
    preview_filter=getattr(plugin,'_notation_preview_filter',None)
    if alive(preview_filter):
        QApplication.instance().removeEventFilter(preview_filter); preview_filter.stop()
    try: QgsProject.instance().layersAdded.disconnect(record_modes)
    except (TypeError,RuntimeError): pass
    try: QgsProject.instance().readProject.disconnect(normalize_layout_labels)
    except (TypeError,RuntimeError): pass
