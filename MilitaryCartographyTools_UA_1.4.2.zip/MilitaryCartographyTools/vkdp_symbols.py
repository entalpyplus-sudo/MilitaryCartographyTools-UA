"""Editable cartographic profile based on VKDP 5(3)-00(01).02 (2020), sections 2.2/5.2/5.5."""
import hashlib,json,os,re,threading,uuid
from pathlib import Path
from xml.etree import ElementTree as ET
from qgis.core import (
    QgsApplication,QgsExpression,QgsFeatureRequest,QgsVectorLayer,QgsField,QgsDefaultValue,
    QgsEditorWidgetSetup,QgsSvgMarkerSymbolLayer,QgsMarkerSymbol,QgsSymbolLayer,QgsProperty,
    QgsSingleSymbolRenderer,QgsProject,QgsVectorFileWriter,QgsMapLayerStyle,
    QgsLineSymbol,QgsFillSymbol,QgsTextFormat,QgsPalLayerSettings,QgsVectorLayerSimpleLabeling,QgsGeometry,QgsPointXY,
    qgsfunction,Qgis,QgsSettings,
)
from qgis.PyQt.QtCore import QMetaType,Qt,QSize
from qgis.PyQt.QtGui import QColor,QPixmap,QPainter,QFont,QAction,QIcon
from qgis.PyQt.QtSvg import QSvgRenderer
from qgis.PyQt.QtWidgets import (
    QDialog,QWidget,QLabel,QLineEdit,QComboBox,QCheckBox,QDoubleSpinBox,QFormLayout,
    QVBoxLayout,QHBoxLayout,QTabWidget,QPushButton,QFileDialog,QMenu,
)
from .military_symbology.sidc import build_sidc,ENTITIES,MODIFIERS
from .military_symbology.symbol_engine import QJSEngine,_VENDOR_JS_PATH
from .localization_uk import entity_display_label,tr

ROOT=Path(__file__).resolve().parent
CACHE=Path(QgsApplication.qgisSettingsDirPath())/'MilitaryCartographyTools/vkdp_svg'
FLAG='MilitaryCartographyTools/vkdp_profile'
NS='http://www.w3.org/2000/svg'
ET.register_namespace('',NS)
_thread=threading.local()
_lock=threading.Lock()
_cache={}
_js_source=None
SIDES={'friend':'Свої','assumed_friend':'Очікувано свої','hostile':'Противник',
    'suspect':'Підозрілі','neutral':'Нейтральні','unknown':'Невідомі','pending':'Невизначені'}
IDENTITIES={'pending':'0','unknown':'1','assumed_friend':'2','friend':'3','neutral':'4','suspect':'5','hostile':'6'}
FILLS={'friend':'rgb(128,224,255)','assumed_friend':'rgb(128,224,255)',
    'hostile':'rgb(255,128,128)','suspect':'rgb(255,128,128)',
    'neutral':'rgb(170,255,170)','unknown':'rgb(255,255,128)','pending':'rgb(255,255,128)'}
DOMAINS={'ground_unit':'Підрозділи Сухопутних військ','land_equipment':'Озброєння та техніка',
    'land_installation':'Об’єкти інфраструктури','air':'Авіація','sea_surface':'Надводні об’єкти',
    'subsurface':'Підводні об’єкти','space':'Космічні системи','activities':'Діяльність'}
ECHELONS={'unspecified':'Не визначено','team_crew':'Група / екіпаж / розрахунок','squad':'Відділення',
    'section':'Секція / ланка','platoon':'Взвод','company':'Рота / батарея','battalion':'Батальйон / дивізіон',
    'regiment':'Полк','brigade':'Бригада','division':'Дивізія','corps':'Корпус / ОТУ / МК / КМП',
    'army':'ОК / ОУВ / ПвК / армія','army_group':'Види та роди ЗС України / група армій',
    'theater':'Збройні Сили України','command':'Командування (++)'}
STATES={'present':'Фактичне / підтверджене','planned':'Планове / імовірне'}
EFFECTS={'normal':'Без перекреслення','destroyed':'Знищено','damaged':'Пошкоджено / подавлено','planned_destroyed':'Планується знищити'}
REF='ВКДП 5(3)-00(01).02, 2020: пп. 2.2.9–2.2.12, 5.2; табл. 6 і 13, рис. 11'
FIELDS=[
 ('domain','Сфера',str,'ground_unit'),('entity','Тип знака',str,'mechanized_infantry'),
 ('side','Належність',str,'friend'),('echelon','Організаційний рівень',str,'platoon'),
 ('state','Стан',str,'present'),('hq','Пункт управління / штаб',bool,False),
 ('command_label','Напис під пунктом управління',str,''),
 ('designation','T — унікальне позначення',str,''),('higher','M — вище формування',str,''),
 ('reinforcement','F — посилення / послаблення',str,''),('staff','G — штабний коментар',str,''),
 ('info','H — додаткова інформація',str,''),('dtg','W — дата й час',str,''),
 ('source','Джерело інформації',str,''),('uncertain','Інформація потребує перевірки',bool,False),
 ('modifier1','Модифікатор сектора 1',str,''),('modifier2','Модифікатор сектора 2',str,''),
 ('effect','Стан ураження',str,'normal'),('effect_side','Ким завдано ураження',str,'friend'),
 ('monochrome','Чорно-білий вигляд',bool,False),('frame_mm','Ширина рамки (мм)',float,14.0),
 ('rotation','Поворот (°)',float,0.0),('notes','Примітка',str,''),
]
DEFAULTS={key:value for key,_,_,value in FIELDS}
VISUAL=[key for key,_,_,_ in FIELDS if key not in ('frame_mm','rotation','notes')]
PRESETS=[
 ('Власний знак',{}),
 ('КСП танкової роти — зразок с. 125',{'entity':'armor','echelon':'company','hq':True,'command_label':'КСП','designation':'1','higher':'3/53'}),
 ('КСП танкового взводу — зразок с. 125',{'entity':'armor','echelon':'platoon','hq':True,'command_label':'КСП','designation':'3','higher':'1/3/53'}),
 ('Механізована бригада — зразок с. 125',{'entity':'mechanized_infantry','echelon':'brigade'}),
 ('Гірсько-піхотна бригада — зразок с. 125',{'entity':'infantry','echelon':'brigade','modifier2':'mountain'}),
 ('Ескадрилья армійської авіації — зразок с. 125',{'entity':'aviation_rotary_wing','echelon':'battalion','designation':'2','higher':'1'}),
 ('Мотопіхотний батальйон — зразок с. 126',{'entity':'motorized_infantry','echelon':'battalion'}),
 ('Танковий батальйон — зразок с. 127',{'entity':'armor','echelon':'battalion'}),
]

def using_profile():
    return QgsSettings().value('MilitaryCartographyTools/symbol_source','vkdp')=='vkdp'

def normalize(values):
    out=dict(DEFAULTS)
    for key,_,kind,default in FIELDS:
        value=values.get(key,default)
        if value is None or str(value)=='NULL': value=default
        out[key]=(bool(value) if kind is bool else float(value or default) if kind is float else str(value))
    if out['domain'] not in DOMAINS: out['domain']='ground_unit'
    if out['entity'] not in ENTITIES[out['domain']]: out['entity']=next(iter(ENTITIES[out['domain']]))
    if out['side'] not in SIDES: out['side']='friend'
    if out['echelon'] not in ECHELONS: out['echelon']='unspecified'
    if out['state'] not in STATES: out['state']='present'
    if out['effect'] not in EFFECTS: out['effect']='normal'
    if out['effect_side'] not in ('friend','hostile'): out['effect_side']='friend'
    if out['domain']!='ground_unit': out.update({'hq':False,'echelon':'unspecified','command_label':''})
    from .field_dependencies import LOWER_ECHELONS
    if out['echelon'] not in LOWER_ECHELONS: out['reinforcement']=''
    return out

def _engine():
    global _js_source
    if not hasattr(_thread,'engine'):
        if _js_source is None: _js_source=Path(_VENDOR_JS_PATH).read_text(encoding='utf-8')
        _thread.engine=QJSEngine()
        result=_thread.engine.evaluate(_js_source)
        if result.isError(): raise RuntimeError(result.toString())
    return _thread.engine

def compose(values):
    v=normalize(values)
    key=hashlib.sha256(json.dumps({k:v[k] for k in VISUAL},sort_keys=True,ensure_ascii=False).encode()).hexdigest()
    with _lock:
        if key in _cache and Path(_cache[key]['path']).is_file(): return _cache[key]
    basic_side=v['side'] if v['side'] in ('friend','hostile','neutral','unknown') else 'friend'
    hq=bool(v['hq']) and v['domain']=='ground_unit'
    sidc=build_sidc(affiliation=basic_side,entity=v['entity'],symbol_set=v['domain'],
        echelon=v['echelon'] if v['domain']=='ground_unit' else 'unspecified',
        headquarters=hq,status=v['state'],edition='2525D',
        sector1_modifier=v['modifier1'] or None,sector2_modifier=v['modifier2'] or None)
    sidc=sidc[:3]+IDENTITIES[v['side']]+sidc[4:]
    options={'size':100,'fontfamily':'Arial','fontSize':32,
        'uniqueDesignation':v['designation'],'higherFormation':v['higher'],
        'reinforcedReduced':v['reinforcement'],'staffComments':v['staff'],
        'additionalInformation':v['info'],'dtg':' '.join(x for x in [v['source'],v['dtg']] if x)}
    if v['monochrome']: options.update({'fill':False,'monoColor':'black'})
    script='JSON.stringify((function(){var s=new ms.Symbol('+json.dumps(sidc)+','+json.dumps(options)+');return {svg:s.asSVG(),anchor:s.getAnchor(),size:s.getSize(),metadata:s.getMetadata()};})())'
    result=_engine().evaluate(script)
    if result.isError(): raise RuntimeError(result.toString())
    raw=json.loads(result.toString())
    svg=ET.fromstring(raw['svg'])
    vx,vy,vw,vh=map(float,svg.attrib['viewBox'].split())
    size=raw['size']
    sx=vw/size['width']; sy=vh/size['height']
    ax=vx+raw['anchor']['x']*sx; ay=vy+raw['anchor']['y']*sy
    bbox=(raw['metadata'].get('baseGeometry') or {}).get('bbox') or {'x1':vx,'y1':vy,'x2':vx+vw,'y2':vy+vh}
    if bbox['x2']<=bbox['x1'] or bbox['y2']<=bbox['y1']: bbox={'x1':vx,'y1':vy,'x2':vx+vw,'y2':vy+vh}
    x1,y1,x2,y2=[bbox[k] for k in ['x1','y1','x2','y2']]
    frame_width=x2-x1
    # Table 6: explicit electronic fill colours; outlines and text remain black.
    for node in svg.iter():
        fill=node.attrib.get('fill','')
        if fill in FILLS.values() and not v['monochrome']: node.set('fill',FILLS[v['side']])
    def text(x,y,value,colour='black',anchor='middle'):
        node=ET.SubElement(svg,'{'+NS+'}text',{'x':str(x),'y':str(y),'font-family':'Arial',
            'font-size':'28','text-anchor':anchor,'fill':colour})
        node.text=value
        return node
    if hq and v['command_label']: text((x1+x2)/2,y2+30,v['command_label']).set('font-weight','bold')
    if v['uncertain']:
        text(x2+16,y1-8,'?','black' if v['monochrome'] else '#0000ff','start')
        right=max(vx+vw,x2+52); top=min(vy,y1-45)
        vw=right-vx; vh=vy+vh-top; vy=top
    if v['effect']!='normal':
        colour='black' if v['monochrome'] else '#ff0000' if v['effect_side']=='hostile' else '#0000ff'
        for index,(a,b,c,d) in enumerate([(x1-8,y1-8,x2+8,y2+8),(x1-8,y2+8,x2+8,y1-8)]):
            attrs={'x1':str(a),'y1':str(b),'x2':str(c),'y2':str(d),'stroke':colour,'stroke-width':'4'}
            if v['effect']=='planned_destroyed' or (v['effect']=='damaged' and index==1): attrs['stroke-dasharray']='9,6'
            ET.SubElement(svg,'{'+NS+'}line',attrs)
        left=min(vx,x1-12); top=min(vy,y1-12)
        right=max(vx+vw,x2+12); bottom=max(vy+vh,y2+12)
        vx,vy,vw,vh=left,top,right-left,bottom-top
    # Symmetric padding puts the actual map anchor at the SVG centre even with long labels.
    rx=max(ax-vx,vx+vw-ax,1); ry=max(ay-vy,vy+vh-ay,1)
    svg.set('viewBox',f'{ax-rx} {ay-ry} {2*rx} {2*ry}')
    svg.set('width',str(2*rx)); svg.set('height',str(2*ry))
    payload=ET.tostring(svg,encoding='utf-8',xml_declaration=True)
    CACHE.mkdir(parents=True,exist_ok=True)
    path=CACHE/(key+'.svg')
    temporary=path.with_suffix('.'+uuid.uuid4().hex+'.tmp')
    temporary.write_bytes(payload)
    os.replace(temporary,path)
    data={'path':str(path),'ratio':2*rx/frame_width,'svg':payload,'anchor':(ax,ay),
        'viewbox':(ax-rx,ay-ry,2*rx,2*ry),'frame':bbox,'sidc':sidc,'reference':REF}
    with _lock: _cache[key]=data
    return data

@qgsfunction(args='auto',group='ВКДП — умовні знаки')
def mct_vkdp_value(which,values,feature,parent):
    try: return compose(dict(values)).get(which)
    except Exception as error:
        parent.setEvalErrorString('ВКДП: '+str(error))
        return None

def value_map(labels): return QgsEditorWidgetSetup('ValueMap',{'map':{label:key for key,label in labels.items()}})

def modifier_labels(domain,sector):
    import importlib
    location={'ground_unit':('land_layer','_UNIT_'),'land_equipment':('land_layer','_EQUIPMENT_'),
        'land_installation':('land_layer','_INSTALLATION_'),'subsurface':('subsurface_layer','_SUBSURFACE_')}
    module,prefix=location.get(domain,(domain+'_layer','_'))
    try: labels=getattr(importlib.import_module('.military_symbology.'+module,__package__),prefix+'SECTOR'+str(sector)+'_LABELS',{})
    except ImportError: labels={}
    return {'':'(Немає)',**{key:labels.get(key,tr(key.replace('_',' ').title())) for key in MODIFIERS.get(domain,{}).get('sector'+str(sector),{})}}

def lookup_layer():
    project=QgsProject.instance()
    for layer in project.mapLayers().values():
        if layer.customProperty(FLAG,'')=='lookup': return layer
    home=project.homePath()
    path=(Path(home)/'data' if home else CACHE.parent)/'vkdp_catalog_v1.gpkg'
    if path.is_file():
        layer=QgsVectorLayer(str(path)+'|layername=vkdp_catalog','ВКДП — довідник типів','ogr')
    else:
        from qgis.core import QgsFeature
        memory=QgsVectorLayer('None','ВКДП — довідник типів','memory')
        memory.dataProvider().addAttributes([QgsField(key,QMetaType.Type.QString) for key in ['domain','kind','code','label']]); memory.updateFields()
        features=[]
        for domain in DOMAINS:
            vocabularies={'entity':{key:entity_display_label(key,domain,'2525D') for key in ENTITIES[domain]},
                'modifier1':modifier_labels(domain,1),'modifier2':modifier_labels(domain,2)}
            for kind,labels in vocabularies.items():
                for code,label in labels.items():
                    f=QgsFeature(memory.fields()); f.setAttributes([domain,kind,code,label]); features.append(f)
        memory.dataProvider().addFeatures(features)
        layer=persist(memory,path,'vkdp_catalog')
    if not layer.isValid(): raise RuntimeError('Не вдалося відкрити довідник типів ВКДП.')
    layer.setCustomProperty(FLAG,'lookup'); project.addMapLayer(layer,False)
    return layer

def apply_defaults(layer,values):
    for key,value in normalize(values).items():
        index=layer.fields().indexFromName(key)
        if index<0: continue
        expression='true' if value is True else 'false' if value is False else str(value) if isinstance(value,(int,float)) else QgsExpression.quotedString(value)
        layer.setDefaultValueDefinition(index,QgsDefaultValue(expression))

def build_point_layer(crs='EPSG:32636',preview=False):
    layer=QgsVectorLayer('Point?crs='+crs,'ВКДП — редаговані знаки','memory')
    types={str:QMetaType.Type.QString,bool:QMetaType.Type.Bool,float:QMetaType.Type.Double}
    layer.dataProvider().addAttributes([QgsField(key,types[kind]) for key,_,kind,_ in FIELDS])
    layer.updateFields()
    for index,(_,label,_,_) in enumerate(FIELDS): layer.setFieldAlias(index,label)
    for key,labels in [('domain',DOMAINS),('side',SIDES),('echelon',ECHELONS),('state',STATES),
        ('effect',EFFECTS),('effect_side',{'friend':'Свої','hostile':'Противник'})]:
        layer.setEditorWidgetSetup(layer.fields().indexFromName(key),value_map(labels))
    # Existing features can always be edited with the constructor, including domain-specific vocabularies.
    if not preview:
        lookup=lookup_layer()
        for field in ['entity','modifier1','modifier2']:
            layer.setEditorWidgetSetup(layer.fields().indexFromName(field),QgsEditorWidgetSetup('ValueRelation',{
                'Layer':lookup.id(),'Key':'code','Value':'label','AllowNull':False,'OrderByValue':True,
                'UseCompleter':True,'FilterExpression':'"domain" = current_value(\'domain\') AND "kind" = \''+field+'\'',
            }))
    for key in ['hq','monochrome','uncertain']:
        layer.setEditorWidgetSetup(layer.fields().indexFromName(key),QgsEditorWidgetSetup('CheckBox',{}))
    for key,minimum,maximum in [('frame_mm',4,60),('rotation',-360,360)]:
        layer.setEditorWidgetSetup(layer.fields().indexFromName(key),QgsEditorWidgetSetup('Range',{'Min':minimum,'Max':maximum,'Step':1,'Precision':1,'Style':'SpinBox'}))
    mapping='map('+','.join(QgsExpression.quotedString(key)+',"'+key+'"' for key in VISUAL)+')'
    base=compose(DEFAULTS)
    marker=QgsSvgMarkerSymbolLayer(base['path'])
    marker.setDataDefinedProperty(QgsSymbolLayer.Property.Name,QgsProperty.fromExpression("mct_vkdp_value('path',"+mapping+')'))
    marker.setDataDefinedProperty(QgsSymbolLayer.Property.Size,QgsProperty.fromExpression("mct_vkdp_value('ratio',"+mapping+') * coalesce("frame_mm",14)'))
    marker.setDataDefinedProperty(QgsSymbolLayer.Property.Angle,QgsProperty.fromField('rotation'))
    symbol=QgsMarkerSymbol(); symbol.changeSymbolLayer(0,marker)
    layer.setRenderer(QgsSingleSymbolRenderer(symbol))
    layer.setCustomProperty(FLAG,'points')
    layer.setCustomProperty('MilitaryCartographyTools/vkdp_reference',REF)
    apply_defaults(layer,DEFAULTS)
    return layer

LINE_SIDES={'friend':'Свої','hostile':'Противник','neutral':'Нейтральні','allied':'Дружні сили','obstacle':'Свої загородження'}
LINE_COLORS={'friend':'0,0,255,255','hostile':'255,0,0,255','neutral':'165,85,35,255','allied':'0,155,0,255','obstacle':'0,155,0,255'}

def build_geometry_layer(kind,crs='EPSG:32636'):
    area=kind=='areas'
    layer=QgsVectorLayer(('Polygon' if area else 'LineString')+'?crs='+crs,'ВКДП — '+('райони' if area else 'лінії та рубежі'),'memory')
    definitions=[('name',QMetaType.Type.QString,'Позначення'),('side',QMetaType.Type.QString,'Належність / призначення'),
        ('state',QMetaType.Type.QString,'Стан'),('width_mm',QMetaType.Type.Double,'Товщина лінії (мм)'),('notes',QMetaType.Type.QString,'Примітка')]
    layer.dataProvider().addAttributes([QgsField(key,kind_) for key,kind_,_ in definitions]); layer.updateFields()
    for index,(_,_,title) in enumerate(definitions): layer.setFieldAlias(index,title)
    layer.setEditorWidgetSetup(1,value_map(LINE_SIDES)); layer.setEditorWidgetSetup(2,value_map(STATES))
    layer.setEditorWidgetSetup(3,QgsEditorWidgetSetup('Range',{'Min':0.1,'Max':2,'Step':0.05,'Precision':2,'Style':'SpinBox'}))
    for key,value in [('side','friend'),('state','present'),('width_mm',0.3)]:
        layer.setDefaultValueDefinition(layer.fields().indexFromName(key),QgsDefaultValue(str(value) if isinstance(value,float) else QgsExpression.quotedString(value)))
    symbol=QgsFillSymbol.createSimple({'color':'0,0,0,0','outline_color':'0,0,255,255','outline_width':'0.3'}) if area else QgsLineSymbol.createSimple({'line_color':'0,0,255,255','line_width':'0.3'})
    drawing=symbol.symbolLayer(0)
    colours='CASE '+ ' '.join("WHEN \"side\"='"+side+"' THEN color_rgb("+','.join(colour.split(',')[:3])+")" for side,colour in LINE_COLORS.items())+" ELSE color_rgb(0,0,255) END"
    drawing.setDataDefinedProperty(QgsSymbolLayer.Property.StrokeColor,QgsProperty.fromExpression(colours))
    drawing.setDataDefinedProperty(QgsSymbolLayer.Property.StrokeWidth,QgsProperty.fromExpression('coalesce("width_mm",0.3)'))
    drawing.setDataDefinedProperty(QgsSymbolLayer.Property.StrokeStyle,QgsProperty.fromExpression("if(\"state\"='planned','dash','solid')"))
    layer.setRenderer(QgsSingleSymbolRenderer(symbol))
    labels=QgsPalLayerSettings(); labels.fieldName='name'
    fmt=QgsTextFormat(); fmt.setFont(QFont('Arial',9)); fmt.setSize(9); fmt.setColor(QColor('black')); labels.setFormat(fmt)
    layer.setLabeling(QgsVectorLayerSimpleLabeling(labels)); layer.setLabelsEnabled(True)
    layer.setCustomProperty(FLAG,kind)
    layer.setCustomProperty('MilitaryCartographyTools/vkdp_reference','ВКДП 5(3)-00(01).02, пп. 2.2.1–2.2.11; базові контури')
    return layer

def persist(layer,path,table):
    path=Path(path)
    if path.exists(): raise FileExistsError(str(path))
    path.parent.mkdir(parents=True,exist_ok=True)
    options=QgsVectorFileWriter.SaveVectorOptions(); options.driverName='GPKG'; options.layerName=table
    result=QgsVectorFileWriter.writeAsVectorFormatV3(layer,str(path),QgsProject.instance().transformContext(),options)
    if result[0]!=QgsVectorFileWriter.WriterError.NoError: raise RuntimeError(str(result[1]))
    stored=QgsVectorLayer(str(path)+'|layername='+table,layer.name(),'ogr')
    style=QgsMapLayerStyle(); style.readFromLayer(layer); style.writeToLayer(stored)
    stored.setCustomProperty(FLAG,layer.customProperty(FLAG,'')); stored.saveDefaultStyle()
    return stored

def get_layer(iface,kind='points'):
    active=iface.activeLayer()
    if active is not None and active.customProperty(FLAG,'')==kind: return active
    for layer in QgsProject.instance().mapLayers().values():
        if layer.customProperty(FLAG,'')==kind: return layer
    crs=iface.mapCanvas().mapSettings().destinationCrs().authid() or 'EPSG:32636'
    layer=build_point_layer(crs) if kind=='points' else build_geometry_layer(kind,crs)
    home=QgsProject.instance().homePath()
    if home:
        path=Path(home)/'data'/('game_vkdp_'+kind+'.gpkg'); index=2
        while path.exists():
            path=path.with_name('game_vkdp_'+kind+'_'+str(index)+'.gpkg'); index+=1
    else:
        file,_=QFileDialog.getSaveFileName(iface.mainWindow(),'Зберегти шар ВКДП','','GeoPackage (*.gpkg)')
        if not file: return None
        path=Path(file)
    stored=persist(layer,path,'vkdp_'+kind); QgsProject.instance().addMapLayer(stored)
    return stored

class SymbolEditor(QDialog):
    def __init__(self,iface,parent=None):
        super().__init__(parent)
        self.iface=iface; self.result_values=None; self.operation='place'
        self.setWindowTitle('ВКДП — конструктор умовного знака'); self.resize(1080,710)
        self.widgets={}
        tabs=QTabWidget()
        forms={}
        for key,title in [('main','Знак'),('text','Підписи'),('extra','Додатково')]:
            page=QWidget(); forms[key]=QFormLayout(page); tabs.addTab(page,title)
        self.presets=QComboBox()
        for caption,values in PRESETS: self.presets.addItem(caption,values)
        forms['main'].addRow('Зразок із документа',self.presets)
        choices={'domain':DOMAINS,'side':SIDES,'echelon':ECHELONS,'state':STATES,'effect':EFFECTS,
            'effect_side':{'friend':'Свої','hostile':'Противник'},
            'command_label':{'':'Без напису','КП':'КП','КСП':'КСП','ОКП':'ОКП','ПКП':'ПКП'},
            'reinforcement':{'':'Не зазначено','(+)':'Посилений (+)','(-)':'Послаблений (-)','(±)':'Посилений і послаблений (±)'}}
        main={'domain','entity','side','echelon','state','hq','command_label','frame_mm','rotation'}
        text_fields={'designation','higher','reinforcement','staff','info','dtg','source'}
        for key,label,kind,default in FIELDS:
            if key in ['entity','modifier1','modifier2'] or key in choices:
                widget=QComboBox()
                for code,caption in choices.get(key,{}).items(): widget.addItem(caption,code)
                if widget.findData(default)>=0: widget.setCurrentIndex(widget.findData(default))
            elif kind is bool: widget=QCheckBox()
            elif kind is float:
                widget=QDoubleSpinBox(); widget.setRange(4,60) if key=='frame_mm' else widget.setRange(-360,360)
                widget.setValue(default); widget.setSuffix(' мм' if key=='frame_mm' else '°')
            else: widget=QLineEdit(); widget.setText(str(default))
            self.widgets[key]=widget
            forms['main' if key in main else 'text' if key in text_fields else 'extra'].addRow(label,widget)
        self.widgets['domain'].setCurrentIndex(self.widgets['domain'].findData('ground_unit'))
        from .notation_preview import LivePreview
        self.live_preview=LivePreview()
        self.preview=self.live_preview.image
        self.preview_layer=build_point_layer(preview=True)
        self.message=QLabel(REF); self.message.setWordWrap(True)
        self.message.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        right=QVBoxLayout(); right.addWidget(self.live_preview,1); right.addWidget(self.message)
        body=QHBoxLayout(); body.addWidget(tabs,1); body.addLayout(right,1)
        place=QPushButton('Розмістити на карті'); replace=QPushButton('Оновити вибрані'); export=QPushButton('Зберегти SVG…'); close=QPushButton('Скасувати')
        active=iface.activeLayer()
        replace.setEnabled(active is not None and active.customProperty(FLAG,'')=='points' and active.selectedFeatureCount()>0)
        buttons=QHBoxLayout(); buttons.addWidget(export); buttons.addStretch(); buttons.addWidget(replace); buttons.addWidget(place); buttons.addWidget(close)
        outer=QVBoxLayout(self); outer.addLayout(body,1); outer.addLayout(buttons)
        self.widgets['domain'].currentIndexChanged.connect(self.populate_types)
        self.presets.currentIndexChanged.connect(lambda index:self.set_values(self.presets.itemData(index)) if index>0 else None)
        for key,widget in self.widgets.items():
            if key=='domain': continue
            if isinstance(widget,QComboBox): widget.currentIndexChanged.connect(self.refresh)
            elif isinstance(widget,QCheckBox): widget.toggled.connect(self.refresh)
            elif isinstance(widget,QDoubleSpinBox): widget.valueChanged.connect(self.refresh)
            else: widget.textChanged.connect(self.refresh)
        place.clicked.connect(lambda:self.finish('place')); replace.clicked.connect(lambda:self.finish('replace'))
        export.clicked.connect(self.export_svg); close.clicked.connect(self.reject)
        self.populate_types()
        if active is not None and active.customProperty(FLAG,'')=='points' and active.selectedFeatureCount()==1:
            feature=next(active.getSelectedFeatures()); self.set_values({k:feature[k] for k,_,_,_ in FIELDS})

    def populate_types(self,*args):
        domain=self.widgets['domain'].currentData()
        for key in ['entity','modifier1','modifier2']:
            combo=self.widgets[key]; combo.blockSignals(True); combo.clear()
            labels={code:entity_display_label(code,domain,'2525D') for code in ENTITIES[domain]} if key=='entity' else modifier_labels(domain,int(key[-1]))
            for code,caption in labels.items(): combo.addItem(caption,code)
            if key=='entity' and domain=='ground_unit': combo.setCurrentIndex(combo.findData('mechanized_infantry'))
            combo.blockSignals(False)
        self.widgets['hq'].setEnabled(domain=='ground_unit'); self.widgets['echelon'].setEnabled(domain=='ground_unit')
        self.refresh()

    def values(self):
        values={}
        for key,widget in self.widgets.items():
            values[key]=widget.currentData() if isinstance(widget,QComboBox) else widget.isChecked() if isinstance(widget,QCheckBox) else widget.value() if isinstance(widget,QDoubleSpinBox) else widget.text()
        return normalize(values)

    def set_values(self,values):
        values=normalize(values)
        self.widgets['domain'].setCurrentIndex(self.widgets['domain'].findData(values['domain']))
        self.populate_types()
        for key,widget in self.widgets.items():
            widget.blockSignals(True)
            if isinstance(widget,QComboBox): widget.setCurrentIndex(widget.findData(values[key]))
            elif isinstance(widget,QCheckBox): widget.setChecked(values[key])
            elif isinstance(widget,QDoubleSpinBox): widget.setValue(values[key])
            else: widget.setText(values[key])
            widget.blockSignals(False)
        self.refresh()

    def refresh(self,*args):
        try:
            values=self.values(); compose(values)
            from qgis.core import QgsFeature
            feature=QgsFeature(self.preview_layer.fields())
            for key,value in values.items(): feature[key]=value
            feature.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(0,0)))
            self.live_preview.set_feature(self.preview_layer,feature)
            if self.live_preview.last_image is None: self.live_preview.refresh()
            self.message.setText(REF+'\nПрив’язка: '+('низ флагштока' if self.values()['hq'] and self.values()['domain']=='ground_unit' else 'центр знака')+'\nРозмір задає ширину рамки; підписи не зменшують сам знак.')
        except Exception as error: self.message.setText('Не вдалося побудувати знак: '+str(error))

    def finish(self,operation):
        try: compose(self.values())
        except Exception as error:
            self.message.setText(str(error)); return
        self.operation=operation; self.result_values=self.values(); self.accept()

    def export_svg(self):
        data=compose(self.values())
        file,_=QFileDialog.getSaveFileName(self,'Зберегти умовний знак SVG','','SVG (*.svg)')
        if file:
            svg=ET.fromstring(data['svg']); width=data['ratio']*self.values()['frame_mm']; _,_,w,h=data['viewbox']
            svg.set('width',str(width)+'mm'); svg.set('height',str(width*h/w)+'mm')
            Path(file).write_bytes(ET.tostring(svg,encoding='utf-8',xml_declaration=True))

def update_selected(layer,values):
    if layer is None or layer.customProperty(FLAG,'')!='points': return 0
    ids=layer.selectedFeatureIds()
    if not ids: return 0
    if not layer.isEditable() and not layer.startEditing(): return 0
    normalized=normalize(values); compose(normalized)
    layer.beginEditCommand('Оновити знак ВКДП')
    for fid in ids:
        for key,value in normalized.items():
            if key=='notes': continue
            if not layer.changeAttributeValue(fid,layer.fields().indexFromName(key),value):
                layer.destroyEditCommand(); raise RuntimeError('Не вдалося оновити знак; операцію скасовано.')
    layer.endEditCommand(); layer.triggerRepaint(); return len(ids)

def show_editor(iface,initial=None):
    dialog=SymbolEditor(iface,iface.mainWindow())
    if initial: dialog.set_values(initial)
    if dialog.exec()!=QDialog.DialogCode.Accepted: return
    if dialog.operation=='replace':
        count=update_selected(iface.activeLayer(),dialog.result_values)
        iface.messageBar().pushInfo('ВКДП',f'Оновлено знаків: {count}. Збережіть зміни шару.'); return
    layer=get_layer(iface)
    if layer is None: return
    apply_defaults(layer,dialog.result_values)
    if not layer.isEditable() and not layer.startEditing(): return
    iface.setActiveLayer(layer); iface.actionAddFeature().trigger()
    iface.messageBar().pushInfo('ВКДП','Клацніть місце знака. Для пункту управління це точка внизу флагштока. Збережіть зміни шару.')

def draw_geometry(iface,kind):
    layer=get_layer(iface,kind)
    if layer is None: return
    if not layer.isEditable() and not layer.startEditing(): return
    iface.setActiveLayer(layer); iface.actionAddFeature().trigger()
    iface.messageBar().pushInfo('ВКДП','Накресліть геометрію, завершіть правою кнопкою та задайте належність, стан і позначення. Це базовий контур; спеціальні знаки доступні в бібліотеці PNG.')

def create_legend_layout(project=None):
    from qgis.core import QgsPrintLayout,QgsLayoutItemPage,QgsLayoutItemLabel,QgsLayoutItemShape,QgsLayoutItemPicture,QgsLayoutPoint,QgsLayoutSize
    project=project or QgsProject.instance()
    records={}
    for layer in project.mapLayers().values():
        if layer.customProperty(FLAG,'')!='points': continue
        for feature in layer.getFeatures():
            values=normalize({key:feature[key] for key,_,_,_ in FIELDS})
            identity=tuple(values[key] for key in VISUAL)
            records.setdefault(identity,values)
    if not records: return None
    layout=QgsPrintLayout(project); layout.initializeDefaults()
    base='Умовні позначення — ВКДП'; name=base; index=2
    while project.layoutManager().layoutByName(name): name=base+' '+str(index); index+=1
    layout.setName(name)
    values=list(records.values()); per_page=4
    def label(text,x,y,width,height,point_size=11):
        item=QgsLayoutItemLabel(layout); item.setText(text)
        fmt=QgsTextFormat(); fmt.setFont(QFont('Arial',point_size)); fmt.setSize(point_size); fmt.setColor(QColor('black')); item.setTextFormat(fmt)
        layout.addLayoutItem(item); item.attemptMove(QgsLayoutPoint(x,y)); item.attemptResize(QgsLayoutSize(width,height)); return item
    def cell(x,y,width,height):
        item=QgsLayoutItemShape(layout); item.setShapeType(QgsLayoutItemShape.Shape.Rectangle)
        item.setSymbol(QgsFillSymbol.createSimple({'color':'255,255,255,0','outline_color':'0,0,0,255','outline_width':'0.2'}))
        layout.addLayoutItem(item); item.attemptMove(QgsLayoutPoint(x,y)); item.attemptResize(QgsLayoutSize(width,height))
    for start in range(0,len(values),per_page):
        page_number=start//per_page
        if page_number:
            page=QgsLayoutItemPage(layout); page.setPageSize('A3',QgsLayoutItemPage.Orientation.Landscape); layout.pageCollection().addPage(page)
        else: layout.pageCollection().page(0).setPageSize('A3',QgsLayoutItemPage.Orientation.Landscape)
        offset=layout.pageCollection().page(page_number).pos().y()
        label('ВКДП 5(3)-00(01).02',60,offset+15,300,10,10)
        label('УМОВНІ ПОЗНАЧЕННЯ',60,offset+28,300,12,14)
        cell(60,offset+44,90,20); cell(150,offset+44,210,20)
        label('Знак',62,offset+47,86,12,12); label('Зміст знака',152,offset+47,206,12,12)
        for row,v in enumerate(values[start:start+per_page]):
            y=offset+64+row*45; cell(60,y,90,45); cell(150,y,210,45)
            data=compose(v); _,_,w,h=data['viewbox']; picture=QgsLayoutItemPicture(layout)
            picture.setPicturePath(data['path']); picture.setResizeMode(QgsLayoutItemPicture.ResizeMode.ZoomResizeFrame); layout.addLayoutItem(picture)
            frame_width=data['frame']['x2']-data['frame']['x1']
            scale=min(14,82*frame_width/w,42*frame_width/h)
            target_width=w/frame_width*scale; target_height=h/frame_width*scale
            picture.attemptMove(QgsLayoutPoint(64+(82-target_width)/2,y+(45-target_height)/2)); picture.attemptResize(QgsLayoutSize(target_width,target_height))
            caption=entity_display_label(v['entity'],v['domain'],'2525D')+'; '+SIDES[v['side']]
            if v['designation'] or v['higher']: caption+='\n'+v['designation']+(' / '+v['higher'] if v['higher'] else '')
            caption+='\n'+STATES[v['state']]+('; '+EFFECTS[v['effect']] if v['effect']!='normal' else '')
            label(caption,153,y+4,204,37,11)
    project.layoutManager().addLayout(layout); return layout

def show_legend(iface):
    layout=create_legend_layout()
    if layout is None:
        iface.messageBar().pushWarning('ВКДП','Спочатку розмістіть хоча б один редагований знак ВКДП.'); return
    iface.openLayoutDesigner(layout)

def open_reference(parent=None,page=None):
    from qgis.PyQt.QtCore import QUrl
    from qgis.PyQt.QtGui import QDesktopServices
    config=ROOT/'vkdp_reference.json'
    path=Path(json.loads(config.read_text(encoding='utf-8')).get('path','')) if config.is_file() else Path('')
    if not path.is_file():
        file,_=QFileDialog.getOpenFileName(parent,'Оберіть PDF із порядком оформлення','','PDF (*.pdf)')
        if not file: return
        path=Path(file)
    url=QUrl.fromLocalFile(str(path))
    if page: url.setFragment('page='+str(page))
    QDesktopServices.openUrl(url)

def install(plugin):
    QgsExpression.unregisterFunction('mct_vkdp_value'); QgsExpression.registerFunction(mct_vkdp_value)
    menu=QMenu('ВКДП — оформлення',plugin.toolbar)
    for text,callback in [('Конструктор редагованого знака…',lambda:show_editor(plugin.iface)),
        ('Накреслити лінію / рубіж',lambda:draw_geometry(plugin.iface,'lines')),
        ('Накреслити район',lambda:draw_geometry(plugin.iface,'areas'))]:
        action=menu.addAction(text); action.triggered.connect(callback)
    action=menu.addAction('Легенда редагованих знаків'); action.triggered.connect(lambda checked=False:show_legend(plugin.iface))
    action=menu.addAction('Відкрити зразки у PDF'); action.triggered.connect(lambda checked=False:open_reference(plugin.iface.mainWindow()))
    host=plugin.group_menus['nato_symbols']; host.insertMenu(host.actions()[0],menu)
    quick=QAction(QIcon(str(ROOT/'icons/icon.svg')),'ВКДП — конструктор',plugin.toolbar)
    quick.setToolTip('Редаговані знаки за зразками ВКДП 5(3)-00(01).02 для карти')
    quick.triggered.connect(lambda checked=False:show_editor(plugin.iface)); plugin.toolbar.addAction(quick)
    plugin._vkdp_menu=menu
    # A third source mode connects the familiar domain buttons to the VKDP constructor.
    from qgis.PyQt.QtGui import QActionGroup
    setting='MilitaryCartographyTools/symbol_source'
    from qgis.core import QgsSettings
    def is_vkdp(): return using_profile()
    for action in host.actions():
        child=action.menu()
        if child is not None and child.title()=='Джерело нових знаків':
            group=child.actions()[0].actionGroup()
            choice=child.addAction('ВКДП — редаговані умовні знаки'); choice.setCheckable(True)
            group.addAction(choice); choice.setChecked(is_vkdp())
            choice.triggered.connect(lambda checked=False:QgsSettings().setValue(setting,'vkdp'))
            break
    domain_actions={
        'tactical_graphics_space_action':'space','tactical_graphics_air_action':'air',
        'tactical_graphics_land_action':'ground_unit','tactical_graphics_sea_surface_action':'sea_surface',
        'tactical_graphics_subsurface_action':'subsurface','tactical_graphics_activities_action':'activities',
    }
    # Specialist signs use the user's document-based artwork in Ukrainian mode.
    png_categories={
        'tactical_graphics_sigint_action':'6-07-02','tactical_graphics_cyberspace_action':'',
        'c2_measures_action':'6-01','maneuver_control_measures_action':'6-02-01',
        'defensive_control_measures_action':'6-02-01','offensive_control_measures_action':'6-02-01',
        'maneuver_control_measures_2_action':'6-02-01','airspace_control_measures_action':'6-03',
        'maritime_control_measures_action':'6-04','deception_control_measures_action':'6-02-01',
        'fire_support_coordination_measures_action':'6-02-02','target_control_measures_action':'6-02-02',
        'obstacle_control_measures_action':'6-07-01','field_fortification_action':'6-07-01',
        'cbrn_defense_action':'6-07-03','target_acquisition_control_measures_action':'6-02-02',
        'sustainment_points_action':'6-08','supply_points_action':'6-08-03',
        'mission_task_points_action':'6-02-01','intelligence_control_measures_action':'6-02-03',
    }
    from . import user_png_symbols
    plugin._vkdp_bindings=[]
    for action,original,png_dispatch in getattr(plugin,'_png_bindings',[]):
        domain=next((value for name,value in domain_actions.items() if getattr(plugin,name,None) is action),None)
        category=next((value for name,value in png_categories.items() if getattr(plugin,name,None) is action),None)
        if action.text()=='Українські підрозділи та служби…': domain='ground_unit'
        if domain is None and category is None: continue
        action.triggered.disconnect(png_dispatch)
        def dispatch(checked=False,selected_domain=domain,selected_category=category,fallback=png_dispatch):
            if not is_vkdp(): return fallback()
            if selected_domain is not None: return show_editor(plugin.iface,{'domain':selected_domain})
            return user_png_symbols.show_browser(plugin.iface,selected_category)
        action.triggered.connect(dispatch); plugin._vkdp_bindings.append((action,png_dispatch,dispatch))
    plugin._vkdp_original_insert=plugin._insert_symbol
    def insert(designer):
        if not is_vkdp(): return plugin._vkdp_original_insert(designer)
        if getattr(plugin,'_ua_classic',False): return plugin._png_original_insert(designer)
        dialog=SymbolEditor(plugin.iface,designer.window())
        if dialog.exec()!=QDialog.DialogCode.Accepted: return
        data=compose(dialog.result_values)
        from qgis.core import QgsLayoutItemPicture,QgsLayoutSize,QgsLayoutPoint
        layout=designer.layout()
        if layout is None: return
        picture=QgsLayoutItemPicture(layout); picture.setPicturePath(data['path'])
        picture.setResizeMode(QgsLayoutItemPicture.ResizeMode.ZoomResizeFrame); layout.addLayoutItem(picture)
        width=data['ratio']*dialog.result_values['frame_mm']; _,_,w,h=data['viewbox']
        picture.attemptResize(QgsLayoutSize(width,width*h/w)); picture.attemptMove(QgsLayoutPoint(10,10))
        picture.setId('ВКДП — '+entity_display_label(dialog.result_values['entity'],dialog.result_values['domain'],'2525D'))
        picture.refreshPicture()
    plugin._insert_symbol=insert

def uninstall(plugin):
    for action,original,dispatch in getattr(plugin,'_vkdp_bindings',[]):
        try: action.triggered.disconnect(dispatch); action.triggered.connect(original)
        except (TypeError,RuntimeError): pass
    plugin._vkdp_bindings=[]
    if hasattr(plugin,'_vkdp_original_insert'): plugin._insert_symbol=plugin._vkdp_original_insert
    QgsExpression.unregisterFunction('mct_vkdp_value')
