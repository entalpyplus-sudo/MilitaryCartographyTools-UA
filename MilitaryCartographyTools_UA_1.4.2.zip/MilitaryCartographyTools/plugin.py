# -*- coding: utf-8 -*-
"""
Military Cartography Tools

Main plugin class.

Copyright (C) 2026 Praveen Kumar

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License v2 or later.
"""

import configparser
from pathlib import Path

from qgis.PyQt.QtCore import Qt, QUrl
from qgis.PyQt.QtGui import QAction, QIcon, QActionGroup, QDesktopServices
from qgis.PyQt.QtWidgets import QMessageBox, QToolButton, QMenu, QToolBar, QDialog
from qgis.PyQt import sip
from qgis.core import (
    Qgis,
    QgsApplication,
    QgsMessageLog,
    QgsLayoutItemMap,
    QgsLayoutItemPicture,
    QgsLayoutPoint,
    QgsLayoutSize,
    QgsUnitTypes,
)

from . import ukrainian_presets
from . import user_png_symbols
from . import vkdp_symbols
from . import notation_preview
from . import ukrainian_workflow
from . import free_zones
from . import layer_groups
from . import menu_preview
from . import global_search
from .expressions import mgrs_functions
from .expressions import military_symbology_functions
from .core.layout_refresh import connect_layout_refresh, disconnect_layout_refresh
from .core.coordinate_probe_tool import CoordinateProbeTool
from .core.bearing_range_tool import BearingRangeTool
from .grid import GridManager, add_grid_frame, remove_grid_frame
from .grid.grid_settings import GridSettings
from .layout import show_new_layout_dialog, LayoutOptionsPanel, show_map_sheet_series_dialog
from .military_symbology.space_layer import add_space_layer
from .military_symbology.air_layer import add_air_layer
from .military_symbology.edition import (
    current_edition,
    edition_label,
    set_current_edition,
)
from .military_symbology.sidc import EDITIONS
from .military_symbology.symbol_engine import render_symbol_base64_path
from .military_symbology.layout_symbol_dialog import InsertSymbolDialog
from .military_symbology.land_layer import add_land_layers
from .military_symbology.sea_surface_layer import add_sea_surface_layer
from .military_symbology.subsurface_layer import add_subsurface_layers
from .military_symbology.activities_layer import add_activities_layer
from .military_symbology.sigint_layer import add_sigint_layer
from .military_symbology.cyberspace_layer import add_cyberspace_layer
from .military_symbology.sustainment_control_measures import (
    add_sustainment_points_layer,
)
from .military_symbology.supply_points import (
    add_supply_points_layer,
    add_supply_routes_lines_layer,
    add_sustainment_areas_layer,
)
from .military_symbology.mission_task_control_measures import (
    add_mission_task_lines_layer,
    add_mission_task_points_layer,
)
from .military_symbology.intelligence_control_measures import (
    add_intelligence_control_measures_lines_layer,
)
from .military_symbology.c2_measures import (
    add_c2_measures_lines_layer,
    add_c2_measures_areas_layer,
    add_c2_measures_points_layer,
)
from .military_symbology.maneuver_control_measures import (
    add_maneuver_control_measures_lines_layer,
    add_maneuver_control_measures_areas_layer,
)
from .military_symbology.defensive_control_measures import (
    add_defensive_control_measures_areas_layer,
    add_defensive_control_measures_lines_layer,
    add_defensive_control_measures_points_layer,
)
from .military_symbology.offensive_control_measures import (
    add_offensive_control_measures_lines_layer,
    add_offensive_control_measures_areas_layer,
    add_offensive_control_measures_points_layer,
)
from .military_symbology.maneuver_control_measures_2 import (
    add_maneuver_control_measures_2_lines_layer,
    add_maneuver_control_measures_2_areas_layer,
)
from .military_symbology.airspace_control_measures import (
    add_airspace_control_measures_lines_layer,
    add_airspace_control_measures_areas_layer,
    add_airspace_control_measures_points_layer,
)
from .military_symbology.maritime_control_measures import (
    add_maritime_control_measures_lines_layer,
    add_maritime_control_measures_points_layer,
)
from .military_symbology.deception_control_measures import (
    add_deception_control_measures_lines_layer,
)
from .military_symbology.fire_support_coordination_measures import (
    add_fire_support_coordination_measures_lines_layer,
    add_fire_support_coordination_measures_areas_layer,
)
from .military_symbology.cbrn_defense import (
    add_cbrn_contaminated_areas_layer,
    add_cbrn_defense_points_layer,
    add_dose_rate_contours_layer,
    add_safe_distance_zones_layer,
)
from .military_symbology.field_fortification import (
    add_field_fortification_lines_layer,
    add_field_fortification_points_layer,
)
from .military_symbology.obstacle_control_measures import (
    add_obstacle_control_measures_areas_layer,
    add_obstacle_control_measures_lines_layer,
    add_obstacle_control_measures_minefields_layer,
    add_obstacle_control_measures_points_layer,
)
from .military_symbology.target_control_measures import (
    add_target_control_measures_lines_layer,
    add_target_control_measures_points_layer,
    add_target_control_measures_areas_layer,
)
from .military_symbology.target_acquisition_control_measures import (
    add_target_acquisition_control_measures_areas_layer,
    add_range_fans_layer,
)
from .terrain import (
    show_tanaka_contour_dialog,
    show_hypsometric_tint_dialog,
    show_hillshade_combination_dialog,
)
from .terrain.line_of_sight_tool import LineOfSightTool
from .terrain.sensor_coverage_dialog import SensorCoverageDialog
from .terrain.sensor_coverage_manager import SensorCoverageManager
from .terrain.viewshed_tool import ViewshedTool
from .waypoints import show_export_waypoints_dialog, show_import_waypoints_dialog


SUB_GRID_OPTIONS = [
    ('Вимкнено', None),
    ('10 км', 10000),
    ('5 км', 5000),
    ('1 км', 1000),
]


_plugin_dir = Path(__file__).parent

_cfg = configparser.ConfigParser()
_cfg.read(_plugin_dir / "metadata.txt", encoding="utf-8")

PLUGIN_NAME = _cfg.get("general", "name")
PLUGIN_VERSION = _cfg.get("general", "version")
PLUGIN_ID = _plugin_dir.name

# The self-contained HTML guide that ships in docs/ - compiled output,
# never hand-edited (see .claude/skills/military-cartography-user-guide).
USER_GUIDE_PATH = Path("docs") / "user-guide-uk.html"


class MilitaryCartographyTools:
    """
    Main plugin class.
    """

    def __init__(self, iface):

        self.iface = iface

        self.plugin_dir = Path(__file__).parent

        self.toolbar = None
        self.action = None
        self.user_guide_action = None

        self.utm_action = None
        self.mgrs100k_action = None
        self.clear_action = None
        self.new_layout_action = None
        self.coordinate_probe_action = None
        self.bearing_range_action = None
        self.tanaka_contours_action = None
        self.hypsometric_tint_action = None
        self.line_of_sight_action = None
        self.hillshade_combination_action = None
        self.viewshed_action = None
        self.sensor_coverage_action = None
        self.regenerate_sensor_coverage_action = None
        self.import_waypoints_action = None
        self.export_waypoints_action = None
        self.map_sheet_series_action = None
        self.tactical_graphics_space_action = None
        self.tactical_graphics_air_action = None
        self.tactical_graphics_land_action = None
        self.tactical_graphics_sea_surface_action = None
        self.tactical_graphics_subsurface_action = None
        self.tactical_graphics_activities_action = None
        self.tactical_graphics_sigint_action = None
        self.tactical_graphics_cyberspace_action = None

        # "Control Measures" nests as its own flyout submenu (like Sub
        # Grid below) rather than a single QAction, since Appendix H's
        # ~17 H.5.x logical groups (C2 Measures, Maneuver, Defensive,
        # ...) each get their own entry as their own mini-phase lands -
        # see _setup_control_measures_menu(). Every entry is one H.5.x
        # group's own layer; the flat "Control Measure Points" layer
        # that used to sit alongside them - a holding pen for entities
        # whose own table had not been built yet - was emptied and
        # retired by H19/H20/H21 (2026-08-14).
        self.control_measures_menu = None
        self.c2_measures_action = None
        self.maneuver_control_measures_action = None
        self.defensive_control_measures_action = None
        self.offensive_control_measures_action = None
        self.maneuver_control_measures_2_action = None
        self.airspace_control_measures_action = None
        self.obstacle_control_measures_action = None
        self.field_fortification_action = None
        self.cbrn_defense_action = None
        self.maritime_control_measures_action = None
        self.deception_control_measures_action = None
        self.fire_support_coordination_measures_action = None
        self.target_control_measures_action = None
        self.target_acquisition_control_measures_action = None
        self.sustainment_points_action = None
        self.supply_points_action = None
        self.mission_task_points_action = None
        self.intelligence_control_measures_action = None

        self.sub_grid_menu = None
        self.sub_grid_group = None

        # Toolbar-button/Plugins-submenu grouping (housekeeping
        # 2026-08-08, see _setup_toolbar_groups()) - keyed by group
        # key ("grid", "navigation", etc.), each value the QMenu shared
        # by that group's toolbar dropdown and Plugins submenu.
        self.group_menus = {}

        self.grid_manager = None
        self.coordinate_probe_tool = None
        self.bearing_range_tool = None
        self.line_of_sight_tool = None
        self.viewshed_tool = None

        # Keeps each level's Sensor Coverage perimeter in step with its
        # own Sensor Points layer - see
        # terrain/sensor_coverage_manager.py. Long-lived (it owns the
        # signal connections), unlike the setup dialog it is passed to.
        self.sensor_coverage_manager = None

        # One small toolbar per currently-open Layout Designer
        # window, keyed by the designer interface itself - just
        # the grid frame action, not a full copy of the canvas
        # toolbar (the layout already shows whatever grid is
        # built on the canvas; this only adds the print-specific
        # border ticks/annotations).
        self.layout_toolbars = {}

        # One "Military Layout Settings" dock panel per currently-
        # open Layout Designer window, same keying as
        # layout_toolbars - lets page size/orientation/scale/
        # heading/classification be changed on that specific
        # layout in place, instead of only at creation time via
        # New Military Layout.
        self.layout_panels = {}

    # ------------------------------------------------------------------
    # Logging
    # ------------------------------------------------------------------

    @staticmethod
    def log(message: str, level=Qgis.MessageLevel.Info):

        QgsMessageLog.logMessage(
            message,
            PLUGIN_NAME,
            level
        )


    # ------------------------------------------------------------------
    # QGIS Plugin API
    # ------------------------------------------------------------------

    def initGui(self):
        """
        Initialize plugin GUI.
        """

        mgrs_functions.register()
        military_symbology_functions.register()

        self.log(
            'Функції виразів MGRS зареєстровано.'
        )

        ukrainian_presets.localize_existing_layers()
        self._init_layout_refresh()
        self._init_grid_manager()

        self.toolbar = self.iface.addToolBar(
            PLUGIN_NAME
        )

        self.toolbar.setObjectName(
            PLUGIN_ID
        )

        self._setup_main_action()
        self._setup_user_guide_action()
        self._setup_grid_toggle_actions()
        self._setup_sub_grid_menu()
        self._setup_clear_action()
        self._setup_coordinate_probe_action()
        self._setup_bearing_range_action()
        self._setup_new_layout_action()
        self._setup_tanaka_contours_action()
        self._setup_hypsometric_tint_action()
        self._setup_line_of_sight_action()
        self._setup_hillshade_combination_action()
        self._setup_viewshed_action()
        self._setup_sensor_coverage_action()
        self._setup_import_waypoints_action()
        self._setup_export_waypoints_action()
        self._setup_map_sheet_series_action()
        self._setup_tactical_graphics_space_action()
        self._setup_tactical_graphics_air_action()
        self._setup_tactical_graphics_land_action()
        self._setup_tactical_graphics_sea_surface_action()
        self._setup_tactical_graphics_subsurface_action()
        self._setup_tactical_graphics_activities_action()
        self._setup_tactical_graphics_sigint_action()
        self._setup_tactical_graphics_cyberspace_action()
        self._setup_control_measures_menu()

        # Assembles every action built above (all built with
        # standalone=False, plus the sub-grid menu) into the grouped
        # toolbar buttons/Plugins submenus below - must run last, once
        # every individual action/menu already exists.
        self._setup_toolbar_groups()
        ukrainian_presets.install(self)
        user_png_symbols.install(self)
        vkdp_symbols.install(self)
        notation_preview.install(self)
        ukrainian_workflow.install(self)
        free_zones.install(self)
        layer_groups.install(self)
        menu_preview.install(self)
        global_search.install(self)

        # Add the grid-frame toolbar to every print layout window -
        # each Layout Designer gets its own small toolbar, since a
        # print layout's map item has its own extent/scale,
        # independent of the interactive canvas.
        self.iface.layoutDesignerOpened.connect(
            self.on_layout_designer_opened
        )

        self.iface.layoutDesignerWillBeClosed.connect(
            self.on_layout_designer_closed
        )

        self.log(
            f"{PLUGIN_NAME} {PLUGIN_VERSION} завантажено."
        )


    def _init_layout_refresh(self):

        try:

            connect_layout_refresh()

            self.log(
                'Оновлення макетів підключено.'
            )

        except Exception as e:

            self.log(
                f"Не вдалося підключити оновлення макетів: {e}",
                Qgis.MessageLevel.Warning
            )


    def _init_grid_manager(self):

        try:

            self.grid_manager = GridManager(
                self.iface
            )

            self.log(
                'Менеджер сіток ініціалізовано.'
            )

        except Exception as e:

            self.log(
                f"Не вдалося ініціалізувати менеджер сіток: {e}",
                Qgis.MessageLevel.Warning
            )


    def _build_action(
        self,
        icon_name,
        text,
        tooltip=None,
        checkable=False,
        callback=None,
        standalone=True
    ):

        """
        A QAction with an icon from icons/icon_name - shared by every
        top-level action initGui() builds below, since they all follow
        the same icon+tooltip+callback shape (only the main "about"
        action and the sub-grid dropdown, which isn't a QAction at all,
        are built separately). `standalone` (default True) controls
        whether this action is placed directly on the main toolbar and
        in the flat Plugins menu, the same as before every action got
        grouped - pass False for an action that instead belongs inside
        one of _setup_toolbar_groups()'s own group menus, which places
        it there itself once every individual action has been built.
        """

        action = QAction(
            QIcon(
                str(
                    self.plugin_dir / "icons" / icon_name
                )
            ),
            text,
            self.iface.mainWindow()
        )

        if tooltip:

            action.setToolTip(
                tooltip
            )

        if checkable:

            action.setCheckable(True)

        if callback is not None:

            (action.toggled if checkable else action.triggered).connect(
                callback
            )

        if standalone:

            self.toolbar.addAction(
                action
            )

            self.iface.addPluginToMenu(
                PLUGIN_NAME,
                action
            )

        return action


    def _setup_main_action(self):

        self.action = QAction(
            QIcon(
                str(
                    self.plugin_dir / "icons" / "icon.svg"
                )
            ),
            PLUGIN_NAME,
            self.iface.mainWindow()
        )

        self.action.triggered.connect(
            self.show_about
        )

        self.iface.addPluginToMenu(
            PLUGIN_NAME,
            self.action
        )

        self.toolbar.addAction(
            self.action
        )


    def _setup_user_guide_action(self):

        # On the toolbar straight after About, in this plugin's Plugins
        # submenu, and under Help -> Plugins, where QGIS users look for
        # a plugin's documentation. QGIS's own help icon rather than a
        # custom one, so it reads as help at a glance.
        self.user_guide_action = QAction(
            QgsApplication.getThemeIcon("/mActionHelpContents.svg"),
            'Посібник користувача',
            self.iface.mainWindow()
        )

        self.user_guide_action.setToolTip(
            'Відкрити посібник з інструментів військової картографії у браузері'
        )

        self.user_guide_action.triggered.connect(
            self.show_user_guide
        )

        self.iface.addPluginToMenu(
            PLUGIN_NAME,
            self.user_guide_action
        )

        self.iface.pluginHelpMenu().addAction(
            self.user_guide_action
        )

        self.toolbar.addAction(
            self.user_guide_action
        )


    def _setup_grid_toggle_actions(self):

        self.utm_action = self._build_action(
            "utm_grid.svg",
            'Сітка UTM',
            tooltip='Показати або приховати сітку координатних зон UTM',
            checkable=True,
            callback=self.toggle_utm_grid,
            standalone=False
        )

        self.mgrs100k_action = self._build_action(
            "mgrs100k_grid.svg",
            'Сітка MGRS 100 км',
            tooltip='Показати або приховати сітку 100-кілометрових квадратів MGRS',
            checkable=True,
            callback=self.toggle_mgrs100k_grid,
            standalone=False
        )


    def _setup_sub_grid_menu(self):

        # A plain QMenu (not a standalone toolbar button, unlike
        # before the toolbar/menu grouping housekeeping) - nested
        # into the Grid group's own menu by _setup_toolbar_groups(),
        # both on the toolbar and in the Plugins menu, as a "Sub
        # Grid" flyout alongside UTM/MGRS 100km/Clear Grid. Parented
        # to the toolbar (not the main window) so sip.delete(self.
        # toolbar) in unload() cascades and cleans this up too, same
        # reasoning as every other toolbar-owned widget here.
        self.sub_grid_menu = QMenu(
            'Додаткова сітка',
            self.toolbar
        )

        self.sub_grid_menu.setIcon(
            QIcon(
                str(
                    self.plugin_dir / "icons" / "sub_grid.svg"
                )
            )
        )

        self.sub_grid_menu.setToolTipsVisible(True)

        self.sub_grid_menu.menuAction().setToolTip(
            'Крок додаткової сітки (10 км / 5 км / 1 км)'
        )

        self.sub_grid_group = QActionGroup(
            self.sub_grid_menu
        )

        # Nothing is generated until the user picks an option -
        # "Off" starts checked, matching every other grid toggle.
        for label, value in SUB_GRID_OPTIONS:

            option_action = QAction(
                label,
                self.sub_grid_menu
            )

            option_action.setCheckable(True)

            option_action.setChecked(
                value is None
            )

            option_action.triggered.connect(
                lambda checked, v=value: self.set_sub_grid_option(v)
            )

            self.sub_grid_group.addAction(
                option_action
            )

            self.sub_grid_menu.addAction(
                option_action
            )


    def _setup_edition_menu(self):

        """
        Which MIL-STD edition NEW symbology layers are built against.

        A setting rather than a per-layer prompt: the entity dropdown on
        each layer is a ValueMap, frozen when the field is configured, so
        edition has to be decided before a layer exists. Changing it never
        touches layers already in the project - those keep the edition
        they were built with, which is what their own renderer expression
        already says.
        """

        self.edition_menu = QMenu(
            'Редакція стандарту умовних знаків',
            self.toolbar
        )

        self.edition_menu.setIcon(
            QIcon(
                str(
                    self.plugin_dir / "icons" / "symbology_edition.svg"
                )
            )
        )

        self.edition_menu.setToolTipsVisible(True)

        self.edition_menu.menuAction().setToolTip(
            'Редакція MIL-STD для нових шарів умовних знаків. Наявні шари проєкту не змінюються.'
        )

        self.edition_group = QActionGroup(self.edition_menu)

        active = current_edition()

        for value in EDITIONS:

            option_action = QAction(
                edition_label(value),
                self.edition_menu
            )

            option_action.setCheckable(True)
            option_action.setChecked(value == active)

            option_action.setToolTip(
                'Нові шари умовних знаків використовують %s. Наявні шари зберігають редакцію, з якою їх створено.'
                % edition_label(value)
            )

            option_action.triggered.connect(
                lambda checked, v=value: self.set_symbology_edition(v)
            )

            self.edition_group.addAction(option_action)
            self.edition_menu.addAction(option_action)

        self.toolbar.addAction(self.edition_menu.menuAction())


    def set_symbology_edition(self, value):

        """Store `value` as the edition newly added layers are built with."""

        set_current_edition(value)

        self.iface.messageBar().pushInfo(
            'Інструменти військової картографії',
            'Нові шари умовних знаків використовуватимуть %s. Наявні шари проєкту не змінюються.' % edition_label(value)
        )


    def _setup_clear_action(self):

        # Removes every grid layer and turns every toggle off.
        # Grids are only ever built once and then shown/hidden by
        # the toggles above, so this is the explicit action for
        # wiping the slate before picking grids again for a new
        # area.
        self.clear_action = self._build_action(
            "clear_grid.svg",
            'Видалити сітки',
            tooltip='Видалити всі шари сіток та вимкнути всі сітки',
            callback=self.clear_grids,
            standalone=False
        )


    def _setup_new_layout_action(self):

        # Creates a fully-configured print layout (page size,
        # orientation, initial scale) in one step, rather than
        # QGIS's own New Layout dialog which only takes a name and
        # starts blank.
        self.new_layout_action = self._build_action(
            "new_layout.svg",
            'Новий військовий макет',
            tooltip=(
                'Створити макет друку із заданими розміром сторінки, орієнтацією та початковим масштабом'
            ),
            callback=self.create_new_layout,
            standalone=False
        )


    def _setup_tanaka_contours_action(self):

        # Illuminated contours from a DEM, clipped to the current
        # map canvas extent - see terrain/tanaka_contours.py.
        self.tanaka_contours_action = self._build_action(
            "tanaka_contours.svg",
            'Горизонталі Танаки',
            tooltip=(
                'Створити освітлені горизонталі Танаки з цифрової моделі рельєфу для поточного охоплення карти'
            ),
            callback=self.create_tanaka_contours,
            standalone=False
        )


    def _setup_hypsometric_tint_action(self):

        # Filled elevation-colour raster from a DEM, clipped to the
        # current map canvas extent - see terrain/hypsometric_tint.py.
        self.hypsometric_tint_action = self._build_action(
            "hypsometric_tint.svg",
            'Гіпсометричне забарвлення',
            tooltip=(
                'Створити растр гіпсометричного забарвлення за висотами цифрової моделі рельєфу для поточного охоплення карти'
            ),
            callback=self.create_hypsometric_tint,
            standalone=False
        )


    def _setup_hillshade_combination_action(self):

        # Multi-directional hillshade blend from a DEM, clipped to
        # the current map canvas extent - see
        # terrain/hillshade_combination.py.
        self.hillshade_combination_action = self._build_action(
            "hillshade_combination.svg",
            'Комбіноване відмивання рельєфу',
            tooltip=(
                'Створити комбіноване відмивання рельєфу за 2–3 напрямками освітлення для поточного охоплення карти'
            ),
            callback=self.create_hillshade_combination,
            standalone=False
        )


    def _setup_coordinate_probe_action(self):

        # Click-to-read-coordinates tool - stays active across
        # multiple clicks like QGIS's own Identify/Measure tools,
        # so the toggle needs to track when some OTHER tool
        # replaces it too (see _on_map_tool_changed), not just
        # respond to its own button.
        self.coordinate_probe_tool = CoordinateProbeTool(
            self.iface.mapCanvas(),
            self.iface
        )

        self.coordinate_probe_action = self._build_action(
            "coordinate_probe.svg",
            'Визначення координат',
            tooltip=(
                'Клацніть на карті, щоб показати широту, довготу й координати MGRS та скопіювати координати MGRS у буфер обміну'
            ),
            checkable=True,
            callback=self.toggle_coordinate_probe,
            standalone=False
        )

        self.iface.mapCanvas().mapToolSet.connect(
            self._on_map_tool_changed
        )


    def _setup_bearing_range_action(self):

        # Two-click true/grid/magnetic azimuth + distance tool - see
        # core/bearing_range_tool.py. Stays active across repeated
        # pairs like the coordinate probe/line of sight tools, so it
        # shares the same _on_map_tool_changed un-check handling (no
        # separate mapToolSet connection needed - one connection
        # already covers every map tool).
        self.bearing_range_tool = BearingRangeTool(
            self.iface.mapCanvas(),
            self.iface
        )

        self.bearing_range_action = self._build_action(
            "bearing_range.svg",
            'Азимут / відстань',
            tooltip=(
                'Укажіть дві точки на карті, щоб визначити істинний і магнітний азимути, дирекційний кут та відстань'
            ),
            checkable=True,
            callback=self.toggle_bearing_range,
            standalone=False
        )


    def _setup_line_of_sight_action(self):

        # Two-click point-to-point visibility check tool - see
        # terrain/line_of_sight_tool.py/terrain/line_of_sight.py.
        # Stays active across repeated pairs like the coordinate
        # probe tool, so it shares the same _on_map_tool_changed
        # un-check handling (no separate mapToolSet connection
        # needed - one connection already covers every map tool).
        self.line_of_sight_tool = LineOfSightTool(
            self.iface.mapCanvas(),
            self.iface
        )

        self.line_of_sight_action = self._build_action(
            "line_of_sight.svg",
            'Пряма видимість',
            tooltip=(
                'Укажіть дві точки на карті для перевірки прямої видимості з урахуванням рельєфу, кривини Землі та рефракції'
            ),
            checkable=True,
            callback=self.toggle_line_of_sight,
            standalone=False
        )


    def _setup_viewshed_action(self):

        # Single-click coverage-sweep tool - see
        # terrain/viewshed_tool.py/terrain/viewshed.py. Stays active
        # across repeated clicks like the coordinate probe/line of
        # sight tools, so it shares the same _on_map_tool_changed
        # un-check handling (no separate mapToolSet connection
        # needed - one connection already covers every map tool).
        self.viewshed_tool = ViewshedTool(
            self.iface.mapCanvas(),
            self.iface
        )

        self.viewshed_action = self._build_action(
            "viewshed.svg",
            'Зона видимості',
            tooltip=(
                'Укажіть точку на карті для побудови зони видимості в межах заданої дальності з урахуванням рельєфу, кривини Землі та рефракції'
            ),
            checkable=True,
            callback=self.toggle_viewshed,
            standalone=False
        )


    def _setup_sensor_coverage_action(self):

        # One-shot setup dialog, not a map tool: it creates the sensor
        # points layers and points them at a DEM, after which the
        # coverage keeps itself up to date whenever the user commits an
        # edit - see terrain/sensor_coverage_manager.py.
        self.sensor_coverage_manager = SensorCoverageManager(
            self.iface
        )

        self.sensor_coverage_action = self._build_action(
            "sensor_coverage.svg",
            'Зона покриття сенсорів',
            tooltip=(
                'Розмістіть сенсори нижнього, середнього або верхнього рівня та побудуйте об’єднану зону покриття кожного рівня'
            ),
            callback=self.create_sensor_coverage,
            standalone=False
        )

        # A separate action rather than a button inside the setup
        # dialog: the whole point is to redraw coverage WITHOUT having
        # to open that dialog - see regenerate_sensor_coverage().
        self.regenerate_sensor_coverage_action = self._build_action(
            "regenerate_sensor_coverage.svg",
            'Перерахувати покриття сенсорів',
            tooltip=(
                'Перерахувати покриття сенсорів усіх рівнів, не очікуючи наступного збереження'
            ),
            callback=self.regenerate_sensor_coverage,
            standalone=False
        )

        # Bind the points layers as they arrive - including on a project
        # load, where the connections made in this session are gone.
        self.sensor_coverage_manager.install()


    def _setup_import_waypoints_action(self):

        # One-shot dialog action, not a map tool - see
        # waypoints/gpx_kml_dialog.py.
        self.import_waypoints_action = self._build_action(
            "import_waypoints.svg",
            'Імпортувати маршрутні точки',
            tooltip=(
                'Імпортувати маршрутні точки з GPX або KML з підписами координат MGRS'
            ),
            callback=self.create_import_waypoints,
            standalone=False
        )


    def _setup_export_waypoints_action(self):

        # One-shot dialog action, not a map tool - see
        # waypoints/gpx_kml_dialog.py.
        self.export_waypoints_action = self._build_action(
            "export_waypoints.svg",
            'Експортувати маршрутні точки',
            tooltip=(
                'Експортувати точковий шар у GPX або KML, використовуючи координати MGRS як назви точок'
            ),
            callback=self.create_export_waypoints,
            standalone=False
        )


    def _setup_map_sheet_series_action(self):

        # One-shot dialog action, not a map tool - see
        # layout/map_sheet_series_dialog.py.
        self.map_sheet_series_action = self._build_action(
            "map_sheet_series.svg",
            'Серія аркушів карти',
            tooltip=(
                'Створити пронумеровану серію аркушів друку, що покривають поточне охоплення карти'
            ),
            callback=self.create_map_sheet_series,
            standalone=False
        )


    def _setup_tactical_graphics_space_action(self):

        # One-shot action, not a map tool - see
        # military_symbology/space_layer.py. Covers both of Appendix B's
        # sections (Space Equipment/Platform and the single Space
        # Missile entity) in one layer.
        self.tactical_graphics_space_action = self._build_action(
            "tactical_graphics_space.svg",
            'Космос',
            tooltip=(
                'Додати шар «Космос» (MIL-STD-2525D, додаток B). Умовний знак кожної точки автоматично будується за її атрибутами.'
            ),
            callback=self.create_tactical_graphics_space,
            standalone=False
        )


    def _setup_tactical_graphics_air_action(self):

        # One-shot action, not a map tool - see
        # military_symbology/air_layer.py. Covers both of Appendix C's
        # sections (Air Equipment/Platform and the single Air Missile
        # entity) in one layer.
        self.tactical_graphics_air_action = self._build_action(
            "tactical_graphics_air.svg",
            'Повітряні об’єкти',
            tooltip=(
                'Додати шар «Повітряні об’єкти» (MIL-STD-2525D, додаток C). Умовний знак кожної точки автоматично будується за її атрибутами.'
            ),
            callback=self.create_tactical_graphics_air,
            standalone=False
        )


    def _setup_tactical_graphics_land_action(self):

        # One-shot action, not a map tool - see
        # military_symbology/land_layer.py. Adds all four of Appendix
        # D's layers (Land Unit/Civilian/Equipment/Installation) in one
        # click - each is a genuinely distinct, substantial vocabulary
        # (unlike Space/Air Missile, not folded into a shared layer).
        self.tactical_graphics_land_action = self._build_action(
            "tactical_graphics_land.svg",
            'Наземні об’єкти',
            tooltip=(
                'Додати шари сухопутних підрозділів, цивільних об’єктів, техніки та інфраструктури (MIL-STD-2525D, додаток D). Знаки будуються автоматично за атрибутами.'
            ),
            callback=self.create_tactical_graphics_land,
            standalone=False
        )


    def _setup_tactical_graphics_sea_surface_action(self):

        # One-shot action, not a map tool - see
        # military_symbology/sea_surface_layer.py.
        self.tactical_graphics_sea_surface_action = self._build_action(
            "tactical_graphics_sea_surface.svg",
            'Надводні об’єкти',
            tooltip=(
                'Додати шар «Надводні об’єкти» (MIL-STD-2525D, додаток E). Умовний знак кожної точки автоматично будується за її атрибутами.'
            ),
            callback=self.create_tactical_graphics_sea_surface,
            standalone=False
        )


    def _setup_tactical_graphics_subsurface_action(self):

        # One-shot action, not a map tool - see
        # military_symbology/subsurface_layer.py. Adds both of Appendix
        # F's layers (Subsurface, Mine Warfare) in one click.
        self.tactical_graphics_subsurface_action = self._build_action(
            "tactical_graphics_subsurface.svg",
            'Підводні об’єкти',
            tooltip=(
                'Додати шари підводних об’єктів і мінної війни (MIL-STD-2525D, додаток F). Знаки будуються автоматично за атрибутами.'
            ),
            callback=self.create_tactical_graphics_subsurface,
            standalone=False
        )


    def _setup_tactical_graphics_activities_action(self):

        # One-shot action, not a map tool - see
        # military_symbology/activities_layer.py.
        self.tactical_graphics_activities_action = self._build_action(
            "tactical_graphics_activities.svg",
            'Діяльність',
            tooltip=(
                'Додати шар «Діяльність» (MIL-STD-2525D, додаток G). Умовний знак кожної точки автоматично будується за її атрибутами.'
            ),
            callback=self.create_tactical_graphics_activities,
            standalone=False
        )


    def _setup_tactical_graphics_sigint_action(self):

        # One-shot action, not a map tool - see
        # military_symbology/sigint_layer.py.
        self.tactical_graphics_sigint_action = self._build_action(
            "tactical_graphics_sigint.svg",
            'Радіоелектронна розвідка (SIGINT)',
            tooltip=(
                'Додати шар «Радіоелектронна розвідка (SIGINT)» (MIL-STD-2525D, додаток J). Умовний знак кожної точки автоматично будується за її атрибутами.'
            ),
            callback=self.create_tactical_graphics_sigint,
            standalone=False
        )


    def _setup_tactical_graphics_cyberspace_action(self):

        # One-shot action, not a map tool - see
        # military_symbology/cyberspace_layer.py.
        self.tactical_graphics_cyberspace_action = self._build_action(
            "tactical_graphics_cyberspace.svg",
            'Кіберпростір',
            tooltip=(
                'Додати шар «Кіберпростір» (MIL-STD-2525D, додаток L). Умовний знак кожної точки автоматично будується за її атрибутами.'
            ),
            callback=self.create_tactical_graphics_cyberspace,
            standalone=False
        )


    def _setup_control_measures_menu(self):

        # "Control Measures" nests as its own flyout submenu (same
        # QMenu-inside-a-group mechanism as Sub Grid inside Grid - see
        # _setup_sub_grid_menu()) rather than a single QAction, at the
        # project maintainer's own request (2026-08-09): Appendix H
        # covers ~17 logical sections (C2 Measures, Maneuver, Defensive,
        # Offensive, Airspace, Maritime, Deception, Fire Support,
        # Targets, Target Acquisition, Obstacles, Field Fortification,
        # CBRN, Sustainment, Supply, Mission Tasks, Intelligence - see
        # docs/roadmap.md's own H3-H22 mini-phase table), and one click
        # adding every one of them at once (the old single "Control
        # Measures" action) would only get more unwieldy as each
        # mini-phase lands - see military_symbology/c2_measures.py's own
        # docstring for the full rationale. Each entry here is its own
        # H.5.x group, added only once that group's own mini-phase is
        # actually built. The flat "Control Measure Points" layer that
        # used to sit alongside them held whichever point entities had
        # no table module yet; H19/H20/H21 moved its last 21 entries
        # out to Sustainment/Supply/Mission Task Points and it was
        # retired (2026-08-14).
        self._setup_edition_menu()

        self.control_measures_menu = QMenu(
            'Заходи управління',
            self.toolbar
        )

        self.control_measures_menu.setIcon(
            QIcon(
                str(
                    self.plugin_dir / "icons" / "control_measures.svg"
                )
            )
        )

        self.control_measures_menu.setToolTipsVisible(True)

        self.control_measures_menu.menuAction().setToolTip(
            'Заходи управління з додатка H, згруповані за розділами'
        )

        self.c2_measures_action = QAction(
            'Заходи командування та управління',
            self.control_measures_menu
        )

        self.c2_measures_action.setToolTip(
            'Додати шари командування та управління: розмежувальні лінії, райони операцій, райони інтересу, аеродромні зони та пункти управління. MIL-STD-2525D, додаток H.5.5/H.5.9/H.5.10.'
        )

        self.c2_measures_action.triggered.connect(
            self.create_c2_measures
        )


        self.maneuver_control_measures_action = QAction(
            'Заходи управління маневром',
            self.control_measures_menu
        )

        self.maneuver_control_measures_action.setToolTip(
            'Додати шари управління маневром: передову лінію військ, рубежі регулювання, райони зосередження, зони десантування, висадки та евакуації. MIL-STD-2525D, додаток H.5.11.'
        )

        self.maneuver_control_measures_action.triggered.connect(
            self.create_maneuver_control_measures
        )


        self.defensive_control_measures_action = QAction(
            'Заходи управління обороною',
            self.control_measures_menu
        )

        self.defensive_control_measures_action.setToolTip(
            'Додати шари управління обороною: бойові позиції, опорні пункти, райони ураження, спостережні пости та орієнтири для цілевказання. MIL-STD-2525D, додаток H.5.12.'
        )

        self.defensive_control_measures_action.triggered.connect(
            self.create_defensive_control_measures
        )


        self.offensive_control_measures_action = QAction(
            'Заходи управління наступом',
            self.control_measures_menu
        )

        self.offensive_control_measures_action.setToolTip(
            'Додати шари управління наступом: осі просування, напрямки атак, рубежі узгодження, вихідні рубежі, позиції для атаки та райони об’єктів атаки. MIL-STD-2525D, додаток H.5.13.'
        )

        self.offensive_control_measures_action.triggered.connect(
            self.create_offensive_control_measures
        )


        self.maneuver_control_measures_2_action = QAction(
            'Заходи управління маневром II',
            self.control_measures_menu
        )

        self.maneuver_control_measures_2_action.setToolTip(
            'Додати другий набір шарів управління маневром: оточення, ділянки прориву, позиції вогневої підтримки, райони розвідки та межі плацдармів. MIL-STD-2525D, додаток H.5.14.'
        )

        self.maneuver_control_measures_2_action.triggered.connect(
            self.create_maneuver_control_measures_2
        )


        self.airspace_control_measures_action = QAction(
            'Заходи управління повітряним простором',
            self.control_measures_menu
        )

        self.airspace_control_measures_action.setToolTip(
            'Додати шари управління повітряним простором: коридори, маршрути, зони оборони баз, зони обмежених операцій і застосування зброї та контрольні точки. MIL-STD-2525D, додаток H.5.15.'
        )

        self.airspace_control_measures_action.triggered.connect(
            self.create_airspace_control_measures
        )


        self.maritime_control_measures_action = QAction(
            'Заходи управління морськими операціями',
            self.control_measures_menu
        )

        self.maritime_control_measures_action.setToolTip(
            'Додати шари управління морськими операціями: лінії пеленгів, підводні й надводні пости, маршрути, опорні точки, гідроакустичні буї, пошук і небезпеки. MIL-STD-2525D, додаток H.5.16.'
        )

        self.maritime_control_measures_action.triggered.connect(
            self.create_maritime_control_measures
        )


        self.deception_control_measures_action = QAction(
            'Заходи введення противника в оману',
            self.control_measures_menu
        )

        self.deception_control_measures_action.setToolTip(
            'Додати лінійний шар заходів введення противника в оману: хибні цілі та макети. MIL-STD-2525D, додаток H.5.17.'
        )

        self.deception_control_measures_action.triggered.connect(
            self.create_deception_control_measures
        )


        self.fire_support_coordination_measures_action = QAction(
            'Заходи координації вогневої підтримки',
            self.control_measures_menu
        )

        self.fire_support_coordination_measures_action.setToolTip(
            'Додати шари координації вогневої підтримки: райони дозволеного, забороненого й обмеженого вогню, позиційні райони артилерії, рубежі координації та траєкторії боєприпасів. MIL-STD-2525D, додаток H.5.18.'
        )

        self.fire_support_coordination_measures_action.triggered.connect(
            self.create_fire_support_coordination_measures
        )


        self.target_control_measures_action = QAction(
            'Заходи управління цілями',
            self.control_measures_menu
        )

        self.target_control_measures_action.setToolTip(
            'Додати шари управління цілями: лінійні та площинні цілі, димові цілі, загороджувальний вогонь, групи цілей і райони вогневої підтримки. MIL-STD-2525D, додаток H.5.19.'
        )

        self.target_control_measures_action.triggered.connect(
            self.create_target_control_measures
        )


        self.obstacle_control_measures_action = QAction(
            'Заходи управління загородженнями',
            self.control_measures_menu
        )

        self.obstacle_control_measures_action.setToolTip(
            'Додати шари загороджень: точки, райони, мінні поля та лінії. Доступні міни, міни-пастки, інженерні пункти, протитанкові й дротяні загородження, обходи, дорожні загородження та переправи. Типовий колір — зелений; для кожного об’єкта можна обрати чорний. MIL-STD-2525D, додаток H.5.21.'
        )

        self.obstacle_control_measures_action.triggered.connect(
            self.create_obstacle_control_measures
        )


        self.field_fortification_action = QAction(
            'Польові фортифікаційні споруди',
            self.control_measures_menu
        )

        self.field_fortification_action.setToolTip(
            'Додати точкові та лінійні шари польових фортифікаційних споруд. Укриття й форти позначаються точками. Укріплений рубіж задається довільною лінією, позиція — двома передніми кутами. Фронт розташований ЛІВОРУЧ від напрямку оцифрування. MIL-STD-2525D, додаток H.5.22.'
        )

        self.field_fortification_action.triggered.connect(
            self.create_field_fortification
        )


        self.cbrn_defense_action = QAction(
            'Заходи РХБ захисту',
            self.control_measures_menu
        )

        self.cbrn_defense_action.setToolTip(
            'Додати чотири шари РХБ захисту: точки хімічних, біологічних, ядерних і радіаційних подій, пункти спеціальної обробки, заражені райони, зони мінімальної безпечної відстані та ізолінії потужності дози. MIL-STD-2525D, додаток H.5.23.'
        )

        self.cbrn_defense_action.triggered.connect(
            self.create_cbrn_defense
        )


        self.target_acquisition_control_measures_action = QAction(
            'Заходи розвідки та виявлення цілей',
            self.control_measures_menu
        )

        self.target_acquisition_control_measures_action.setToolTip(
            'Додати райони розвідки й виявлення цілей, зони виклику вогню, мертвого простору, відповідальності та ураження. Додати сектори дальності зброї / сенсорів: центр і до п’яти кіл або секторів. MIL-STD-2525D, додаток H.5.20.'
        )

        self.target_acquisition_control_measures_action.triggered.connect(
            self.create_target_acquisition_control_measures
        )


        self.sustainment_points_action = QAction(
            'Пункти забезпечення',
            self.control_measures_menu
        )

        self.sustainment_points_action.setToolTip(
            'Додати шар пунктів забезпечення: передачі поранених, постачання боєприпасів, збору поранених і затриманих, регулювання руху тощо.'
        )

        self.sustainment_points_action.triggered.connect(
            self.create_sustainment_points
        )


        # Named "...Control Measures" rather than "Supply Points"
        # (2026-08-18, UI request) - the one click adds three layers
        # (Points/Lines/Areas, see create_supply_points()), and every
        # other multi-geometry entry in this menu uses that suffix;
        # "Supply Points" specifically read as promising only points,
        # which is exactly what the maintainer found confusing.
        # "Sustainment Points" (Table H-XXII, its own action above)
        # keeps its own name unrenamed - it genuinely is points-only.
        self.supply_points_action = QAction(
            'Заходи управління постачанням',
            self.control_measures_menu
        )

        self.supply_points_action.setToolTip(
            'Додати шари пунктів постачання за класами НАТО й США, основних і запасних маршрутів постачання з напрямками руху та районів забезпечення.'
        )

        self.supply_points_action.triggered.connect(
            self.create_supply_points
        )


        self.mission_task_points_action = QAction(
            'Тактичні завдання',
            self.control_measures_menu
        )

        self.mission_task_points_action.setToolTip(
            'Додати шари тактичних завдань. Точки: знищити, перешкоджати діям, нейтралізувати. Лінії: блокувати, дезорганізувати, скувати. Інші завдання таблиці ще не реалізовано. MIL-STD-2525D, додаток H.5.26.'
        )

        self.mission_task_points_action.triggered.connect(
            self.create_mission_task_points
        )


        self.intelligence_control_measures_action = QAction(
            'Заходи управління розвідкою',
            self.control_measures_menu
        )

        self.intelligence_control_measures_action.setToolTip(
            'Додати лінійний шар управління розвідкою: рубіж координації розвідки ICL із позначенням на обох кінцях. MIL-STD-2525D, додаток H.5.27.'
        )

        self.intelligence_control_measures_action.triggered.connect(
            self.create_intelligence_control_measures
        )

        # Alphabetical by label (2026-08-18, UI request) - a plain
        # "pick one of many" flyout, not a table that has to mirror
        # the standard's own H.5.x section order. Batched here rather
        # than interleaved after each action's own construction above,
        # so this order can be read and changed in one place.
        for action in (
            self.airspace_control_measures_action,
            self.c2_measures_action,
            self.cbrn_defense_action,
            self.deception_control_measures_action,
            self.defensive_control_measures_action,
            self.field_fortification_action,
            self.fire_support_coordination_measures_action,
            self.intelligence_control_measures_action,
            self.maneuver_control_measures_action,
            self.maneuver_control_measures_2_action,
            self.maritime_control_measures_action,
            self.mission_task_points_action,
            self.obstacle_control_measures_action,
            self.offensive_control_measures_action,
            self.supply_points_action,
            self.sustainment_points_action,
            self.target_acquisition_control_measures_action,
            self.target_control_measures_action,
        ):
            self.control_measures_menu.addAction(action)


    def _setup_toolbar_groups(self):

        # Housekeeping (2026-08-08): every action above is now built
        # with standalone=False, so none of them land on the main
        # toolbar or the flat Plugins menu by themselves - this groups
        # them into six logical toolbar buttons (each a QToolButton
        # with an InstantPopup dropdown, the same mechanism the
        # existing Sub Grid control already used) mirrored as six
        # nested submenus in the Plugins menu (the group's own QMenu,
        # added once via its own menuAction() - see
        # _build_toolbar_group()). Only the main "about" action stays
        # a standalone top-level item. Must run after every individual
        # action/menu above has been built.
        groups = [
            (
                "grid",
                "group_grid.svg",
                'Сітка',
                'Керування сітками UTM/MGRS, кроком додаткової сітки та видаленням сіток',
                [
                    self.utm_action,
                    self.mgrs100k_action,
                    self.sub_grid_menu,
                    self.clear_action,
                ],
            ),
            (
                "navigation",
                "group_navigation.svg",
                'Навігація',
                'Визначення координат, азимутів і відстаней',
                [
                    self.coordinate_probe_action,
                    self.bearing_range_action,
                ],
            ),
            (
                "terrain_analysis",
                "group_terrain_analysis.svg",
                'Аналіз рельєфу',
                (
                    'Аналіз цифрової моделі рельєфу: горизонталі Танаки, гіпсометричне забарвлення, відмивання, пряма видимість, зони видимості та покриття сенсорів'
                ),
                [
                    self.tanaka_contours_action,
                    self.hypsometric_tint_action,
                    self.hillshade_combination_action,
                    self.line_of_sight_action,
                    self.viewshed_action,
                    self.sensor_coverage_action,
                    self.regenerate_sensor_coverage_action,
                ],
            ),
            (
                "waypoints",
                "group_waypoints.svg",
                'Маршрутні точки',
                'Імпорт та експорт маршрутних точок (GPX/KML)',
                [
                    self.import_waypoints_action,
                    self.export_waypoints_action,
                ],
            ),
            (
                "nato_symbols",
                "group_nato_symbols.svg",
                'Умовні знаки НАТО',
                (
                    'Тактичні умовні знаки MIL-STD-2525D/E та APP-6D/E: космічні, повітряні, наземні, надводні, підводні об’єкти, діяльність, радіоелектронна розвідка, кіберпростір і заходи управління. Редакція задається в меню стандарту умовних знаків.'
                ),
                # Alphabetical by label (2026-08-18, UI request) - a
                # plain "pick one of many" dropdown, not a table that
                # has to mirror the standard's own appendix order.
                [
                    self.tactical_graphics_activities_action,
                    self.tactical_graphics_air_action,
                    self.control_measures_menu,
                    self.tactical_graphics_cyberspace_action,
                    self.tactical_graphics_land_action,
                    self.tactical_graphics_sea_surface_action,
                    self.tactical_graphics_sigint_action,
                    self.tactical_graphics_space_action,
                    self.tactical_graphics_subsurface_action,
                ],
            ),
            # Print Production stays last, always (2026-08-09, at the
            # maintainer's request) - "creating print layouts" is the
            # natural final step of a mapping workflow, so its own group
            # button anchors the end of the toolbar regardless of what
            # else is added before it.
            (
                "print_production",
                "group_print_production.svg",
                'Підготовка до друку',
                'Створення військового макета та серії аркушів карти',
                [
                    self.new_layout_action,
                    self.map_sheet_series_action,
                ],
            ),
        ]

        for key, icon_name, title, tooltip, items in groups:

            self.group_menus[key] = self._build_toolbar_group(
                key,
                icon_name,
                title,
                tooltip,
                items
            )


    def _build_toolbar_group(self, key, icon_name, title, tooltip, items):

        """
        One QToolButton (added to the main toolbar, InstantPopup
        dropdown) and one nested Plugins-menu submenu, both backed by
        the SAME QMenu instance - clicking either shows identical
        items in identical (checked/unchecked, etc.) state, since
        they're literally the same QAction objects underneath. `items`
        is a list of QAction and/or QMenu instances (a QMenu - e.g.
        Sub Grid - nests as its own flyout via QMenu.addMenu()). Returns
        the QMenu, which the caller keeps in self.group_menus for
        unload() to detach cleanly from the Plugins menu before the
        toolbar (and this menu, one of its children) gets destroyed.
        """

        icon = QIcon(
            str(
                self.plugin_dir / "icons" / icon_name
            )
        )

        # Parented to the toolbar (not the main window) so
        # sip.delete(self.toolbar) in unload() cascades and cleans
        # this up too, same reasoning as the Sub Grid menu above.
        menu = QMenu(
            title,
            self.toolbar
        )

        menu.setIcon(
            icon
        )

        for item in items:

            if isinstance(item, QMenu):

                menu.addMenu(
                    item
                )

            else:

                menu.addAction(
                    item
                )

        button = QToolButton()

        button.setIcon(
            icon
        )

        button.setText(
            title
        )

        button.setToolTip(
            tooltip
        )

        # Icon-only (2026-08-09, at the maintainer's request): the
        # group's own tooltip (below) already communicates the function
        # on hover, and dropping the text keeps the toolbar's six group
        # buttons compact - .setText() above is kept regardless, for
        # accessibility (screen readers) and the Plugins-menu submenu's
        # own title, neither of which this style affects.
        button.setToolButtonStyle(
            Qt.ToolButtonStyle.ToolButtonIconOnly
        )

        button.setPopupMode(
            QToolButton.ToolButtonPopupMode.InstantPopup
        )

        button.setMenu(
            menu
        )

        button.setObjectName(
            f"{PLUGIN_ID}_group_{key}"
        )

        self.toolbar.addWidget(
            button
        )

        self.iface.addPluginToMenu(
            PLUGIN_NAME,
            menu.menuAction()
        )

        return menu


    def unload(self):
        global_search.uninstall(self)
        menu_preview.uninstall(self)
        layer_groups.uninstall(self)
        free_zones.uninstall(self)
        ukrainian_workflow.uninstall(self)
        notation_preview.uninstall(self)
        vkdp_symbols.uninstall(self)
        user_png_symbols.uninstall(self)
        ukrainian_presets.uninstall(self)
        """
        Unload plugin.
        """

        mgrs_functions.unregister()
        military_symbology_functions.unregister()

        disconnect_layout_refresh()

        if self.coordinate_probe_tool is not None:

            if self.iface.mapCanvas().mapTool() is self.coordinate_probe_tool:

                self.iface.mapCanvas().unsetMapTool(
                    self.coordinate_probe_tool
                )

            try:

                self.iface.mapCanvas().mapToolSet.disconnect(
                    self._on_map_tool_changed
                )

            except (TypeError, RuntimeError):

                pass

        if self.bearing_range_tool is not None:

            if self.iface.mapCanvas().mapTool() is self.bearing_range_tool:

                self.iface.mapCanvas().unsetMapTool(
                    self.bearing_range_tool
                )

        if self.line_of_sight_tool is not None:

            if self.iface.mapCanvas().mapTool() is self.line_of_sight_tool:

                self.iface.mapCanvas().unsetMapTool(
                    self.line_of_sight_tool
                )

        try:

            self.iface.layoutDesignerOpened.disconnect(
                self.on_layout_designer_opened
            )

            self.iface.layoutDesignerWillBeClosed.disconnect(
                self.on_layout_designer_closed
            )

        except (TypeError, RuntimeError):

            # Already disconnected (e.g. initGui() never
            # completed, or unload() is somehow running twice) -
            # PyQt raises TypeError for a signal that was never
            # connected and RuntimeError if the underlying C++
            # object is already gone; either way there's nothing
            # left to disconnect.
            pass

        for designer, toolbar in list(self.layout_toolbars.items()):

            designer.window().removeToolBar(
                toolbar
            )

            sip.delete(toolbar)

        self.layout_toolbars.clear()

        for designer, panel in list(self.layout_panels.items()):

            designer.window().removeDockWidget(
                panel
            )

            sip.delete(panel)

        self.layout_panels.clear()

        # Detach every top-level Plugins-menu entry - the main
        # "about" action plus each group's own menuAction() (see
        # _build_toolbar_group()) - before the toolbar teardown below
        # destroys the QMenu objects backing the latter (all parented
        # to the toolbar). Removing a QAction from a QMenu after its
        # underlying object is already gone would leave a dangling
        # reference in that menu; individual grouped actions (UTM
        # Grid, Tanaka Contours, and so on) were never registered with
        # the Plugins menu directly, only ever added into their own
        # group's QMenu, so detaching each group's single menuAction()
        # here is sufficient - nothing further to do per child action.
        for action in [self.action, self.user_guide_action] + [
            menu.menuAction() for menu in self.group_menus.values()
        ]:

            if action is not None:

                self.iface.removePluginMenu(
                    PLUGIN_NAME,
                    action
                )

        if self.user_guide_action is not None:

            # Help -> Plugins belongs to QGIS, not to this plugin, so
            # it outlives unload() - without this, every Plugin
            # Reloader cycle would leave another "User Guide" entry.
            self.iface.pluginHelpMenu().removeAction(
                self.user_guide_action
            )

            self.user_guide_action = None


        if self.toolbar is not None:

            self.iface.removeToolBarIcon(
                self.action
            )

            self.iface.mainWindow().removeToolBar(
                self.toolbar
            )

            # Delete the underlying C++ object immediately rather
            # than via deleteLater(): Plugin Reloader calls unload()
            # and re-runs initGui() synchronously without returning
            # to the Qt event loop, so a deferred delete leaves the
            # old toolbar (same object name) alive when the new one
            # is created, triggering QGIS's duplicate-widget cleanup.
            sip.delete(self.toolbar)

            self.toolbar = None


        # utm_action/mgrs100k_action/clear_action/new_layout_action/
        # coordinate_probe_action/bearing_range_action/
        # tanaka_contours_action/hypsometric_tint_action/
        # line_of_sight_action/hillshade_combination_action/
        # viewshed_action/sensor_coverage_action/
        # import_waypoints_action/
        # export_waypoints_action/map_sheet_series_action are
        # parented to the main window (like self.action above), not
        # the toolbar, so they survive sip.delete(self.toolbar) -
        # just drop the references.
        self.utm_action = None
        self.mgrs100k_action = None
        self.clear_action = None
        self.new_layout_action = None
        self.coordinate_probe_action = None
        self.coordinate_probe_tool = None
        self.bearing_range_action = None
        self.bearing_range_tool = None
        self.tanaka_contours_action = None
        self.hypsometric_tint_action = None
        self.line_of_sight_action = None
        self.line_of_sight_tool = None
        self.hillshade_combination_action = None
        self.viewshed_action = None
        self.viewshed_tool = None
        self.sensor_coverage_action = None
        self.regenerate_sensor_coverage_action = None

        if self.sensor_coverage_manager is not None:

            # Its project-level connections outlive the plugin object
            # otherwise, and would fire into a dead manager on the next
            # project load.
            self.sensor_coverage_manager.uninstall()

        self.sensor_coverage_manager = None
        self.import_waypoints_action = None
        self.export_waypoints_action = None
        self.map_sheet_series_action = None
        self.tactical_graphics_space_action = None
        self.tactical_graphics_air_action = None
        self.tactical_graphics_land_action = None
        self.tactical_graphics_sea_surface_action = None
        self.tactical_graphics_subsurface_action = None
        self.tactical_graphics_activities_action = None
        self.tactical_graphics_sigint_action = None
        self.tactical_graphics_cyberspace_action = None
        self.c2_measures_action = None
        self.maneuver_control_measures_action = None
        self.defensive_control_measures_action = None
        self.offensive_control_measures_action = None
        self.maneuver_control_measures_2_action = None
        self.airspace_control_measures_action = None
        self.obstacle_control_measures_action = None
        self.maritime_control_measures_action = None
        self.deception_control_measures_action = None
        self.fire_support_coordination_measures_action = None
        self.target_control_measures_action = None
        self.target_acquisition_control_measures_action = None
        self.sustainment_points_action = None
        self.supply_points_action = None
        self.mission_task_points_action = None
        self.intelligence_control_measures_action = None

        # sub_grid_menu/group, control_measures_menu, and every
        # group_menus entry ARE parented to the toolbar (see
        # _setup_sub_grid_menu()/_setup_control_measures_menu()/
        # _build_toolbar_group()), so sip.delete(self.toolbar) above
        # already destroyed them.
        self.sub_grid_menu = None
        self.sub_grid_group = None
        self.control_measures_menu = None
        self.group_menus = {}

        self.log(
            f"{PLUGIN_NAME} вивантажено."
        )


    # ------------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------------

    def toggle_utm_grid(self, checked):
        """
        Show/hide the UTM Grid Zone Designator grid. Only
        generates it the first time - after that this just
        toggles layer-tree visibility (see Regenerate Grids
        for rebuilding it against a new map extent).
        """

        GridSettings.set_utm_visible(
            checked
        )

        if self.grid_manager is None:
            return

        if checked:

            self.grid_manager.show_utm()

        else:

            self.grid_manager.hide_utm()


    def toggle_mgrs100k_grid(self, checked):
        """
        Show/hide the MGRS 100km square grid. Only generates
        it the first time - see toggle_utm_grid().
        """

        GridSettings.set_mgrs100_visible(
            checked
        )

        if self.grid_manager is None:
            return

        if checked:

            # The 100km grid is built from the UTM Grid Zone
            # Designator layer - bring it up first if it isn't
            # already showing (this also flips the UTM toggle
            # on, via its own toggled signal).
            if not self.utm_action.isChecked():

                self.utm_action.setChecked(True)

            self.grid_manager.show_mgrs100k()

        else:

            self.grid_manager.hide_mgrs100k()


    def set_sub_grid_option(self, spacing):
        """
        Switch the sub grid: None hides it, otherwise spacing
        (10000/5000/1000) selects 10km/5km/1km. Each spacing is
        only generated the first time it's picked - after that,
        switching just shows/hides the matching layer.
        """

        if self.grid_manager is None:
            return

        if spacing is None:

            GridSettings.set_mgrs_sub_visible(False)

            self.grid_manager.hide_sub_grid()

            return

        GridSettings.set_mgrs_sub_visible(True)

        GridSettings.set_mgrs_sub_spacing(
            spacing
        )

        # Same dependency pattern as MGRS 100km: bring UTM up
        # first if it isn't already on.
        if not self.utm_action.isChecked():

            self.utm_action.setChecked(True)

        self.grid_manager.show_sub_grid()


    def clear_grids(self):
        """
        Remove every grid layer (all sub-grid spacings
        included) and turn every toggle off - a clean slate
        before picking grids again for a new area.
        """

        if self.grid_manager is None:
            return

        self.grid_manager.clear()


        GridSettings.set_utm_visible(False)

        self.utm_action.setChecked(False)

        GridSettings.set_mgrs100_visible(False)

        self.mgrs100k_action.setChecked(False)

        GridSettings.set_mgrs_sub_visible(False)

        for action in self.sub_grid_menu.actions():

            if action.text() == 'Вимкнено':

                action.setChecked(True)


    def create_new_layout(self):
        """
        Prompt for page size/orientation/scale and create a new
        print layout accordingly.
        """

        show_new_layout_dialog(
            self.iface
        )


    def create_tanaka_contours(self):
        """
        Prompt for a DEM and illumination parameters, then generate
        a Tanaka contour layer for the current map extent.
        """

        show_tanaka_contour_dialog(
            self.iface
        )


    def create_hypsometric_tint(self):
        """
        Prompt for a DEM and opacity, then generate a hypsometric
        tint layer for the current map extent.
        """

        show_hypsometric_tint_dialog(
            self.iface
        )


    def create_hillshade_combination(self):
        """
        Prompt for a DEM and an azimuth preset, then generate a
        combined hillshade layer for the current map extent.
        """

        show_hillshade_combination_dialog(
            self.iface
        )


    def toggle_coordinate_probe(self, checked):
        """
        Activate/deactivate the coordinate probe map tool.
        """

        if checked:

            self.iface.mapCanvas().setMapTool(
                self.coordinate_probe_tool
            )

        else:

            self.iface.mapCanvas().unsetMapTool(
                self.coordinate_probe_tool
            )


    def toggle_bearing_range(self, checked):
        """
        Activate/deactivate the bearing/range map tool.
        """

        if checked:

            self.iface.mapCanvas().setMapTool(
                self.bearing_range_tool
            )

        else:

            self.iface.mapCanvas().unsetMapTool(
                self.bearing_range_tool
            )


    def toggle_line_of_sight(self, checked):
        """
        Activate/deactivate the line of sight map tool.
        """

        if checked:

            self.iface.mapCanvas().setMapTool(
                self.line_of_sight_tool
            )

        else:

            self.iface.mapCanvas().unsetMapTool(
                self.line_of_sight_tool
            )


    def toggle_viewshed(self, checked):
        """
        Activate/deactivate the viewshed map tool.
        """

        if checked:

            self.iface.mapCanvas().setMapTool(
                self.viewshed_tool
            )

        else:

            self.iface.mapCanvas().unsetMapTool(
                self.viewshed_tool
            )


    def regenerate_sensor_coverage(self):

        """
        Redraw every level's coverage from its own sensor points.

        Coverage normally redraws when a points layer is saved, which
        is deliberate - each sensor is a full viewshed run. But a
        reopened project, or a laydown whose DEM has just changed, has
        nothing to trigger that, and the maintainer found the only way
        out was to nudge a sensor until Save lit up. This is the way
        out.
        """

        regenerated = self.sensor_coverage_manager.regenerate_all()

        if regenerated:

            self.iface.messageBar().pushInfo(
                'Інструменти військової картографії',
                'Перераховано покриття сенсорів: %s.'
                % ", ".join(level.label for level in regenerated)
            )

        else:

            self.iface.messageBar().pushWarning(
                'Інструменти військової картографії',
                'Немає покриття для перерахунку. Створіть шар через «Зона покриття сенсорів» і розмістіть на ньому хоча б один сенсор.'
            )


    def create_sensor_coverage(self):
        """
        Set up (or repoint) the multi-sensor coverage layers - see
        terrain/sensor_coverage_dialog.py.
        """

        # Any sensor points layer already in this project - reopened
        # from disk, or added before this dialog was last closed -
        # needs its coverage connection re-made, since signal
        # connections don't survive a project load.
        self.sensor_coverage_manager.attach_existing()

        dialog = SensorCoverageDialog(
            self.iface,
            self.sensor_coverage_manager,
            self.iface.mainWindow()
        )

        dialog.exec()


    def create_import_waypoints(self):
        """
        Prompt for a GPX/KML file and import its waypoints, labelled
        with their MGRS grid reference.
        """

        show_import_waypoints_dialog(
            self.iface
        )


    def create_export_waypoints(self):
        """
        Prompt for a point layer and a GPX/KML destination, then
        export it with each waypoint's name set to its MGRS grid
        reference.
        """

        show_export_waypoints_dialog(
            self.iface
        )


    def create_map_sheet_series(self):
        """
        Prompt for page size/orientation/scale, then batch-generate
        a numbered series of print sheets tiling the current map
        extent.
        """

        show_map_sheet_series_dialog(
            self.iface
        )


    def create_tactical_graphics_space(self):
        """
        Add a "Space" layer (MIL-STD-2525D Appendix B), ready for
        placing symbols with QGIS's own native point editing tools.
        """

        add_space_layer(
            self.iface
        )


    def create_tactical_graphics_air(self):
        """
        Add an "Air" layer (MIL-STD-2525D Appendix C), ready for
        placing symbols with QGIS's own native point editing tools.
        """

        add_air_layer(
            self.iface
        )


    def create_tactical_graphics_land(self):
        """
        Add "Land Unit"/"Land Civilian"/"Land Equipment"/"Land
        Installation" layers (MIL-STD-2525D Appendix D), ready for
        placing symbols with QGIS's own native point editing tools.
        """

        add_land_layers(
            self.iface
        )


    def create_tactical_graphics_sea_surface(self):
        """
        Add a "Sea Surface" layer (MIL-STD-2525D Appendix E), ready for
        placing symbols with QGIS's own native point editing tools.
        """

        add_sea_surface_layer(
            self.iface
        )


    def create_tactical_graphics_subsurface(self):
        """
        Add "Subsurface" and "Mine Warfare" layers (MIL-STD-2525D
        Appendix F), ready for placing symbols with QGIS's own native
        point editing tools.
        """

        add_subsurface_layers(
            self.iface
        )


    def create_tactical_graphics_activities(self):
        """
        Add an "Activities" layer (MIL-STD-2525D Appendix G), ready for
        placing symbols with QGIS's own native point editing tools.
        """

        add_activities_layer(
            self.iface
        )


    def create_tactical_graphics_sigint(self):
        """
        Add a "SIGINT" layer (MIL-STD-2525D Appendix J), ready for
        placing symbols with QGIS's own native point editing tools.
        """

        add_sigint_layer(
            self.iface
        )


    def create_tactical_graphics_cyberspace(self):
        """
        Add a "Cyberspace" layer (MIL-STD-2525D Appendix L), ready for
        placing symbols with QGIS's own native point editing tools.
        """

        add_cyberspace_layer(
            self.iface
        )


    def create_c2_measures(self):
        """
        Add the C2 Measures layers (lines: Boundary, Light Line; areas:
        Area of Operations, Named/Target Area of Interest, Airfield
        Zone; points: Checkpoint, Contact/Coordination/Decision Point,
        and similar, Table H-VI - MIL-STD-2525D Appendix H.5.5/H.5.9/
        H.5.10), ready for digitizing with QGIS's own native editing
        tools.
        """

        add_c2_measures_lines_layer(
            self.iface
        )

        add_c2_measures_areas_layer(
            self.iface
        )

        add_c2_measures_points_layer(
            self.iface
        )


    def create_maneuver_control_measures(self):
        """
        Add the Maneuver Control Measures layers (lines: Forward Line
        of Troops, Phase Line, FEBA, Principal Direction of Fire;
        areas: Area, Assembly Area, Action Areas, Drop/Extraction/
        Landing/Pickup Zones, Fortified Area - MIL-STD-2525D Appendix
        H.5.11, Table H-VII), ready for digitizing with QGIS's own
        native editing tools.
        """

        add_maneuver_control_measures_lines_layer(
            self.iface
        )

        add_maneuver_control_measures_areas_layer(
            self.iface
        )


    def create_defensive_control_measures(self):
        """
        Add the Defensive Control Measures layers (areas: Battle
        Position, Strong Point, Engagement Area, Table H-VIII; lines:
        Contain and Retain, the same table's own two procedural
        arc constructions; points: Observation Post and its variants,
        Target Reference Point, Table H-IX - MIL-STD-2525D Appendix
        H.5.12), ready for digitizing with QGIS's own native editing
        tools.
        """

        add_defensive_control_measures_areas_layer(
            self.iface
        )

        add_defensive_control_measures_lines_layer(
            self.iface
        )

        add_defensive_control_measures_points_layer(
            self.iface
        )


    def create_offensive_control_measures(self):
        """
        Add the Offensive Control Measures layers (lines: Axis of
        Advance, Direction of Attack, Infiltration Lane, Final
        Coordination Line, Limit of Advance, Line of Departure(/Line of
        Contact), Probable Line of Deployment; areas: Assault Position,
        Attack Position, Objective Area; points: Point of Departure -
        MIL-STD-2525D Appendix H.5.13, Tables H-X/H-XI), ready for
        digitizing with QGIS's own native editing tools.
        """

        add_offensive_control_measures_lines_layer(
            self.iface
        )

        add_offensive_control_measures_areas_layer(
            self.iface
        )

        add_offensive_control_measures_points_layer(
            self.iface
        )


    def create_maneuver_control_measures_2(self):
        """
        Add a second set of Maneuver Control Measures layers
        (Encirclement, Penetration Box, Support by Fire Position,
        Search Area/Reconnaissance Area, Airhead/Bridgehead/Holding/
        Release Line - MIL-STD-2525D Appendix H.5.14, Table H-XII),
        ready for digitizing with QGIS's own native editing tools.
        """

        add_maneuver_control_measures_2_lines_layer(
            self.iface
        )

        add_maneuver_control_measures_2_areas_layer(
            self.iface
        )


    def create_airspace_control_measures(self):
        """
        Add Airspace Control Measures layers (lines: Air Corridor,
        Low-Level Transit Route, Minimum-Risk Route, Safe Lane, SAAFR,
        Transit Corridor, UA Route, IFF Off/On Line; areas: High-Density
        Airspace Control Zone, Restricted Operations Zone family,
        Weapon Engagement Zone family, Weapons Free Zone -
        MIL-STD-2525D Appendix H.5.15, Table H-XIII), ready for
        digitizing with QGIS's own native editing tools. The airspace
        control point vocabulary (ACP, CCP, TACAN, Orbit, and similar)
        now comes with them, on its own third Points layer - see
        airspace_control_measures.py's own docstring.
        """

        add_airspace_control_measures_lines_layer(
            self.iface
        )

        add_airspace_control_measures_areas_layer(
            self.iface
        )

        add_airspace_control_measures_points_layer(
            self.iface
        )


    def create_maritime_control_measures(self):
        """
        Add a Maritime Control Measures (Lines) layer (the Bearing Line
        family - Bearing, Electronic, Electronic Warfare, Acoustic (and
        its Ambiguous variant), Torpedo, Electro-Optical Intercept,
        Jammer, Radio Detention Finder - MIL-STD-2525D Appendix H.5.16,
        Table H-XIV), plus a Points layer carrying the table's own
        full 105-entry point vocabulary (printed pages 474-501,
        grouped by the table's own sub-headings - Surface/Subsurface
        Stations, Routes, Sonobuoys, Hazard, and the rest), ready for
        digitizing with QGIS's own native editing tools. Table H-XIV
        has no Areas section. See maritime_control_measures.py's own
        docstring for the five codes deliberately left out and for the
        AEGIS-combat-system-specific family that stays out of scope
        entirely.
        """

        add_maritime_control_measures_lines_layer(
            self.iface
        )

        add_maritime_control_measures_points_layer(
            self.iface
        )


    def create_deception_control_measures(self):
        """
        Add a Deception Control Measures (Lines) layer (Decoy/Dummy -
        MIL-STD-2525D Appendix H.5.17, Table H-XV), ready for digitizing
        with QGIS's own native editing tools. Every other entry in this
        table is either a cross-reference to a symbol already built in
        Maneuver/Offensive Control Measures, or deferred to the future
        Obstacles table - see deception_control_measures.py's own
        docstring.
        """

        add_deception_control_measures_lines_layer(
            self.iface
        )


    def create_fire_support_coordination_measures(self):
        """
        Add Fire Support Coordination Measures layers (areas: Airspace
        Coordination Area, Free/No/Restricted Fire Area, Position Area
        For Artillery; lines: Fire Support Coordination Line,
        Coordinated Fire Line, No Fire Line, Battlefield Coordination
        Line, Restrictive Fire Line, Munition Flight Path -
        MIL-STD-2525D Appendix H.5.18, Table H-XVI), ready for
        digitizing with QGIS's own native editing tools.
        """

        add_fire_support_coordination_measures_lines_layer(
            self.iface
        )

        add_fire_support_coordination_measures_areas_layer(
            self.iface
        )


    def create_target_control_measures(self):
        """
        Add Target Control Measures layers (lines: Linear Target,
        Linear Smoke Target, Final Protective Fire; areas: Area Target,
        Series or Group of Targets, Smoke, Bomb Area, Fire Support Area
        - MIL-STD-2525D Appendix H.5.19, Table H-XVII), ready for
        digitizing with QGIS's own native editing tools, plus a Points
        layer carrying this table's own nine point entries
        (Point/Single/Nuclear/Recorded Target, Fire Support Station,
        Firing/Hide/Launch/Reload/Survey Control Point).
        """

        add_target_control_measures_lines_layer(
            self.iface
        )

        add_target_control_measures_areas_layer(
            self.iface
        )

        add_target_control_measures_points_layer(
            self.iface
        )


    def create_cbrn_defense(self):
        """
        Add all four CBRN Defense layers - Table H-XXI (MIL-STD-2525D
        Appendix H.5.23), complete as of 2026-08-15.
        """

        add_cbrn_defense_points_layer(
            self.iface
        )

        add_cbrn_contaminated_areas_layer(
            self.iface
        )

        add_safe_distance_zones_layer(
            self.iface
        )

        add_dose_rate_contours_layer(
            self.iface
        )

    def create_field_fortification(self):
        """
        Add the Field Fortification (Points) and (Lines) layers - Table
        H-XX (MIL-STD-2525D Appendix H.5.22), ready for digitizing with
        QGIS's own native tools.

        Affiliation-coloured, not green: the green rule is H.5.21.1's
        own exception for obstacles, and H.5.22 claims nothing like it.
        See field_fortification.py's own docstring for the three
        proportions the standard leaves unnumbered here.
        """

        add_field_fortification_points_layer(
            self.iface
        )

        add_field_fortification_lines_layer(
            self.iface
        )

    def create_obstacle_control_measures(self):
        """
        Add the Obstacle Control Measures (Points) and (Areas) layers -
        Table H-XIX (MIL-STD-2525D Appendix H.5.21), ready for
        digitizing with QGIS's own native tools.

        Obstacles draw GREEN rather than in the affiliation hue every
        other control measure uses, with a per-feature Colour field to
        switch any one to black. Points (batch B1) and areas (batch B2)
        exist so far; the table's large line family arrives in later
        batches - see obstacle_control_measures.py's own docstring for
        the full inventory and batch plan.
        """

        add_obstacle_control_measures_points_layer(
            self.iface
        )

        add_obstacle_control_measures_areas_layer(
            self.iface
        )

        add_obstacle_control_measures_minefields_layer(
            self.iface
        )

        add_obstacle_control_measures_lines_layer(
            self.iface
        )


    def create_target_acquisition_control_measures(self):
        """
        Add a Target Acquisition Control Measures (Areas) layer
        (Artillery Target Intelligence Zone, Call For Fire Zone,
        Censor Zone, Critical Friendly Zone, Dead Space Area, Sensor
        Zone, Target Build-up Area, Target Value Area, Zone of
        Responsibility, Blue Kill Box, Purple Kill Box - MIL-STD-2525D
        Appendix H.5.20, Table H-XVIII), ready for digitizing with
        QGIS's own native editing tools. Both Weapon/Sensor Range Fan
        variants are not built - see that module's own docstring.
        """

        add_target_acquisition_control_measures_areas_layer(
            self.iface
        )

        add_range_fans_layer(
            self.iface
        )


    def create_sustainment_points(self):
        """
        Add a "Sustainment Points" layer - Table H-XXII's own sixteen
        drawable point symbols (MIL-STD-2525D Appendix H.5.24), ready
        for placing with QGIS's own native point editing tools.
        """

        add_sustainment_points_layer(
            self.iface
        )


    def create_supply_points(self):
        """
        Add Table H-XXIII's own three layers (MIL-STD-2525D Appendix
        H.5.25): "Supply Points", its eighteen point symbols - general
        and medical supply points plus the NATO and US supply classes;
        "Supply Routes (Lines)", the Main and Alternate Supply Routes
        with their traffic variants; and "Sustainment Areas", the
        table's own seven area symbols. Only that table's two convoy
        lines are not built; see supply_points.py's own docstring.
        """

        add_supply_points_layer(
            self.iface
        )

        add_supply_routes_lines_layer(
            self.iface
        )

        add_sustainment_areas_layer(
            self.iface
        )


    def create_mission_task_points(self):
        """
        Add the Mission Task layers - Points (Destroy, Interdict and
        Neutralize, the three of Table H-XXIV's 29 rows that are point
        symbols (MIL-STD-2525D Appendix H.5.26). The other 26 are
        multi-anchor constructions; see
        mission_task_control_measures.py's own docstring.
        """

        add_mission_task_points_layer(
            self.iface
        )

        add_mission_task_lines_layer(
            self.iface
        )


    def create_intelligence_control_measures(self):
        """
        Add an Intelligence Control Measures (Lines) layer - the
        Intelligence Coordination Line, the only drawable entry in
        Table H-XXV (MIL-STD-2525D Appendix H.5.27). Constructed
        exactly like the Battlefield and Restrictive Fire Lines of
        Table H-XVI; see intelligence_control_measures.py's own
        docstring.
        """

        add_intelligence_control_measures_lines_layer(
            self.iface
        )


    def _on_map_tool_changed(self, new_tool, old_tool):
        """
        Keep each checkable tool's toolbar button in sync when some
        OTHER tool (e.g. Pan, Identify, or one of this plugin's own
        other tools) replaces it - QGIS map tools don't un-check
        their own toolbar button automatically when deselected this
        way.
        """

        for action, tool in (
            (self.coordinate_probe_action, self.coordinate_probe_tool),
            (self.bearing_range_action, self.bearing_range_tool),
            (self.line_of_sight_action, self.line_of_sight_tool),
            (self.viewshed_action, self.viewshed_tool),
        ):

            if action is not None and new_tool is not tool:

                action.setChecked(
                    False
                )


    # ------------------------------------------------------------------
    # Print layout grid frame
    # ------------------------------------------------------------------

    def on_layout_designer_opened(self, designer):
        """
        Add a small "grid frame" toolbar, and the Military Layout
        Settings dock panel, to a newly-opened Layout Designer
        window.
        """

        layout = designer.layout()

        if layout is None:
            return

        map_item = None

        for item in layout.items():

            if isinstance(item, QgsLayoutItemMap):
                map_item = item
                break

        if map_item is None:
            return

        toolbar = self._build_grid_frame_toolbar(
            designer,
            map_item
        )

        settings_action = self._build_layout_settings_panel(
            designer,
            layout
        )

        toolbar.addAction(
            settings_action
        )

        designer.window().addToolBar(
            toolbar
        )

        self.layout_toolbars[designer] = toolbar


    def _build_grid_frame_toolbar(self, designer, map_item):

        """
        Adds/removes the native QGIS map-grid border (ticks +
        coordinate annotations) on this layout's map item, at
        whatever sub-grid spacing is currently selected on the
        canvas. Returns the toolbar without adding it to the
        window yet - on_layout_designer_opened() adds the Layout
        Settings toggle action to it first.
        """

        toolbar = QToolBar(
            'Військова координатна рамка'
        )

        toolbar.setObjectName(
            f"{PLUGIN_ID}_layout"
        )

        add_action = QAction(
            QIcon(
                str(
                    self.plugin_dir / "icons" / "sub_grid.svg"
                )
            ),
            'Додати координатну рамку',
            designer.window()
        )

        add_action.setToolTip(
            'Додати штрихи й координатні підписи на рамці карти з автоматичним кроком відповідно до масштабу друку та приховати внутрішні підписи додаткової сітки в цьому макеті'
        )

        add_action.triggered.connect(
            lambda: add_grid_frame(
                map_item
            )
        )

        toolbar.addAction(
            add_action
        )

        remove_action = QAction(
            QIcon(
                str(
                    self.plugin_dir / "icons" / "clear_grid.svg"
                )
            ),
            'Видалити координатну рамку',
            designer.window()
        )

        remove_action.setToolTip(
            'Видалити координатну рамку цього макета'
        )

        remove_action.triggered.connect(
            lambda: remove_grid_frame(
                map_item
            )
        )

        toolbar.addAction(
            remove_action
        )

        insert_symbol_action = QAction(
            QIcon(
                str(
                    self.plugin_dir / "icons" / "insert_symbol.svg"
                )
            ),
            'Вставити умовний знак',
            designer.window()
        )

        insert_symbol_action.setToolTip(
            'Вставити умовний знак MIL-STD-2525/APP-6 на сторінку макета'
        )

        insert_symbol_action.triggered.connect(
            lambda: self._insert_symbol(
                designer
            )
        )

        toolbar.addAction(
            insert_symbol_action
        )

        return toolbar


    def _insert_symbol(self, designer):

        """
        U-1: places one MIL-STD-2525/APP-6 symbol on the currently
        open layout as a QgsLayoutItemPicture, via InsertSymbolDialog.
        A layout page has no features/attribute table to hold entity/
        affiliation the way a canvas layer's own ValueMap fields do,
        so the symbol is baked once into a static SVG picture at
        insertion time - see layout_symbol_dialog.py's own docstring
        for why this is deliberately narrower than a canvas layer's
        amplifier set. Placed at a fixed default position/size; like
        any other layout item, it can be dragged and resized
        afterwards in the designer.
        """

        layout = designer.layout()

        if layout is None:
            return

        dialog = InsertSymbolDialog(designer.window())

        if dialog.exec() != QDialog.DialogCode.Accepted:
            return

        picture = QgsLayoutItemPicture(layout)

        picture.setPicturePath(
            dialog.picture_path(),
            QgsLayoutItemPicture.Format.FormatSVG
        )

        picture.setResizeMode(
            QgsLayoutItemPicture.ResizeMode.ZoomResizeFrame
        )

        layout.addLayoutItem(
            picture
        )

        picture.attemptResize(
            QgsLayoutSize(
                20,
                20,
                QgsUnitTypes.LayoutUnit.LayoutMillimeters
            )
        )

        picture.attemptMove(
            QgsLayoutPoint(
                10,
                10,
                QgsUnitTypes.LayoutUnit.LayoutMillimeters
            ),
            useReferencePoint=False,
            page=0
        )

        picture.setId(
            dialog.entity_label()
        )

        picture.refreshPicture()


    def _build_layout_settings_panel(self, designer, layout):

        """
        Military Layout Settings dock panel - lets this specific
        layout's page size/orientation/scale/heading/
        classification be changed in place (calling
        layout.update_layout()) rather than only at creation time
        via New Military Layout. Returns a checkable action that
        shows/hides it, for the caller to place on a toolbar.
        """

        panel = LayoutOptionsPanel(
            self.iface,
            layout,
            designer.window()
        )

        designer.window().addDockWidget(
            Qt.DockWidgetArea.RightDockWidgetArea,
            panel
        )

        self.layout_panels[designer] = panel

        # The panel is shown by default when the designer opens,
        # but closing it (its dock title bar's own close button)
        # previously left no way to bring it back short of
        # reopening the whole designer window.
        # QDockWidget.toggleViewAction() is a checkable action
        # that's already wired to the dock's own visibility, so
        # this just needs an icon and a home on the toolbar.
        settings_action = panel.toggleViewAction()

        settings_action.setIcon(
            QIcon(
                str(
                    self.plugin_dir / "icons" / "layout_settings.svg"
                )
            )
        )

        settings_action.setToolTip(
            'Показати або приховати панель налаштувань військового макета'
        )

        return settings_action


    def on_layout_designer_closed(self, designer):
        """
        Drop our references when a Layout Designer window closes -
        the toolbar and dock panel are both Qt children of that
        window and are cleaned up by Qt when the window goes away.
        """

        self.layout_toolbars.pop(
            designer,
            None
        )

        self.layout_panels.pop(
            designer,
            None
        )


    def show_user_guide(self):
        """
        Open the bundled HTML user guide in the system web browser.

        A browser rather than a dock inside QGIS: the guide unpacks
        itself with JavaScript, which QTextBrowser cannot run, and
        neither QtWebKit nor QtWebEngine is dependably present across
        QGIS 3 and QGIS 4 builds. It is a local file, so it opens the
        same on an air-gapped machine.
        """

        guide = self.plugin_dir / USER_GUIDE_PATH

        if guide.is_file() and QDesktopServices.openUrl(
            QUrl.fromLocalFile(str(guide))
        ):

            return

        QMessageBox.warning(
            self.iface.mainWindow(),
            PLUGIN_NAME,
            "The user guide could not be opened.\n\n"
            f"It should be at:\n{guide}\n\n"
            "If the file is there, open it in any web browser. "
            "If it is missing, reinstall the plugin."
        )


    def show_about(self):
        """
        Show plugin information.
        """

        QMessageBox.information(
            self.iface.mainWindow(),
            PLUGIN_NAME,
            f"""
{PLUGIN_NAME}
Версія {PLUGIN_VERSION}

Інструменти військової картографії для QGIS: тактичні умовні знаки
MIL-STD-2525D/E та APP-6D/E, координати MGRS і аналіз рельєфу.
Працює повністю автономно, без зовнішніх сервісів.

Copyright © 2026 Praveen Kumar

Ліцензія GNU GPL версії 2 або новішої.


Сторонні компоненти:

Модуль перетворення координат MGRS
Alex Bruy - Boundless / Planet Federal / Planet Inc.
GNU GPL v2 or later

Milsymbol (Побудова знаків MIL-STD-2525 / APP-6)
Måns Beckman - www.spatialillusions.com
MIT License

Світова магнітна модель (магнітне схилення)
Justin Myers - pyGeoMag
MIT License

Джерело методики створення сітки MGRS
Klas Karlsson - QGIS Model Repository
Creative Commons Zero (CC0)

React (відображення посібника користувача)
Meta Platforms, Inc. and affiliates
MIT License


Повні відомості про авторство та тексти ліцензій:

README.md
THIRD_PARTY_NOTICES.md
LICENSE
            """
        )