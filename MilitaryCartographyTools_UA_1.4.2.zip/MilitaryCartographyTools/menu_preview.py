"""Browse actual symbol renderers in a gallery beside the original menu actions."""
from collections import OrderedDict
from dataclasses import dataclass
import unicodedata

from qgis.core import (
    QgsMapSettings, QgsMapRendererCustomPainterJob,
    QgsVectorLayerUtils, QgsVariantUtils, QgsCoordinateReferenceSystem,
)
from qgis.PyQt.QtCore import QObject, QEvent, QTimer, Qt, QSize
from qgis.PyQt.QtGui import QColor, QIcon, QImage, QPainter, QPixmap, QBitmap, QRegion
from qgis.PyQt.QtWidgets import (
    QFrame, QLabel, QLineEdit, QListWidget, QListWidgetItem, QListView,
    QVBoxLayout, QAbstractItemView,
)
from . import ukrainian_catalog as catalog, ukrainian_workflow as ukrainian
from . import notation_preview as preview, user_png_symbols as png, free_zones
from .military_symbology.edition import current_edition, edition_label, layer_name_for
from .military_symbology import maritime_control_measures as maritime

ICON_SIZE = QSize(160, 94)
RENDER_SIZE = QSize(320, 188)
TILE_SIZE = QSize(180, 150)
ROLE = Qt.ItemDataRole.UserRole


def search_key(text):
    text = unicodedata.normalize('NFKC', str(text)).casefold()
    return text.translate(str.maketrans({'’': "'", 'ʼ': "'", '`': "'"}))


@dataclass(frozen=True)
class Entry:
    slot: str
    field: str
    value: object
    title: str
    layer_title: str
    group_value: object = None


class Catalogue:
    """Private layers only: browsing must not register layers or dirty the project."""
    def __init__(self):
        self.layers = OrderedDict()
        self.groups = OrderedDict()
        self.images = OrderedDict()

    def layer(self, slot, mode, standard):
        key = (slot, mode, standard)
        if key in self.layers:
            self.layers.move_to_end(key)
            return self.layers[key]
        if slot == 'free_zones':
            layer = free_zones.build_layer()
        elif slot == 'maritime_control_measures/maritime_control_measures_points_layer':
            layer = maritime.create_maritime_control_measures_points_layer(register_lookup=False)
            ukrainian.localize_layer(layer)
            if mode == 'vkdp':
                layer = ukrainian.adapt_layer(layer, slot, 'preview', '', None, register_search=False)
        else:
            builder, domain = catalog.BUILDERS[slot]
            layer = builder(edition=standard) if domain is not None else builder()
            if mode == 'nato' and domain is not None:
                layer.setName(layer_name_for(layer.name(),standard))
            ukrainian.localize_layer(layer)
            if mode == 'vkdp':
                layer = ukrainian.adapt_layer(layer, slot, 'preview', '', domain, register_search=False)
        if not layer.crs().isValid():
            layer.setCrs(QgsCoordinateReferenceSystem('EPSG:3857'))
        self.layers[key] = layer
        while len(self.layers) > 24:
            self.layers.popitem(last=False)
        return layer

    def entries(self, group, mode, standard):
        key = (group, mode, standard)
        if key in self.groups:
            self.groups.move_to_end(key)
            return self.groups[key]
        result = []
        if group == 'png':
            result = [Entry('png', '', e['key'], e['title'], e['category_title']) for e in png.CATALOG]
        else:
            slots = ['free_zones'] if group == 'free_zones' else catalog.GROUPS[group]
            for slot in slots:
                layer = self.layer(slot, mode, standard)
                field = next((n for n in ('entity', 'measure_type') if n in layer.fields().names()), '')
                choices = []
                if field:
                    setup = layer.editorWidgetSetup(layer.fields().indexFromName(field))
                    values = setup.config().get('map', [])
                    if isinstance(values, dict):
                        values = [values]
                    choices = [(title, value) for row in values for title, value in row.items()
                               if not QgsVariantUtils.isNull(value) and value != '']
                if not choices:
                    choices = [(layer.name(), None)]
                for title, value in choices:
                    group_value = maritime._POINT_ENTITIES[value][0] if slot == 'maritime_control_measures/maritime_control_measures_points_layer' else None
                    caption = layer.name()
                    if group_value is not None:
                        caption += ' · '+maritime.POINT_GROUP_LABELS[group_value]
                    result.append(Entry(slot, field, value, title, caption, group_value))
        self.groups[key] = result
        while len(self.groups) > 32:
            self.groups.popitem(last=False)
        return result

    @staticmethod
    def image_key(entry, mode, standard):
        return (entry.slot, entry.field, type(entry.value).__name__, str(entry.value), mode, standard)

    def cached(self, entry, mode, standard):
        key = self.image_key(entry, mode, standard)
        image = self.images.get(key)
        if image is not None:
            self.images.move_to_end(key)
        return image

    def render(self, entry, mode, standard):
        cached = self.cached(entry, mode, standard)
        if cached is not None:
            return cached
        if entry.slot == 'png':
            image = QImage(png.asset_path(str(entry.value)))
            if image.isNull():
                raise ValueError('Не вдалося відкрити PNG')
            output = QImage(ICON_SIZE, QImage.Format.Format_ARGB32_Premultiplied)
            output.fill(QColor('white'))
            fitted = image.scaled(ICON_SIZE - QSize(12, 12), Qt.AspectRatioMode.KeepAspectRatio,
                                  Qt.TransformationMode.SmoothTransformation)
            painter = QPainter(output)
            painter.drawImage((output.width()-fitted.width())//2, (output.height()-fitted.height())//2, fitted)
            painter.end()
        else:
            layer = self.layer(entry.slot, mode, standard)
            geometry = preview._sample_geometry(layer)
            feature = QgsVectorLayerUtils.createFeature(layer, geometry)
            if entry.field and entry.value is not None:
                feature[entry.field] = entry.value
            if entry.group_value is not None:
                feature['group'] = entry.group_value
            # Range fans have no drawing until a range is entered. These values
            # belong only to the private sample, never to a newly added layer.
            if 'ring1_range' in layer.fields().names():
                feature['ring1_range'] = 60
                if 'ring1_left' in layer.fields().names():
                    feature['ring1_left'] = 30
                    feature['ring1_right'] = 135
            layer.dataProvider().truncate()
            if not layer.dataProvider().addFeatures([feature])[0]:
                raise ValueError('Не вдалося підготувати знак')
            layer.updateExtents()
            dpi = 288.0
            for attempt in range(6):
                settings = QgsMapSettings()
                settings.setLayers([layer])
                settings.setDestinationCrs(layer.crs())
                settings.setExtent(preview._extent(geometry, layer.crs()))
                settings.setOutputSize(RENDER_SIZE)
                settings.setOutputDpi(dpi)
                settings.setBackgroundColor(QColor(255, 255, 255, 0))
                settings.setExpressionContext(preview.map_context(settings,layer))
                image = QImage(RENDER_SIZE, QImage.Format.Format_ARGB32_Premultiplied)
                image.fill(Qt.GlobalColor.transparent)
                painter = QPainter(image)
                job = QgsMapRendererCustomPainterJob(settings, painter)
                try:
                    job.renderSynchronously()
                finally:
                    painter.end()
                if job.errors():
                    raise ValueError('; '.join(e.message for e in job.errors()))
                bounds = QRegion(QBitmap.fromImage(image.createAlphaMask())).boundingRect()
                clipped = not bounds.isEmpty() and (bounds.left() < 5 or bounds.top() < 5
                    or bounds.right() > RENDER_SIZE.width()-6 or bounds.bottom() > RENDER_SIZE.height()-6)
                # Page-sized constructions can be completely outside a small
                # canvas at high DPI; an empty first pass also needs fitting.
                if (not bounds.isEmpty() and not clipped) or dpi <= 30:
                    break
                dpi *= 0.72
            output = QImage(ICON_SIZE, QImage.Format.Format_ARGB32_Premultiplied)
            output.fill(QColor('white'))
            if bounds.isEmpty():
                raise ValueError('За початковими параметрами знак не має видимого зображення')
            cropped = image.copy(bounds.adjusted(-4,-4,4,4).intersected(image.rect()))
            fitted = cropped.scaled(ICON_SIZE-QSize(12,12), Qt.AspectRatioMode.KeepAspectRatio,
                                    Qt.TransformationMode.SmoothTransformation)
            painter = QPainter(output)
            painter.drawImage((output.width()-fitted.width())//2, (output.height()-fitted.height())//2, fitted)
            painter.end()
        self.images[self.image_key(entry, mode, standard)] = output
        while len(self.images) > 512:
            self.images.popitem(last=False)
        return output

    def clear(self):
        self.images.clear()
        self.groups.clear()
        self.layers.clear()


class Gallery(QFrame):
    def __init__(self, owner):
        super().__init__(owner.menu)
        self.owner = owner
        self.setObjectName('mctMenuSymbolGallery')
        self.setFrameShape(QFrame.Shape.StyledPanel)
        self.setAutoFillBackground(True)
        self.title = QLabel('Перегляд умовних знаків', self)
        self.title.setWordWrap(True)
        self.title.setStyleSheet('font-weight:600;')
        self.badge = QLabel(self)
        self.badge.setWordWrap(True)
        self.search = QLineEdit(self)
        self.search.setObjectName('mctMenuSymbolSearch')
        self.search.setPlaceholderText('Пошук знака за назвою…')
        self.search.setClearButtonEnabled(True)
        self.list = QListWidget(self)
        self.list.setObjectName('mctMenuSymbolList')
        self.list.setViewMode(QListView.ViewMode.IconMode)
        self.list.setResizeMode(QListView.ResizeMode.Adjust)
        self.list.setMovement(QListView.Movement.Static)
        self.list.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.list.setIconSize(ICON_SIZE)
        self.list.setGridSize(TILE_SIZE)
        self.list.setWordWrap(True)
        self.list.setTextElideMode(Qt.TextElideMode.ElideRight)
        self.list.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.list.setStyleSheet('QListWidget { background: white; color: #192936; border: 1px solid #b8c1c9; selection-background-color: #cde5f7; selection-color: #102c42; }')
        self.hint = QLabel('Наведіть на категорію ліворуч, щоб переглянути її знаки.', self)
        self.hint.setWordWrap(True)
        self.hint.setStyleSheet('font-size:11px;')
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.addWidget(self.title)
        layout.addWidget(self.badge)
        layout.addWidget(self.search)
        layout.addWidget(self.list, 1)
        layout.addWidget(self.hint)
        self.entries = []
        self.visible_entries = []
        self.context = None
        self.rendered = set()
        self.errors = []
        placeholder = QPixmap(ICON_SIZE)
        placeholder.fill(QColor('#f2f4f6'))
        self.placeholder = QIcon(placeholder)
        self.timer = QTimer(self)
        self.timer.setSingleShot(True)
        self.timer.timeout.connect(self.render_next)
        self.search.textChanged.connect(self.filter_entries)
        self.list.verticalScrollBar().valueChanged.connect(self.schedule)
        self.list.itemSelectionChanged.connect(self.describe_selection)
        self.search.installEventFilter(self)
        self.list.installEventFilter(self)

    def eventFilter(self, obj, event):
        # QMenu otherwise treats Enter from an embedded editor as activation
        # of the highlighted native action, which would add layers while searching.
        if event.type() in (QEvent.Type.KeyPress, QEvent.Type.KeyRelease, QEvent.Type.ShortcutOverride):
            if event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
                event.accept()
                return True
        return False

    def set_entries(self, title, entries, mode, standard):
        self.timer.stop()
        self.entries = entries
        self.context = (mode, standard)
        self.errors = []
        self.title.setText(title.replace('&', ''))
        self.search.blockSignals(True)
        self.search.clear()
        self.search.blockSignals(False)
        self.filter_entries()

    def message(self, title, text):
        self.timer.stop()
        self.context = None
        self.entries = []
        self.visible_entries = []
        self.list.clear()
        self.title.setText(title.replace('&', ''))
        self.badge.clear()
        self.hint.setText(text)
        self.search.setEnabled(False)

    def filter_entries(self, *args):
        self.timer.stop()
        self.rendered.clear()
        self.list.clear()
        terms = search_key(self.search.text()).split()
        self.visible_entries = [e for e in self.entries
            if all(t in search_key(self.entry_search_text(e)) for t in terms)]
        for entry in self.visible_entries:
            item = QListWidgetItem(self.placeholder, entry.title, self.list)
            item.setSizeHint(TILE_SIZE)
            item.setToolTip(entry.title+'\n'+entry.layer_title)
        self.list.doItemsLayout()
        self.search.setEnabled(True)
        if self.context:
            mode, standard = self.context
            caption = preview.MODES[mode] if self.entries and self.entries[0].slot != 'png' else preview.MODES['png']
            if mode == 'nato' and self.entries and self.entries[0].slot not in ('png', 'free_zones'):
                caption += ' · '+edition_label(standard)
            if self.entries and self.entries[0].slot == 'free_zones':
                caption = 'Довільні зони'
            self.badge.setText(caption+'\nТипів: '+str(len(self.visible_entries))+' із '+str(len(self.entries)))
        self.hint.setText('Натисніть пункт меню ліворуч, щоб додати його шари. Лінії та площі показано на умовній геометрії.'
                          if self.visible_entries else 'За цим запитом нічого не знайдено.')
        self.schedule()

    def entry_search_text(self, entry):
        return entry.title+' '+entry.layer_title

    def describe_selection(self):
        row = self.list.currentRow()
        if 0 <= row < len(self.visible_entries):
            entry = self.visible_entries[row]
            self.hint.setText(entry.title+'\n'+entry.layer_title)

    def schedule(self, *args):
        if self.context is not None and self.isVisible():
            self.timer.start(12)

    def render_next(self):
        if self.context is None or not self.isVisible():
            return
        viewport = self.list.viewport().rect()
        for row, entry in enumerate(self.visible_entries):
            if row in self.rendered or not self.list.visualItemRect(self.list.item(row)).intersects(viewport):
                continue
            try:
                image = self.owner.manager.catalogue.render(entry, *self.context)
                self.list.item(row).setIcon(QIcon(QPixmap.fromImage(image)))
            except Exception as error:
                self.errors.append((entry.title, str(error)))
                self.list.item(row).setToolTip(entry.title+'\nПерегляд недоступний: '+str(error))
            self.rendered.add(row)
            self.timer.start(8)
            return

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if hasattr(self, 'timer'):
            self.schedule()


class MenuController(QObject):
    def __init__(self, manager, menu):
        super().__init__(menu)
        self.manager = manager
        self.menu = menu
        self.margins = menu.contentsMargins()
        self.minimum = menu.minimumSize()
        self.tooltips = menu.toolTipsVisible()
        self.base_width = max(menu.sizeHint().width(), self.minimum.width())
        self.panel = Gallery(self)
        self.active = True
        self.current_key = None
        self.pending = None
        self.timer = QTimer(self)
        self.timer.setSingleShot(True)
        self.timer.setInterval(130)
        self.timer.timeout.connect(self.load)
        menu.hovered.connect(self.hover)
        menu.aboutToHide.connect(self.hide)
        menu.installEventFilter(self)
        menu.setToolTipsVisible(False)
        self.reserve_space()

    def reserve_space(self):
        screen = self.menu.screen().availableGeometry()
        self.panel_width = max(240, min(410, screen.width()-self.base_width-24))
        # Keep the same QMenu and QActions. Qt lays native action rectangles
        # inside these margins; the gallery occupies the reserved right side.
        m = self.margins
        self.menu.setContentsMargins(m.left(), m.top(), m.right()+self.panel_width, m.bottom())
        self.menu.setMinimumWidth(self.base_width+self.panel_width)
        self.menu.setMinimumHeight(max(self.minimum.height(), min(590, screen.height()-60)))
        self.position()

    def position(self):
        self.panel.setGeometry(self.menu.width()-self.panel_width-self.margins.right(), self.margins.top(),
                               self.panel_width, self.menu.height()-self.margins.top()-self.margins.bottom())
        self.panel.raise_()

    def eventFilter(self, obj, event):
        if not self.active:
            return False
        if event.type() == QEvent.Type.Show:
            self.reserve_space()
            self.panel.show()
            self.panel.schedule()
            action = self.menu.activeAction()
            if action is not None:
                self.hover(action)
        elif event.type() == QEvent.Type.Resize:
            self.position()
        return False

    def hover(self, action):
        if not self.active or action not in self.menu.actions():
            return
        mode, standard = self.manager.context()
        group = self.manager.actions.get(action)
        if group is None:
            self.timer.stop()
            self.pending = None
            self.current_key = None
            self.panel.message(action.text(), 'Наведіть на потрібну категорію в підменю.' if action.menu()
                               else 'Оберіть категорію умовних знаків для перегляду.')
            return
        key = (group, mode, standard)
        if key == self.current_key:
            self.panel.schedule()
            return
        self.current_key = None
        self.pending = (action, key)
        self.panel.message(action.text(), 'Готую перегляд…')
        self.timer.start()

    def load(self):
        if not self.active or not self.menu.isVisible() or self.pending is None:
            return
        action, key = self.pending
        try:
            entries = self.manager.catalogue.entries(*key)
            self.current_key = key
            self.panel.set_entries(action.text(), entries, key[1], key[2])
        except Exception as error:
            self.current_key = None
            self.panel.message(action.text(), 'Не вдалося показати перегляд: '+str(error))

    def hide(self):
        self.timer.stop()
        self.pending = None
        self.panel.timer.stop()

    def stop(self):
        self.active = False
        self.hide()
        self.menu.removeEventFilter(self)
        self.menu.hovered.disconnect(self.hover)
        self.menu.aboutToHide.disconnect(self.hide)
        self.menu.setContentsMargins(self.margins)
        self.menu.setMinimumSize(self.minimum)
        self.menu.setToolTipsVisible(self.tooltips)
        self.panel.hide()
        self.panel.deleteLater()
        self.deleteLater()


class MenuPreviews(QObject):
    def __init__(self, plugin):
        super().__init__(plugin.toolbar)
        self.plugin = plugin
        self.catalogue = Catalogue()
        self.actions = {action: original.__name__ for action, original, dispatch in plugin._png_bindings
                        if original.__name__ in catalog.GROUPS}
        self.actions[plugin._free_zones_action] = 'free_zones'
        main = plugin.group_menus['nato_symbols']
        for action in main.actions():
            if action.text() == 'Мої знаки (PNG)':
                self.actions[action] = 'png'
        self.controllers = [MenuController(self, m) for m in (main, plugin.control_measures_menu)]
        plugin._notation_combo.currentIndexChanged.connect(self.refresh)
        self.edition_actions = plugin.edition_menu.actions()
        for action in self.edition_actions:
            action.triggered.connect(self.refresh)

    def context(self):
        mode = self.plugin._notation_combo.currentData()
        return mode, '2525D' if mode == 'vkdp' else current_edition()

    def refresh(self, *args):
        for controller in self.controllers:
            controller.current_key = None
            if controller.menu.isVisible() and controller.menu.activeAction() is not None:
                controller.hover(controller.menu.activeAction())

    def stop(self):
        self.plugin._notation_combo.currentIndexChanged.disconnect(self.refresh)
        for action in self.edition_actions:
            action.triggered.disconnect(self.refresh)
        for controller in self.controllers:
            controller.stop()
        self.catalogue.clear()
        self.deleteLater()


def install(plugin):
    plugin._menu_preview = MenuPreviews(plugin)


def uninstall(plugin):
    manager = getattr(plugin, '_menu_preview', None)
    if preview.alive(manager):
        manager.stop()
    plugin._menu_preview = None
