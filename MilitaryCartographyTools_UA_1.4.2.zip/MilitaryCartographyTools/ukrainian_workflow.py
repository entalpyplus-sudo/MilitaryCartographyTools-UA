"""Ukrainian symbol-system adapter for the original plugin commands and QGIS workflow."""
import base64,hashlib,json,os,re,threading,uuid
from pathlib import Path
from xml.etree import ElementTree as ET
from qgis.core import (
    QgsProject,QgsVectorLayer,QgsField,QgsFeature,QgsDefaultValue,QgsEditorWidgetSetup,
    QgsExpression,QgsMapLayerStyle,QgsProperty,QgsSymbolLayer,QgsRasterMarkerSymbolLayer,
    QgsMarkerSymbol,QgsRuleBasedRenderer,Qgis,qgsfunction,QgsMessageLog,
    QgsPalLayerSettings,QgsVectorLayerSimpleLabeling,
)
from qgis.PyQt.QtCore import QMetaType
from qgis.PyQt.QtGui import QColor
from . import ukrainian_catalog as catalog,user_png_symbols as png,vkdp_symbols as vk
from .military_symbology.sidc import SYMBOL_SETS
from .military_symbology.symbol_engine import render_symbol_svg,scale_svg_stroke_width,_get_engine
from .military_symbology._control_measure_shared import _AFFILIATION_COLOR_EXPRESSION,default_insert_position
from .core._layer_utils import add_layer_at_default_position
from .localization_uk import localize_layer
from .field_dependencies import configure as configure_dependencies,LOWER_ECHELONS

FLAG='MilitaryCartographyTools/ukrainian_native'
SLOT='MilitaryCartographyTools/ukrainian_slot'
CATEGORY='MilitaryCartographyTools/ukrainian_category'
LOOKUP='MilitaryCartographyTools/ukrainian_lookup'
FORM_MAPS='MilitaryCartographyTools/ukrainian_form_maps'
STYLE_REVISION='MilitaryCartographyTools/ukrainian_style_revision'
ROOT_NAME='Українські позначення — ВКДП'
UA_COLOUR=("CASE WHEN \"affiliation\" = 'friend' THEN color_rgb(0, 0, 255) "
    "WHEN \"affiliation\" = 'hostile' THEN color_rgb(255, 0, 0) "
    "WHEN \"affiliation\" = 'neutral' THEN color_rgb(165, 85, 35) "
    "WHEN \"affiliation\" = 'unknown' THEN color_rgb(255, 255, 0) ELSE color_rgb(0, 0, 0) END")
FRAMED={value for key,value in SYMBOL_SETS.items() if key not in ('control_measure','activities','mine_warfare','cyberspace')}
_cache={}; _cache_lock=threading.Lock(); _lookup_keys={}
EXTRA=[
 ('ua_higher','M — вище формування',str,''),('ua_command_label','Напис під пунктом управління',str,''),
 ('ua_reinforcement','F — посилення / послаблення',str,''),('ua_staff','G — штабний коментар',str,''),
 ('ua_info','H — додаткова інформація',str,''),('ua_dtg','W — дата й час',str,''),
 ('ua_source','Джерело інформації',str,''),('ua_uncertain','Інформація потребує перевірки',bool,False),
 ('ua_effect','Стан ураження',str,'normal'),('ua_effect_side','Ким завдано ураження',str,'friend'),
 ('ua_monochrome','Чорно-білий вигляд',bool,False),('notes','Примітка',str,''),
]

def native(layer):
    return isinstance(layer,QgsVectorLayer) and bool(layer.customProperty(FLAG,False))

def _value(feature,key,default=''):
    if feature is None or feature.fields().indexFromName(key)<0: return default
    value=feature[key]
    return default if value is None or str(value)=='NULL' else value

def _render(values,feature=None):
    sidc=str(values[0]); detailed=len(values)>1; framed=sidc[4:6] in FRAMED
    extras={key:_value(feature,key,default) for key,_,_,default in EXTRA} if detailed and framed else {}
    options={}
    if detailed and values[1]: options[str(values[2]) if len(values)>2 and values[2] else 'uniqueDesignation']=str(values[1])
    if len(values)>3 and values[3]: options['monoColor']=str(values[3])
    if len(values)>6 and values[5] and values[6]: options[str(values[6])]=str(values[5])
    # General control measures use the colours of section 2.2, including
    # brown for neutral forces. An explicit obstacle colour takes priority.
    if sidc[4:6]==SYMBOL_SETS['control_measure'] and 'monoColor' not in options:
        options['monoColor']={'3':'#0000ff','6':'#ff0000','4':'#a55523','1':'#ffff00'}.get(sidc[3],'black')
    if feature is not None and feature.fields().indexFromName('colour')>=0 and _value(feature,'colour')!='black':
        if _value(feature,'affiliation')=='hostile' or _value(feature,'measure_type') in ('minefield_known_enemy','minefield_suspected'):
            options['monoColor']='#ff0000'
    if extras.get('ua_reinforcement') and (sidc[4:6]!='10' or str(_value(feature,'echelon','')) not in LOWER_ECHELONS):
        extras['ua_reinforcement']=''
    for field,option in [('ua_higher','higherFormation'),('ua_reinforcement','reinforcedReduced'),
        ('ua_staff','staffComments'),('ua_info','additionalInformation'),('ua_dtg','dtg')]:
        if extras.get(field): options[option]=str(extras[field])
    if extras.get('ua_source'): options['dtg']=' '.join([str(extras['ua_source']),str(extras.get('ua_dtg',''))]).strip()
    if extras.get('ua_monochrome'): options.update({'monoColor':'black','fill':False})
    stroke=float(values[4]) if len(values)>4 and values[4] else 1.3
    key=hashlib.sha256(json.dumps([sidc,options,extras,stroke],ensure_ascii=False,sort_keys=True).encode()).hexdigest()
    with _cache_lock:
        if key in _cache: return _cache[key]
    render_options=options
    recolour=None
    # milsymbol's monoColor path removes both circles of Plan Ship (210100).
    # Keep its native geometry and recolour the existing paints instead.
    if sidc[4:6]==SYMBOL_SETS['control_measure'] and sidc[10:16]=='210100' and options.get('monoColor'):
        render_options=dict(options); recolour=render_options.pop('monoColor')
    node=ET.fromstring(scale_svg_stroke_width(render_symbol_svg(sidc,render_options or None),stroke))
    if recolour:
        for child in node.iter():
            for paint in ('fill','stroke'):
                if child.attrib.get(paint) not in (None,'none','transparent'):
                    child.set(paint,recolour)
    if not framed:
        for child in node.iter():
            if child.tag=='{'+vk.NS+'}text': child.set('fill','black')
    x,y,w,h=map(float,node.attrib['viewBox'].split())
    frame_width=w; ax=x+w/2; ay=y+h/2
    for child in node.iter():
        if child.attrib.get('fill') in vk.FILLS.values():
            side=next((name for name,identity in vk.IDENTITIES.items() if identity==sidc[3]),'friend')
            child.set('fill',vk.FILLS[side])
    if framed:
        js='JSON.stringify((function(){var s=new ms.Symbol('+json.dumps(sidc)+','+json.dumps(options)+');return {anchor:s.getAnchor(),size:s.getSize(),metadata:s.getMetadata(),svg:s.asSVG()};})())'
        result=_get_engine().evaluate(js)
        if result.isError(): raise ValueError(result.toString())
        metadata=json.loads(result.toString()); bounds=(metadata['metadata'].get('baseGeometry') or {}).get('bbox')
        if bounds and bounds['x2']>bounds['x1']:
            frame_width=bounds['x2']-bounds['x1']
            ox,oy,ow,oh=map(float,ET.fromstring(metadata['svg']).attrib['viewBox'].split())
            ax=ox+metadata['anchor']['x']*ow/metadata['size']['width']; ay=oy+metadata['anchor']['y']*oh/metadata['size']['height']
            def text(px,py,value,anchor='middle'):
                t=ET.SubElement(node,'{'+vk.NS+'}text',{'x':str(px),'y':str(py),'font-family':'Arial','font-size':'28','text-anchor':anchor,'fill':'black'})
                t.text=str(value); return t
            if extras.get('ua_command_label') and bool(_value(feature,'headquarters',False)):
                text((bounds['x1']+bounds['x2'])/2,bounds['y2']+30,extras['ua_command_label']).set('font-weight','bold')
                h=max(y+h,bounds['y2']+38)-y
            if extras.get('ua_uncertain'):
                text(bounds['x2']+16,bounds['y1']-8,'?','start').set('fill','black' if extras.get('ua_monochrome') else '#0000ff')
                right=max(x+w,bounds['x2']+52); top=min(y,bounds['y1']-45)
                w=right-x; h=y+h-top; y=top
            effect=extras.get('ua_effect','normal')
            if effect in ('destroyed','damaged','planned_destroyed'):
                b=bounds; colour='black' if extras.get('ua_monochrome') else '#ff0000' if extras.get('ua_effect_side')=='hostile' else '#0000ff'
                for i,(a,b_,c,d) in enumerate([(b['x1']-8,b['y1']-8,b['x2']+8,b['y2']+8),(b['x1']-8,b['y2']+8,b['x2']+8,b['y1']-8)]):
                    attrs={'x1':str(a),'y1':str(b_),'x2':str(c),'y2':str(d),'stroke':colour,'stroke-width':'4'}
                    if effect=='planned_destroyed' or (effect=='damaged' and i==1): attrs['stroke-dasharray']='9,6'
                    ET.SubElement(node,'{'+vk.NS+'}line',attrs)
                left=min(x,bounds['x1']-12); top=min(y,bounds['y1']-12)
                right=max(x+w,bounds['x2']+12); bottom=max(y+h,bounds['y2']+12); x,y,w,h=left,top,right-left,bottom-top
            rx=max(ax-x,x+w-ax,1); ry=max(ay-y,y+h-ay,1); x,y,w,h=ax-rx,ay-ry,2*rx,2*ry
            node.set('viewBox',f'{x} {y} {w} {h}'); node.set('width',str(w)); node.set('height',str(h))
    data=ET.tostring(node,encoding='utf-8',xml_declaration=True)
    output={'path':'base64:'+base64.b64encode(data).decode(),'width':w,'frame_width':frame_width,'svg':data,'anchor':(ax,ay),'viewbox':(x,y,w,h)}
    with _cache_lock:
        _cache[key]=output
        if len(_cache)>1024: _cache.pop(next(iter(_cache)))
    return output

@qgsfunction('mct_ua_sidc_svg',group='ВКДП — умовні знаки')
def mct_ua_sidc_svg(values,feature=None,parent=None):
    try: return _render(values,feature)['path']
    except Exception as error:
        if parent is not None: parent.setEvalErrorString('ВКДП: '+str(error))
        return ''

@qgsfunction('mct_ua_sidc_svg_width',group='ВКДП — умовні знаки')
def mct_ua_sidc_svg_width(values,feature=None,parent=None):
    try:
        result=_render(values,feature)
        return result['frame_width'] if len(values)==1 else result['width']
    except Exception as error:
        if parent is not None: parent.setEvalErrorString('ВКДП: '+str(error))
        return 0.0

@qgsfunction(args='auto',group='ВКДП — умовні знаки')
def mct_ua_png_path(key,feature,parent): return png.asset_path(str(key))

FUNCTIONS=[mct_ua_sidc_svg,mct_ua_sidc_svg_width,mct_ua_png_path]

def _transform(value,label=False,obstacle_hostile=''):
    value=value.replace('mct_sidc_svg_width(','mct_ua_sidc_svg_width(').replace('mct_sidc_svg(','mct_ua_sidc_svg(')
    value=value.replace(_AFFILIATION_COLOR_EXPRESSION,'color_rgb(0, 0, 0)' if label else UA_COLOUR)
    # Some SVG glyphs use CSS rgb() strings instead of QGIS colour values.
    value=re.sub(r'(WHEN\s+"affiliation"\s*=\s*\'neutral\'\s+THEN\s*)\'rgb\(0,\s*255,\s*0\)\'',r"\1'rgb(165,85,35)'",value)
    if label:
        value=re.sub(r'color_rgb\(\s*0,\s*155,\s*0\s*\)','color_rgb(0, 0, 0)',value)
    elif obstacle_hostile:
        from .military_symbology.obstacle_control_measures import _AREA_OUTLINE_COLOR_EXPRESSION,_POINT_MONO_COLOR_EXPRESSION
        value=value.replace(_AREA_OUTLINE_COLOR_EXPRESSION,
            'CASE WHEN "colour" = \'black\' THEN color_rgb(0, 0, 0) WHEN '+obstacle_hostile+
            ' THEN color_rgb(255, 0, 0) ELSE color_rgb(0, 155, 0) END')
        value=value.replace(_POINT_MONO_COLOR_EXPRESSION,
            'CASE WHEN "colour" = \'black\' THEN \'rgb(0,0,0)\' WHEN '+obstacle_hostile+
            ' THEN \'rgb(255,0,0)\' ELSE \'rgb(0,155,0)\' END')
    value=value.replace('"echelon" != \'\'','"echelon" NOT IN (\'\',\'unspecified\')')
    if not label:
        value=value.replace('color_rgb(0, 255, 0)','color_rgb(0, 155, 0)')
        if value=='0,255,0,255': value='0,155,0,255'
    return value

def adapt_style(layer):
    # QGIS's full style XML round-trip converts empty ValueMap keys to NULL.
    # Only rendering/labels are adapted; preserve native form configurations.
    setups=[layer.editorWidgetSetup(i) for i in range(len(layer.fields()))]; form=layer.editFormConfig()
    obstacle_hostile=''
    if layer.fields().indexFromName('colour')>=0:
        obstacle_hostile='"affiliation" = \'hostile\''
        if layer.fields().indexFromName('measure_type')>=0:
            obstacle_hostile+=' OR "measure_type" IN (\'minefield_known_enemy\',\'minefield_suspected\')'
    style=QgsMapLayerStyle(); style.readFromLayer(layer); root=ET.fromstring(style.xmlData())
    for section in [root.find('renderer-v2'),root.find('labeling')]:
        if section is None: continue
        for node in section.iter():
            for key,value in list(node.attrib.items()): node.set(key,_transform(value,section.tag=='labeling',obstacle_hostile))
            if node.text: node.text=_transform(node.text,section.tag=='labeling',obstacle_hostile)
    style=QgsMapLayerStyle(ET.tostring(root,encoding='unicode')); style.writeToLayer(layer)
    for i,setup in enumerate(setups): layer.setEditorWidgetSetup(i,setup)
    layer.setEditFormConfig(form)
    labeling=layer.labeling().clone() if layer.labeling() else None
    def black_text(settings):
        fmt=settings.format(); fmt.setColor(QColor('black')); settings.setFormat(fmt)
        settings.dataDefinedProperties().setProperty(QgsPalLayerSettings.Property.Color,QgsProperty.fromValue(QColor('black')))
        return settings
    if labeling is not None:
        if labeling.type()=='simple': labeling=QgsVectorLayerSimpleLabeling(black_text(labeling.settings()))
        elif labeling.type()=='rule-based':
            def visit(rule):
                if rule.settings() is not None: rule.setSettings(black_text(rule.settings()))
                for child in rule.children(): visit(child)
            visit(labeling.rootRule())
        layer.setLabeling(labeling)

def configure_obstacle_colours(layer):
    index=layer.fields().indexFromName('colour')
    if index<0: return
    layer.setFieldAlias(index,'Колір загороджень')
    layer.setEditorWidgetSetup(index,vk.value_map({'green':'За належністю','black':'Чорний'}))

def lookup_layer():
    project=QgsProject.instance()
    found=next((l for l in project.mapLayers().values() if l.customProperty(LOOKUP,False) and l.isValid()),None)
    if found is not None: return found
    layer=QgsVectorLayer('None','Довідник українських позначень','memory')
    layer.dataProvider().addAttributes([QgsField(k,QMetaType.Type.QString) for k in ['list_id','code','label']]); layer.updateFields()
    layer.setCustomProperty(LOOKUP,True); layer.setCustomProperty('skipMemoryLayersCheck',True); project.addMapLayer(layer,False)
    return layer

def configure_search(layer,maps):
    if not maps: return
    lookup=lookup_layer() if 'ua_png_key' in maps else None
    known=_lookup_keys.setdefault(lookup.id(),{(str(f['list_id']),str(f['code'])) for f in lookup.getFeatures()}) if lookup is not None else set()
    rows=[]
    for field,labels in maps.items():
        index=layer.fields().indexFromName(field)
        if index<0: continue
        if field!='ua_png_key':
            if layer.editorWidgetSetup(index).type()!='ValueMap':
                layer.setEditorWidgetSetup(index,QgsEditorWidgetSetup('ValueMap',{'map':[{caption:code} for caption,code in labels]}))
            continue
        list_id='user_png_catalog' if field=='ua_png_key' else str(layer.customProperty(SLOT,''))+':'+field
        for caption,code in labels:
            if (list_id,str(code)) not in known:
                f=QgsFeature(lookup.fields()); f.setAttributes([list_id,str(code),str(caption)]); rows.append(f); known.add((list_id,str(code)))
        layer.setEditorWidgetSetup(layer.fields().indexFromName(field),QgsEditorWidgetSetup('ValueRelation',{
            'Layer':lookup.id(),'Key':'code','Value':'label','AllowNull':any(str(code)=='' for _,code in labels),
            'OrderByValue':True,'UseCompleter':True,'FilterExpression':'"list_id" = '+QgsExpression.quotedString(list_id),
        }))
    if rows and lookup is not None: lookup.dataProvider().addFeatures(rows)
    layer.setCustomProperty(FORM_MAPS,json.dumps(maps,ensure_ascii=False))

def restore_forms(*args):
    _lookup_keys.clear()
    for layer in list(QgsProject.instance().mapLayers().values()):
        if native(layer):
            if layer.customProperty(STYLE_REVISION,0)!=3:
                adapt_style(layer); layer.setCustomProperty(STYLE_REVISION,3)
            configure_obstacle_colours(layer)
            maps=layer.customProperty(FORM_MAPS,'')
            if maps: configure_search(layer,json.loads(maps))
            if layer.customProperty(SLOT,'')=='land_layer/land_unit_layer':
                index=layer.fields().indexFromName('entity')
                if index>=0:
                    setup=layer.editorWidgetSetup(index); config=setup.config(); values=config.get('map',[])
                    entries=[values] if isinstance(values,dict) else values
                    if setup.type()=='ValueMap' and not any('infantry_amphibious' in item.values() for item in entries):
                        if isinstance(values,dict): values=dict(values); values['Амфібійна піхота']='infantry_amphibious'
                        else: values=list(values)+[{'Амфібійна піхота':'infantry_amphibious'}]
                        config['map']=values; layer.setEditorWidgetSetup(index,QgsEditorWidgetSetup('ValueMap',config))
            form=layer.editFormConfig()
            names={element.name() for element in form.invisibleRootContainer().children()}
            if form.layout()==Qgis.AttributeFormLayout.TabLayout and names and names<={'Знак','Підписи','Параметри','Власний PNG'}:
                form.setLayout(Qgis.AttributeFormLayout.GeneratedLayout); layer.setEditFormConfig(form)
            if layer.fields().indexFromName('ua_effect')>=0:
                index=layer.fields().indexFromName('affiliation')
                if index>=0:
                    setup=layer.editorWidgetSetup(index); choices=setup.config().get('map',{})
                    entries=[choices] if isinstance(choices,dict) else choices
                    codes={code for entry in entries for code in entry.values()}
                    if setup.type()=='ValueMap' and codes<=set(vk.SIDES):
                        layer.setEditorWidgetSetup(index,vk.value_map(vk.SIDES))
            configure_dependencies(layer)

def _add_fields(layer,definitions):
    types={str:QMetaType.Type.QString,bool:QMetaType.Type.Bool,float:QMetaType.Type.Double}
    missing=[QgsField(k,types[t]) for k,_,t,_ in definitions if layer.fields().indexFromName(k)<0]
    if missing: layer.dataProvider().addAttributes(missing); layer.updateFields()
    for key,label,kind,default in definitions:
        index=layer.fields().indexFromName(key); layer.setFieldAlias(index,label)
        value='false' if default is False else str(default) if isinstance(default,(int,float)) else QgsExpression.quotedString(default)
        layer.setDefaultValueDefinition(index,QgsDefaultValue(value))
        if kind is bool: layer.setEditorWidgetSetup(index,QgsEditorWidgetSetup('CheckBox',{}))

def adapt_layer(layer,slot,category,prefix,domain,*,register_search=True):
    layer.setName(layer.name()+' (ВКДП)')
    layer.setCustomProperty(FLAG,True); layer.setCustomProperty(SLOT,slot); layer.setCustomProperty(CATEGORY,category)
    layer.setCustomProperty('MilitaryCartographyTools/notation_mode','vkdp')
    layer.setCustomProperty('MilitaryCartographyTools/vkdp_reference',vk.REF)
    adapt_style(layer)
    layer.setCustomProperty(STYLE_REVISION,3)
    configure_obstacle_colours(layer)
    maps={}
    for i,field in enumerate(layer.fields()):
        setup=layer.editorWidgetSetup(i)
        if field.name() in ('entity','measure_type') and setup.type()=='ValueMap':
            values=setup.config().get('map',[])
            if isinstance(values,dict): values=[values]
            maps[field.name()]=[(caption,code) for entry in values for caption,code in entry.items()]
    if layer.fields().indexFromName('echelon')>=0:
        index=layer.fields().indexFromName('echelon'); setup=layer.editorWidgetSetup(index)
        entries=setup.config().get('map',{}); entries=[entries] if isinstance(entries,dict) else entries
        # Keep the original keys: line renderers use an empty key for no echelon.
        labels={code:vk.ECHELONS.get(code,'Не визначено' if code=='' else label) for entry in entries for label,code in entry.items()}
        if setup.type()=='ValueMap': layer.setEditorWidgetSetup(index,vk.value_map(labels))
    if layer.geometryType()==Qgis.GeometryType.Point:
        if domain and SYMBOL_SETS.get(domain) in FRAMED:
            _add_fields(layer,EXTRA)
            layer.setEditorWidgetSetup(layer.fields().indexFromName('affiliation'),vk.value_map(vk.SIDES))
            for key,labels in [('ua_effect',vk.EFFECTS),('ua_effect_side',{'friend':'Свої','hostile':'Противник'}),
                ('ua_command_label',{'':'Без напису','КП':'КП','КСП':'КСП','ОКП':'ОКП','ПКП':'ПКП'})]:
                layer.setEditorWidgetSetup(layer.fields().indexFromName(key),vk.value_map(labels))
        _add_fields(layer,[('ua_png_key','Власний PNG — замість векторного знака',str,''),('ua_png_size_mm','Розмір PNG (мм)',float,18.0)])
        layer.setEditorWidgetSetup(layer.fields().indexFromName('ua_png_size_mm'),QgsEditorWidgetSetup('Range',{'Min':1,'Max':200,'Step':1,'Precision':1,'Style':'SpinBox'}))
        maps['ua_png_key']=[('Векторний знак — за типом об’єкта','')]+[(entry['category_title']+' — '+entry['title'],entry['key']) for entry in png.CATALOG]
        renderer=QgsRuleBasedRenderer.convertFromRenderer(layer.renderer())
        vector=renderer.rootRule().clone(); vector.setFilterExpression('coalesce("ua_png_key",\'\') = \'\''); vector.setLabel('Векторні позначення')
        root=QgsRuleBasedRenderer.Rule(None); root.appendChild(vector); renderer=QgsRuleBasedRenderer(root)
        marker=QgsRasterMarkerSymbolLayer(png.asset_path(png.CATALOG[0]['key']))
        marker.setDataDefinedProperty(QgsSymbolLayer.Property.Name,QgsProperty.fromExpression('mct_ua_png_path("ua_png_key")'))
        marker.setDataDefinedProperty(QgsSymbolLayer.Property.Size,QgsProperty.fromExpression('coalesce("ua_png_size_mm",18)'))
        marker.setDataDefinedProperty(QgsSymbolLayer.Property.Angle,QgsProperty.fromExpression('coalesce("rotation",0)'))
        symbol=QgsMarkerSymbol(); symbol.changeSymbolLayer(0,marker)
        rule=QgsRuleBasedRenderer.Rule(symbol); rule.setFilterExpression('coalesce("ua_png_key",\'\') <> \'\''); rule.setLabel('Власний PNG')
        renderer.rootRule().appendChild(rule); layer.setRenderer(renderer)
    if register_search:
        configure_search(layer,maps)
    for key,label in {'rotation':'Поворот (°)','scale':'Масштаб (%)','ua_png_key':'Власний PNG (необов’язково)'}.items():
        index=layer.fields().indexFromName(key)
        if index>=0: layer.setFieldAlias(index,label)
    configure_dependencies(layer)
    return layer

def add_category(plugin,method):
    """Use the classic insertion and duplicate guards; never start tools or save files."""
    project=QgsProject.instance(); added=[]
    for slot in catalog.GROUPS[method]:
        builder,domain=catalog.BUILDERS[slot]
        layer=builder(); name=layer.name()+' (ВКДП)'; previous_name='ВКДП — '+layer.name()
        exists=project.mapLayersByName(name) or [l for l in project.mapLayersByName(previous_name) if native(l) and l.customProperty(SLOT,'')==slot]
        if exists:
            plugin.iface.messageBar().pushWarning('Інструменти військової картографії',f'Шар «{exists[0].name()}» уже існує. Працюйте з ним у панелі шарів або перейменуйте його для створення іншого.')
            continue
        layer=adapt_layer(layer,slot,method,'',domain)
        add_layer_at_default_position(project,layer,default_insert_position); added.append(layer)
    return added

def add_from_callback(plugin,callback):
    """Keep the existing Ukrainian preset dialog, adapting only the layers it creates."""
    project=QgsProject.instance(); before=set(project.mapLayers()); result=callback()
    for key,layer in list(project.mapLayers().items()):
        if key not in before and isinstance(layer,QgsVectorLayer) and layer.fields().indexFromName('entity')>=0:
            adapt_layer(layer,'presets/'+layer.id(),'presets','','ground_unit')
    return result

def install(plugin):
    for function in FUNCTIONS: QgsExpression.unregisterFunction(function.name()); QgsExpression.registerFunction(function)
    plugin._ua_classic=True; plugin._ua_bindings=[]
    for action,old_png,old_dispatch in plugin._vkdp_bindings:
        original=next(original for a,original,p in plugin._png_bindings if a is action)
        method=getattr(original,'__name__','')
        action.triggered.disconnect(old_dispatch)
        def dispatch(checked=False,selected=method,callback=original,fallback=old_dispatch):
            if not vk.using_profile(): return fallback()
            try:
                return add_category(plugin,selected) if selected in catalog.GROUPS else add_from_callback(plugin,callback)
            except Exception as error:
                import traceback
                QgsMessageLog.logMessage(traceback.format_exc(),'Українські позначення',Qgis.MessageLevel.Critical)
                plugin.iface.messageBar().pushCritical('Українські позначення',str(error))
        action.triggered.connect(dispatch); plugin._ua_bindings.append((action,old_dispatch,dispatch))
    # Keep old renderers available for existing maps, without their extra navigation UI.
    hidden=[plugin._vkdp_menu.menuAction()]+[a for a in plugin.toolbar.actions() if a.text()=='ВКДП — конструктор']
    plugin._ua_hidden_actions=[(a,a.isVisible()) for a in hidden]
    for action,visible in plugin._ua_hidden_actions: action.setVisible(False)
    def sync(*args): plugin.edition_menu.menuAction().setEnabled(not vk.using_profile())
    plugin._ua_sync=sync; plugin._notation_combo.currentIndexChanged.connect(sync)
    plugin._ua_source_actions=[]
    for action in plugin.group_menus['nato_symbols'].actions():
        child=action.menu()
        if child is not None and child.title()=='Режим позначень':
            for choice in child.actions(): choice.triggered.connect(sync); plugin._ua_source_actions.append(choice)
    QgsProject.instance().readProject.connect(restore_forms); restore_forms(); sync()

def uninstall(plugin):
    plugin._ua_classic=False
    for action,old,dispatch in getattr(plugin,'_ua_bindings',[]):
        try: action.triggered.disconnect(dispatch); action.triggered.connect(old)
        except (TypeError,RuntimeError): pass
    plugin._ua_bindings=[]
    try: plugin._notation_combo.currentIndexChanged.disconnect(plugin._ua_sync)
    except (TypeError,RuntimeError,AttributeError): pass
    for choice in getattr(plugin,'_ua_source_actions',[]):
        try: choice.triggered.disconnect(plugin._ua_sync)
        except (TypeError,RuntimeError): pass
    try: QgsProject.instance().readProject.disconnect(restore_forms)
    except (TypeError,RuntimeError): pass
    for action,visible in getattr(plugin,'_ua_hidden_actions',[]): action.setVisible(visible)
    plugin.edition_menu.menuAction().setEnabled(True)
    for function in FUNCTIONS: QgsExpression.unregisterFunction(function.name())
