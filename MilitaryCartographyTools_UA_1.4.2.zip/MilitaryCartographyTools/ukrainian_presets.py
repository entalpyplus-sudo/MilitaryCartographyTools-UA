"""Editable Ukrainian unit templates backed by unchanged MIL-STD/APP-6 codes."""
from qgis.core import (
    QgsProject, QgsField, QgsDefaultValue, QgsExpression, QgsEditorWidgetSetup,
)
from qgis.PyQt.QtCore import QMetaType,QObject,QEvent
from qgis.PyQt.QtGui import QAction
from qgis.PyQt.QtWidgets import (
    QDialog,QComboBox,QLineEdit,QLabel,QFormLayout,QVBoxLayout,QDialogButtonBox,
)
from .military_symbology.sidc import entities_for_edition
from .military_symbology.edition import current_edition,layer_name_for
from .military_symbology.land_layer import (
    _UNIT_ENTITY_LABELS,_UNIT_SECTOR1_LABELS,_UNIT_SECTOR2_LABELS,
)
from .military_symbology._point_symbol_layer import (
    build_single_domain_point_layer,default_insert_position,_ECHELON_LABELS,
)
from .core._layer_utils import add_layer_at_default_position
from .localization_uk import localize_existing_layers

STRUCTURES = {
    'ground': ('Сухопутні війська / загальновійськові підрозділи',
        ['infantry','motorized_infantry','mechanized_infantry','armor','reconnaissance',
         'antitank','field_artillery','field_artillery_self_propelled','mortar','air_defense','engineer','signal']),
    'air_assault': ('Десантно-штурмова тематика',
        ['air_assault','infantry','reconnaissance','unmanned_systems','field_artillery','engineer','medical']),
    'marine': ('Морська піхота / морський десант',
        ['infantry_amphibious','amphibious','infantry','mechanized_infantry','reconnaissance','unmanned_systems','field_artillery','engineer']),
    'territorial': ('Територіальна оборона',
        ['infantry','security','reconnaissance','unmanned_systems','mortar','engineer','medical','supply']),
    'special': ('Сили спеціальних операцій',
        ['special_forces','reconnaissance','sniper','military_intelligence','unmanned_systems','signal','medical']),
    'unmanned': ('Безпілотні та роботизовані системи',
        ['unmanned_systems','surveillance','military_intelligence','signal','maintenance']),
    'ew': ('РЕБ, розвідка та зв’язок',
        ['electronic_warfare','military_intelligence','counter_intelligence','sensor','signal','command_and_control']),
    'guard': ('Національна гвардія України',
        ['infantry','security','reconnaissance','unmanned_systems','military_police','medical','supply']),
    'border': ('Державна прикордонна служба України',
        ['security','reconnaissance','surveillance','sensor','unmanned_systems','signal','medical']),
    'engineer': ('Інженерне забезпечення та РХБ захист',
        ['engineer','engineer_mechanized','mine_clearing','explosive_ordnance_disposal','cbrn']),
    'medical': ('Медичне забезпечення та евакуація',
        ['medical','search_and_rescue','transportation','supply']),
    'logistics': ('Логістика, ремонт і забезпечення',
        ['sustainment','maintenance','supply','transportation','ammunition','petroleum_oil_lubricants','ordnance','quartermaster']),
}

def types_for(structure,edition):
    return [key for key in STRUCTURES[structure][1] if resolve_entity(key,edition) is not None]

def resolve_entity(key,edition):
    source=entities_for_edition('2525D').get('ground_unit',{})
    target=entities_for_edition(edition).get('ground_unit',{})
    if edition=='2525D': return key if key in target else None
    # The E vocabulary renames keys and reuses some old keys for different functions.
    # Match entity codes, never a coincidentally identical name.
    code=source.get(key)
    return next((candidate for candidate,value in target.items() if code is not None and value==code),None)

def create_ukrainian_layer(iface,structure,entity,echelon,name,designation='',role='',edition=None):
    if edition is None:
        from .vkdp_symbols import using_profile
        edition='2525D' if using_profile() else current_edition()
    if structure not in STRUCTURES or entity not in types_for(structure,edition):
        raise ValueError('Оберіть доступний тип українського шаблону.')
    if echelon not in _ECHELON_LABELS:
        raise ValueError('Оберіть припустимий організаційний рівень.')
    if not name.strip():
        raise ValueError('Укажіть назву шару.')
    project=QgsProject.instance()
    full_name=layer_name_for(name.strip(),edition)
    if project.mapLayersByName(full_name):
        iface.messageBar().pushWarning('Українські підрозділи','Шар із такою назвою вже існує. Змініть назву для створення ще одного шару.')
        return None
    layer=build_single_domain_point_layer(
        name.strip(),'ground_unit',_UNIT_ENTITY_LABELS,resolve_entity(entity,edition),
        sector1_labels=_UNIT_SECTOR1_LABELS,sector2_labels=_UNIT_SECTOR2_LABELS,
        edition=edition,
    )
    # New attributes describe the user's context; they never alter the SIDC builder.
    layer.dataProvider().addAttributes([
        QgsField('uk_structure',QMetaType.Type.QString),
        QgsField('uk_role',QMetaType.Type.QString),
        QgsField('uk_subordination',QMetaType.Type.QString),
    ])
    layer.updateFields()
    structure_index=layer.fields().indexFromName('uk_structure')
    layer.setEditorWidgetSetup(structure_index,QgsEditorWidgetSetup('ValueMap',{
        'map':{label:key for key,(label,_) in STRUCTURES.items()}
    }))
    defaults={
        'affiliation':'friend','status':'present','entity':resolve_entity(entity,edition),'echelon':echelon,
        'unique_designation':designation.strip(),'uk_structure':structure,'uk_role':role.strip(),
    }
    if structure=='marine' and entity=='infantry_amphibious': defaults['sector1_modifier']='naval'
    for key,value in defaults.items():
        index=layer.fields().indexFromName(key)
        if index>=0: layer.setDefaultValueDefinition(index,QgsDefaultValue(QgsExpression.quotedString(value)))
    for key,label in {
        'uk_structure':'Структура / тематика','uk_role':'Спеціалізація / призначення',
        'uk_subordination':'Підпорядкування',
    }.items():
        layer.setFieldAlias(layer.fields().indexFromName(key),label)
    layer.setCustomProperty('MilitaryCartographyTools/ukrainian_template',structure)
    add_layer_at_default_position(project,layer,default_insert_position)
    iface.messageBar().pushInfo('Українські підрозділи','Шар створено. Увімкніть редагування та розміщуйте знаки на карті; назви й підпорядкування задаються у формі об’єкта.')
    return layer

class UkrainianUnitsDialog(QDialog):
    def __init__(self,iface,parent=None):
        super().__init__(parent)
        self.iface=iface
        from .vkdp_symbols import using_profile
        self.edition='2525D' if using_profile() else current_edition()
        self.setWindowTitle('Українські підрозділи та служби')
        self.structure=QComboBox()
        for key,(label,_) in STRUCTURES.items(): self.structure.addItem(label,key)
        self.unit_type=QComboBox()
        self.echelon=QComboBox()
        for key,label in _ECHELON_LABELS.items(): self.echelon.addItem(label,key)
        self.name=QLineEdit()
        self.designation=QLineEdit()
        self.designation.setPlaceholderText('Власне позначення підрозділу — необов’язково')
        self.role=QLineEdit()
        self.role.setPlaceholderText('Наприклад: розвідувальні БпЛА, ударні БпЛА, евакуація')
        explanation=QLabel('Оберіть українську тематику, функцію та організаційний рівень. Знак формується за поточною редакцією MIL-STD/APP-6. Структура, спеціалізація та підпорядкування зберігаються окремими редагованими полями.')
        explanation.setWordWrap(True)
        form=QFormLayout()
        for label,widget in [('Структура / тематика',self.structure),('Тип підрозділу',self.unit_type),
             ('Організаційний рівень',self.echelon),('Назва шару',self.name),
             ('Унікальне позначення',self.designation),('Спеціалізація',self.role)]: form.addRow(label,widget)
        buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText('Створити шар')
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText('Скасувати')
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout=QVBoxLayout(self)
        layout.addWidget(explanation)
        layout.addLayout(form)
        layout.addWidget(buttons)
        self.structure.currentIndexChanged.connect(self.populate)
        self.unit_type.currentIndexChanged.connect(self.update_name)
        self.populate()
        self.setMinimumWidth(610)

    def populate(self):
        self.unit_type.clear()
        for key in types_for(self.structure.currentData(),self.edition):
            self.unit_type.addItem(_UNIT_ENTITY_LABELS[key],key)
        self.update_name()

    def update_name(self):
        self.name.setText('Українські підрозділи — '+self.unit_type.currentText())

    def create_layer(self):
        return create_ukrainian_layer(self.iface,self.structure.currentData(),self.unit_type.currentData(),
            self.echelon.currentData(),self.name.text(),self.designation.text(),self.role.text(),self.edition)

def install(plugin):
    menu=plugin.group_menus['nato_symbols']
    def show_dialog():
        dialog=UkrainianUnitsDialog(plugin.iface,plugin.iface.mainWindow())
        if dialog.exec()==QDialog.DialogCode.Accepted: dialog.create_layer()
    action=QAction('Українські підрозділи та служби…',menu)
    action.setToolTip('Шаблони для українських структур: організаційні рівні, БпЛА, РЕБ, розвідка, інженерне, медичне й логістичне забезпечення')
    action.triggered.connect(show_dialog)
    menu.insertAction(menu.actions()[0],action)
    plugin._uk_project_callback=localize_existing_layers
    QgsProject.instance().readProject.connect(plugin._uk_project_callback)
    localize_existing_layers()
    from qgis.PyQt.QtWidgets import QApplication
    plugin._uk_button_filter=UkrainianDialogButtons(plugin.toolbar)
    QApplication.instance().installEventFilter(plugin._uk_button_filter)

class UkrainianDialogButtons(QObject):
    def eventFilter(self,obj,event):
        if event.type()==QEvent.Type.Show and isinstance(obj,QDialog) and (
            obj.__class__.__module__.startswith(__package__) or obj.windowTitle().startswith('Інструменти військової')
        ):
            captions={'Ok':'Гаразд','Cancel':'Скасувати','Close':'Закрити','Apply':'Застосувати',
                'Save':'Зберегти','Open':'Відкрити','Yes':'Так','No':'Ні','Reset':'Скинути',
                'RestoreDefaults':'Відновити типові','Help':'Довідка'}
            defaults={'OK','Ok','Cancel','Close','Apply','Save','Open','Yes','No','Reset',
                'Restore Defaults','Help','Отмена','Закрыть','Применить','Сохранить','Открыть','Да','Нет'}
            for box in obj.findChildren(QDialogButtonBox):
                for name,caption in captions.items():
                    button=box.button(getattr(QDialogButtonBox.StandardButton,name))
                    if button and button.text().replace('&','') in defaults: button.setText(caption)
        return False

def uninstall(plugin):
    from qgis.PyQt.QtWidgets import QApplication
    button_filter=getattr(plugin,'_uk_button_filter',None)
    if button_filter: QApplication.instance().removeEventFilter(button_filter)
    callback=getattr(plugin,'_uk_project_callback',None)
    if callback:
        try: QgsProject.instance().readProject.disconnect(callback)
        except (TypeError,RuntimeError): pass
        plugin._uk_project_callback=None
