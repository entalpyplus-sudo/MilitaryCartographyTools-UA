# -*- coding: utf-8 -*-

"""
Builds the "Sea Surface" point layer - MIL-STD-2525D
Appendix E (Sea Surface Symbols), symbol set "30" (Table A-III). No
missile-family companion to fold in here, unlike Space/Air - Table A-III
has no separate "Sea Surface Missile" symbol set, so this is a single
layer.

Moved 2026-08-08 from military_symbology/unit_layer.py, which used to
share sea_surface across a cascading multi-domain dropdown with
subsurface (and, previously, ground_unit/air before their own
mini-phases split them out) - see that module's own docstring for what's
left there (only subsurface now, pending Appendix F).

No echelon or headquarters fields - Appendix E's own amplifier table
(Table E-II) lists neither Field B (Echelon) nor Field S (Headquarters
Staff Indicator), same finding as every icon-based appendix so far.

Entity vocabulary is sidc.py's ENTITIES["sea_surface"] - the FULL
93-entity vocabulary from milsymbol-3.0.4's own sea.js (not a curated
subset - Sea Surface's own source is small enough that full coverage was
the more consistent choice this time, avoiding a repeat of the Land
Equipment/Installation gap the user caught). Includes Table E-VI's "Own
Ship" (150000 - Combat Information Center-internal, friend-only) and
Table E-VII's "Fused Track" (160000 - a track still being classified,
always pending status - this plugin doesn't enforce that pairing, same
"amplifier restrictions aren't enforced in code" pattern as sector 2
modifiers not being blocked for civilian entities either).

Sector 1/2 modifiers ARE built here (sidc.py's MODIFIERS["sea_surface"],
25 sector 1 + 16 sector 2 codes, also the FULL vocabulary) - Sea
Surface's own modifier tables are compact enough (unlike Land's 50+ per
sector) that there was no reason to defer them the way Land's were.

Military Cartography Tools
"""

from ._point_symbol_layer import add_single_domain_point_layer


OUTPUT_LAYER_NAME = 'Надводні об’єкти'

DEFAULT_ENTITY = "frigate"

_ENTITY_LABELS = {
    "military": 'Військовий об’єкт (загальне позначення)',
    "combatant": 'Бойовий корабель (загальне позначення)',
    "carrier": 'Авіаносець',
    "surface_combatant_line": 'Надводний бойовий корабель основних класів',
    "battleship": 'Лінійний корабель',
    "cruiser_guided_missile": 'Ракетний крейсер',
    "destroyer": 'Есмінець',
    "frigate": 'Фрегат',
    "corvette": 'Корвет',
    "littoral_combatant_ship": 'Бойовий корабель прибережної зони',
    "amphibious_warfare_ship": 'Корабель десантних сил',
    "amphibious_force_flagship": 'Флагман десантних сил',
    "amphibious_assault": 'Морська десантна атака',
    "amphibious_assault_ship_general": 'Десантний корабель (загальний)',
    "amphibious_assault_ship_multi_purpose": 'Багатоцільовий десантний корабель',
    "amphibious_assault_ship_helicopter": 'Десантний корабель-вертольотоносець',
    "amphibious_transport_dock": 'Десантний транспортний корабель-док',
    "landing_ship": 'Десантний корабель',
    "landing_craft": 'Десантний катер',
    "mine_warfare_vessel": 'Судно мінної війни (загальне позначення)',
    "minelayer": 'Корабель-мінний загороджувач',
    "minesweeper": 'Мінний тральщик',
    "minesweeper_drone": 'Безекіпажний мінний тральщик',
    "minehunter": 'Мінний мисливець',
    "mine_countermeasures": 'Протимінні заходи',
    "mine_countermeasure_support_ship": 'Корабель протимінного забезпечення',
    "patrol": 'Патрулювання (загальне позначення)',
    "patrol_craft": 'Патрульний катер',
    "patrol_gun": 'Патрульний артилерійський катер',
    "sea_surface_decoy": 'Надводна хибна ціль',
    "unmanned_surface_water_vehicle": 'Безекіпажний надводний апарат',
    "military_speedboat": 'Військовий швидкісний катер',
    "military_speedboat_rigid_hull_inflatable_boat": 'Військовий швидкісний надувний човен із жорстким корпусом',
    "military_jetski": 'Військовий гідроцикл',
    "navy_task_organization_unit": 'Підрозділ тактичної організації ВМС',
    "navy_task_element": 'Тактичний елемент ВМС',
    "navy_task_force": 'Тактичне з’єднання ВМС',
    "navy_task_group": 'Тактична група ВМС',
    "navy_task_unit": 'Тактичний підрозділ ВМС',
    "convoy": 'Колона',
    "radar": 'Радіолокаційна станція',
    "noncombatant": 'Небойове судно (загальне позначення)',
    "auxiliary_ship": 'Допоміжне судно',
    "ammunition_ship": 'Судно постачання боєприпасів',
    "stores_ship": 'Судно постачання запасів',
    "auxiliary_flag_or_command_ship": 'Допоміжний флагманський корабель або корабель управління',
    "intelligence_collector": 'Розвідувальний корабель',
    "ocean_research_ship": 'Океанографічне дослідницьке судно',
    "survey_ship": 'Гідрографічне судно',
    "hospital_ship": 'Госпітальне судно',
    "cargo_ship": 'Вантажне судно',
    "combat_support_ship_fast": 'Швидкохідне судно бойового забезпечення',
    "oiler_replenishment": 'Танкер забезпечення',
    "repair_ship": 'Ремонтне судно',
    "submarine_tender": 'Плавуча база підводних човнів',
    "tug_ocean_going": 'Морський буксир',
    "service_craft_yard_general": 'Портове службове судно (загальний)',
    "barge_not_self_propelled": 'Несамохідна баржа',
    "barge_self_propelled": 'Самохідна баржа',
    "tug_harbour": 'Гаванський буксир',
    "launch": 'Моторний катер',
    "civilian": 'Цивільний об’єкт (загальне позначення)',
    "merchant_ship_general": 'Торговельне судно (загальний)',
    "cargo_general": 'Вантажний (загальний)',
    "container_ship": 'Контейнеровоз',
    "dredge": 'Земснаряд',
    "roll_on_roll_off": 'Судно типу ро-ро',
    "ferry": 'Поромна переправа',
    "heavy_lift": 'Важкі транспортні перевезення',
    "hovercraft": 'Судно на повітряній подушці',
    "merchant_ship_lash_carrier": 'Торговельний ліхтеровоз LASH (із баржами)',
    "oiler_tanker": 'Нафтовоз / танкер',
    "passenger_ship": 'Пасажирське судно',
    "tug_ocean_going_civilian": 'Морський буксир (цивільний)',
    "tow": 'Буксирування',
    "transport_ship_hazardous_material": 'Судно перевезення небезпечних речовин',
    "junk_dhow": 'Джонка / дау',
    "barge_not_self_propelled_civilian": 'Несамохідна баржа (цивільний)',
    "hospital_ship_civilian": 'Госпітальне судно (цивільний)',
    "fishing_vessel": 'Рибальське судно (загальне позначення)',
    "drifter": 'Дрифтер',
    "trawler": 'Траулер',
    "fishing_vessel_dredge": 'Рибальське днопоглиблювальне судно',
    "law_enforcement_vessel": 'Правоохоронне судно',
    "leisure_craft_sailing_boat": 'Вітрильне прогулянкове судно',
    "leisure_craft_motorized": 'Моторне прогулянкове судно',
    "leisure_craft_motorized_rigid_hull_inflatable_boat": 'Моторний прогулянковий надувний човен із жорстким корпусом',
    "leisure_craft_motorized_speedboat": 'Швидкісне моторне прогулянкове судно',
    "leisure_craft_jetski": 'Прогулянковий гідроцикл',
    "civilian_unmanned_surface_water_vehicle": 'Безекіпажний надводний апарат (цивільний)',
    "own_ship": 'Власний корабель',
    "fused_track": 'Об’єднана траса',
    "manual_track": 'Ручний супровід',
}

_SECTOR1_LABELS = {
    "own_ship": 'Власний корабель',
    "antiair_warfare": 'Боротьба з повітряними цілями',
    "antisubmarine_warfare": 'Протичовнова боротьба',
    "escort": 'Супровід',
    "electronic_warfare": 'Радіоелектронна боротьба (РЕБ)',
    "intelligence_surveillance_reconnaissance": 'Розвідка, спостереження та рекогносцировка',
    "mine_countermeasures": 'Протимінні заходи',
    "missile_defense": 'Протиракетна оборона',
    "medical": 'Медичний підрозділ',
    "mine_warfare": 'Мінна війна',
    "remote_multi_mission_vehicle": 'Дистанційний багатоцільовий апарат',
    "special_operations_force": 'Підрозділ сил спеціальних операцій',
    "surface_warfare": 'Надводні бойові дії',
    "ballistic_missile": 'Балістична ракета',
    "guided_missile": 'Керована ракета',
    "other_guided_missile": 'Інша керована ракета',
    "torpedo": 'Торпеда',
    "drone_equipped": 'Оснащений безпілотними апаратами',
    "helicopter_equipped": 'Оснащений вертольотом',
    "ballistic_missile_defense_shooter": 'Протиракетна оборона: вогневий засіб',
    "ballistic_missile_defense_long_range_surveillance_and_track": 'Протиракетна оборона: дальнє спостереження та супровід (LRS&T)',
    "sea_base_x_band": 'Морська РЛС X-діапазону',
    "hijacking_hijacked": 'Захоплення / захоплений транспорт',
    "hijacker": 'Викрадач транспортного засобу',
    "cyberspace": 'Кіберпростір',
}

_SECTOR2_LABELS = {
    "nuclear_powered": 'З ядерною енергетичною установкою',
    "heavy": 'Важкий',
    "light": 'Легкий',
    "medium": 'Середній',
    "dock": 'Док',
    "logistics": 'Логістика',
    "tank": 'Танк',
    "vehicle": 'Транспортний засіб',
    "fast": 'Швидкохідний',
    "air_cushioned_us": 'На повітряній подушці (лише США)',
    "air_cushioned": 'На повітряній подушці',
    "hydrofoil": 'Судно на підводних крилах',
    "autonomous_control": 'Автономне керування',
    "remotely_piloted": 'Дистанційно пілотований',
    "expendable": 'Одноразовий',
    "cyberspace": 'Кіберпростір',
}


def add_sea_surface_layer(iface, edition=None):

    """
    Add the "Sea Surface" layer - warns and does
    nothing if one already exists, same data-safety guard as every other
    hand-digitized layer in this plugin.
    """

    return add_single_domain_point_layer(
        iface,
        OUTPUT_LAYER_NAME,
        "sea_surface",
        _ENTITY_LABELS,
        DEFAULT_ENTITY,
        include_echelon=False,
        include_headquarters=False,
        sector1_labels=_SECTOR1_LABELS,
        sector2_labels=_SECTOR2_LABELS,
        edition=edition,
    )
