# -*- coding: utf-8 -*-

"""
Builds the "Space" point layer - MIL-STD-2525D
Appendix B (Space Symbols), covering both of its sections in one layer:
B.6 Space Equipment and Platform Symbols (symbol set "05") and B.7 Space
Missile Symbols (symbol set "06" - Table A-III). Space Missile has only
one entity at this plugin's current level of coverage (no sector
modifiers exposed for any symbol set yet - see sidc.py), so rather than
give it a whole second layer for one entity, its "missile" entity is
folded straight into this layer's own entity dropdown via
_point_symbol_layer.py's entity_symbol_set_overrides mechanism, which
resolves it to symbol set "06" instead of this layer's default "05" only
for that one entity.

Entity vocabulary is military_symbology/sidc.py's ENTITIES["space"]/
["space_missile"] - see that module for sourcing (milsymbol.js's own
space.js/spacemissile.js, cross-checked against the standard's own
Table B-III).

No echelon or headquarters fields - Appendix B's own amplifier table
(Table B-II) lists neither Field B (Echelon) nor Field S (Headquarters
Staff Indicator) for space symbols at all, unlike land units.

Sector 1/2 modifiers (added 2026-08-08, alongside the shared factory's
own modifier support) - _SECTOR1_LABELS/_SECTOR2_LABELS are each the
UNION of sidc.py's MODIFIERS["space"] and MODIFIERS["space_missile"]
(orbit type/sensor type for Space Equipment, missile class/range for
Space Missile) - see build_single_domain_point_layer()'s own docstring
for why a merged layer needs the union rather than just its default
symbol_set's own vocabulary, and the failure mode if an incompatible
entity/modifier pair is chosen anyway.

Military Cartography Tools
"""

from ._point_symbol_layer import add_single_domain_point_layer


OUTPUT_LAYER_NAME = 'Космос'

DEFAULT_ENTITY = "satellite"

# The one entity that resolves to a different symbol_set (Space Missile,
# "06") than this layer's own default ("05", Space Equipment/Platform) -
# see this module's own docstring.
_ENTITY_SYMBOL_SET_OVERRIDES = {
    "missile": "space_missile",
}

# Display labels - kept separate from sidc.py's own vocabulary dicts,
# which are the data model (real SIDC component codes), not
# presentation text. Mirrors unit_layer.py's own _ENTITY_LABELS_BY_
# SYMBOL_SET convention.
_ENTITY_LABELS = {
    "military": 'Військовий об’єкт (загальне позначення)',
    "space_vehicle": 'Космічний апарат',
    "re_entry_vehicle": 'Апарат повернення в атмосферу',
    "planet_lander": 'Планетний посадковий апарат',
    "orbiter_shuttle": 'Орбітальний корабель / шатл',
    "capsule": 'Космічна капсула',
    "satellite_general": 'Супутник загального типу',
    "satellite": 'Супутник',
    "antisatellite_weapon": 'Протисупутникова зброя',
    "astronomical_satellite": 'Астрономічний супутник',
    "biosatellite": 'Біосупутник',
    "communications_satellite": 'Супутник зв’язку',
    "earth_observation_satellite": 'Супутник спостереження Землі',
    "miniaturized_satellite": 'Малий супутник',
    "navigational_satellite": 'Навігаційний супутник',
    "reconnaissance_satellite": 'Розвідувальний супутник',
    "space_station": 'Космічна станція',
    "tethered_satellite": 'Тросовий супутник',
    "weather_satellite": 'Метеорологічний супутник',
    "space_launch_vehicle": 'Космічна ракета-носій',
    "civilian": 'Цивільний об’єкт (загальне позначення)',
    "civilian_orbiter_shuttle": 'Орбітальний корабель / шатл (цивільний)',
    "civilian_capsule": 'Космічна капсула (цивільний)',
    "civilian_satellite": 'Супутник (цивільний)',
    "civilian_astronomical_satellite": 'Астрономічний супутник (цивільний)',
    "civilian_biosatellite": 'Біосупутник (цивільний)',
    "civilian_communications_satellite": 'Супутник зв’язку (цивільний)',
    "civilian_earth_observation_satellite": 'Супутник спостереження Землі (цивільний)',
    "civilian_miniaturized_satellite": 'Малий супутник (цивільний)',
    "civilian_navigational_satellite": 'Навігаційний супутник (цивільний)',
    "civilian_space_station": 'Космічна станція (цивільний)',
    "civilian_tethered_satellite": 'Тросовий супутник (цивільний)',
    "civilian_weather_satellite": 'Метеорологічний супутник (цивільний)',
    "civilian_planetary_lander": 'Посадковий апарат для дослідження планет (цивільний)',
    "civilian_space_vehicle": 'Космічний апарат (цивільний)',
    "manual_track": 'Ручний супровід',
    "missile": 'Ракета',
}

# Sector 1 modifier - union of MODIFIERS["space"]["sector1"] (orbit
# type) and MODIFIERS["space_missile"]["sector1"] (missile class).
_SECTOR1_LABELS = {
    "low_earth_orbit": 'Низька навколоземна орбіта (LEO)',
    "medium_earth_orbit": 'Середня навколоземна орбіта (MEO)',
    "high_earth_orbit": 'Висока навколоземна орбіта (HEO)',
    "geosynchronous_orbit": 'Геосинхронна орбіта (GSO)',
    "geostationary_orbit": 'Геостаціонарна орбіта (GO)',
    "molniya_orbit": 'Орбіта типу «Молнія» (MO)',
    "cyberspace": 'Кіберпростір',
    "ballistic": 'Балістична',
    "space": 'Космос',
    "interceptor": 'Перехоплювач',
    "hypersonic": 'Гіперзвукова',
}

# Sector 2 modifier - union of MODIFIERS["space"]["sector2"] (sensor
# type) and MODIFIERS["space_missile"]["sector2"] (missile range class).
_SECTOR2_LABELS = {
    "optical": 'Оптичний',
    "infrared": 'Інфрачервоний',
    "radar": 'Радіолокаційна станція',
    "signals_intelligence": 'Радіоелектронна розвідка (SIGINT)',
    "cyberspace": 'Кіберпростір',
    "electromagnetic_warfare": 'Електромагнітна боротьба проти супутників (ASAT)',
    "high_power_microwave": 'Потужне мікрохвильове випромінювання',
    "laser": 'Лазер',
    "mine": 'Міна',
    "maintenance": 'Ремонтний підрозділ',
    "refuel": 'Заправлення пальним',
    "tug": 'Буксир',
    "short_range": 'Мала дальність',
    "medium_range": 'Середня дальність',
    "intermediate_range": 'Проміжна дальність',
    "long_range": 'Велика дальність',
    "intercontinental": 'Міжконтинентальна',
    "arrow": 'Протиракетна система Arrow',
    "ground_based_interceptor": 'Протиракета наземного базування (GBI)',
    "patriot": 'Зенітний ракетний комплекс Patriot',
    "standard_missile_terminal_phase": 'Ракета Standard Missile для кінцевої ділянки (SM-T)',
    "standard_missile_3": 'Протиракета Standard Missile 3 (SM-3)',
    "terminal_high_altitude_area_defense": 'Висотний комплекс протиракетної оборони THAAD',
    "space": 'Космос',
    "close_range": 'Ближня дальність',
    "debris": 'Уламки',
    "unknown": 'Невідомий',
}


def add_space_layer(iface, edition=None):

    """
    Add the "Space" layer (Space Equipment/Platform
    plus the single Space Missile entity) - warns and does nothing if
    one already exists, same data-safety guard as every other
    hand-digitized layer in this plugin.
    """

    return add_single_domain_point_layer(
        iface,
        OUTPUT_LAYER_NAME,
        "space",
        _ENTITY_LABELS,
        DEFAULT_ENTITY,
        entity_symbol_set_overrides=_ENTITY_SYMBOL_SET_OVERRIDES,
        include_echelon=False,
        include_headquarters=False,
        sector1_labels=_SECTOR1_LABELS,
        sector2_labels=_SECTOR2_LABELS,
        edition=edition,
    )
