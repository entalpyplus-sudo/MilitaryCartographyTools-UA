# -*- coding: utf-8 -*-

"""
Builds the "Air" point layer - MIL-STD-2525D
Appendix C (Air Symbols), covering both of its sections in one layer:
C.6 Air Equipment and Platform Symbols (symbol set "01") and C.7 Air
Missile Symbols (symbol set "02" - Table A-III). Air Missile has only
one entity at this plugin's current level of coverage (no sector
modifiers exposed for any symbol set yet - see sidc.py), so its
"missile" entity is folded straight into this layer's own entity
dropdown via _point_symbol_layer.py's entity_symbol_set_overrides
mechanism, the same pattern space_layer.py already established for
Space Missile.

No echelon or headquarters fields - Appendix C's own amplifier table
(Table C-II, already read this session) lists neither Field B (Echelon)
nor Field S (Headquarters Staff Indicator) for air symbols, same finding
as Space's own Table B-II.

Entity vocabulary is military_symbology/sidc.py's ENTITIES["air"]/
["air_missile"] - see that module for sourcing (milsymbol.js's own
air.js/airmissile.js, cross-checked against the standard's own Table
C-III).

Sector 1/2 modifiers (added 2026-08-08, alongside the shared factory's
own modifier support) - _SECTOR1_LABELS/_SECTOR2_LABELS are each the
UNION of sidc.py's MODIFIERS["air"] and MODIFIERS["air_missile"] (role/
mission class for Air Equipment, target/range class for Air Missile) -
see space_layer.py's own comment and
build_single_domain_point_layer()'s docstring for why a merged layer
needs the union. A few keys (e.g. "interceptor", "short_range") are
valid AND mean essentially the same thing in both underlying
vocabularies, so they appear once here rather than twice - not a
conflict, since mct_build_sidc() resolves the actual numeric code
against whichever symbol_set the chosen entity maps to.

Military Cartography Tools
"""

from ._point_symbol_layer import add_single_domain_point_layer


OUTPUT_LAYER_NAME = 'Повітряні об’єкти'

DEFAULT_ENTITY = "fighter"

# The one entity that resolves to a different symbol_set (Air Missile,
# "02") than this layer's own default ("01", Air Equipment/Platform).
_ENTITY_SYMBOL_SET_OVERRIDES = {
    "missile": "air_missile",
}

# Display labels - kept separate from sidc.py's own vocabulary dicts,
# which are the data model (real SIDC component codes), not
# presentation text.
_ENTITY_LABELS = {
    "military": 'Військовий об’єкт (загальне позначення)',
    "fixed_wing": 'Літак',
    "medical_evacuation": 'Медична евакуація',
    "attack_strike": 'Штурмовик / ударний літак',
    "bomber": 'Бомбардувальник',
    "fighter": 'Винищувач',
    "fighter_bomber": 'Винищувач-бомбардувальник',
    "cargo": 'Вантажний',
    "jammer_electronic_countermeasures": 'Постановник перешкод / радіоелектронна протидія (ECM)',
    "tanker": 'Заправник',
    "patrol": 'Патрулювання',
    "reconnaissance": 'Розвідка',
    "trainer": 'Навчальний',
    "utility": 'Допоміжний',
    "vstol": 'Вертикальний / короткий зліт і посадка (VSTOL)',
    "airborne_command_post": 'Повітряний командний пункт',
    "airborne_early_warning": 'Повітряне дальнє радіолокаційне виявлення',
    "antisurface_warfare": 'Боротьба з надводними цілями',
    "antisubmarine_warfare": 'Протичовнова боротьба',
    "communications": 'Зв’язок',
    "combat_search_and_rescue": 'Бойовий пошук і рятування (CSAR)',
    "electronic_support": 'Радіоелектронне забезпечення',
    "government": 'Державний',
    "mine_countermeasures": 'Протимінні заходи',
    "personnel_recovery": 'Повернення особового складу',
    "search_and_rescue": 'Пошук і рятування',
    "special_operations_forces": 'Сили спеціальних операцій',
    "ultra_light": 'Надлегкий',
    "photographic_reconnaissance": 'Фоторозвідка',
    "vip": 'Особливо важлива особа (VIP)',
    "suppression_of_enemy_air_defense": 'Придушення ППО противника (SEAD)',
    "passenger": 'Пасажирський',
    "escort": 'Супровід',
    "electronic_attack": 'Радіоелектронна атака (EA)',
    "military_rotary_wing": 'Військовий вертоліт',
    "unmanned_aerial_vehicle": 'Безпілотний літальний апарат (БпЛА)',
    "vertical_takeoff_uav": 'БпЛА вертикального зльоту (VT-UAV)',
    "military_balloon": 'Військовий аеростат',
    "military_airship": 'Військовий дирижабль',
    "tethered_lighter_than_air": 'Прив’язний аеростат',
    "civilian": 'Цивільний об’єкт (загальне позначення)',
    "civilian_fixed_wing": 'Цивільний літак',
    "civilian_rotary_wing": 'Цивільний вертоліт',
    "civilian_unmanned_aerial_vehicle": 'Цивільний БпЛА',
    "civilian_balloon": 'Цивільний аеростат',
    "civilian_airship": 'Цивільний дирижабль',
    "civilian_tethered_lighter_than_air": 'Цивільний прив’язний аеростат',
    "civilian_medical_evacuation": 'Цивільна медична евакуація',
    "weapon": 'Зброя (загальне позначення)',
    "bomb": 'Бомба',
    "underwater_decoy": 'Підводна хибна ціль',
    "manual_track": 'Ручний супровід',
    "missile": 'Ракета',
}

# Sector 1 modifier - union of MODIFIERS["air"]["sector1"] (role/mission)
# and MODIFIERS["air_missile"]["sector1"] (missile class).
_SECTOR1_LABELS = {
    "attack": 'Атака',
    "bomber": 'Бомбардувальник',
    "cargo": 'Вантажний',
    "fighter": 'Винищувач',
    "interceptor": 'Перехоплювач',
    "tanker": 'Заправник',
    "utility": 'Допоміжний',
    "vstol": 'Вертикальний / короткий зліт і посадка (VSTOL)',
    "passenger": 'Пасажирський',
    "ultra_light": 'Надлегкий',
    "airborne_command_post": 'Повітряний командний пункт',
    "airborne_early_warning": 'Повітряне дальнє радіолокаційне виявлення',
    "government": 'Державний',
    "medevac": 'Медична евакуація',
    "escort": 'Супровід',
    "jammer_electronic_countermeasures": 'Постановник перешкод / радіоелектронна протидія (ECM)',
    "patrol": 'Патрулювання',
    "reconnaissance": 'Розвідка',
    "trainer": 'Навчальний',
    "photographic": 'Фотографічний',
    "personnel_recovery": 'Повернення особового складу',
    "antisubmarine_warfare": 'Протичовнова боротьба',
    "communications": 'Зв’язок',
    "electronic_support": 'Радіоелектронне забезпечення (ES)',
    "mine_countermeasures": 'Протимінні заходи',
    "search_and_rescue": 'Пошук і рятування',
    "special_operations_forces": 'Сили спеціальних операцій',
    "surface_warfare": 'Надводні бойові дії',
    "vip": 'Особливо важлива особа (VIP)',
    "combat_search_and_rescue": 'Бойовий пошук і рятування',
    "suppression_of_enemy_air_defense": 'Придушення ППО противника',
    "antisurface_warfare": 'Боротьба з надводними цілями',
    "fighter_bomber": 'Винищувач-бомбардувальник',
    "intensive_care": 'Інтенсивна терапія',
    "electronic_attack": 'Радіоелектронна атака (EA)',
    "multimission": 'Багатоцільовий',
    "hijacking": 'Захоплення транспортного засобу',
    "asw_helo_lamps": 'Протичовновий вертоліт LAMPS',
    "asw_helo_sh_60r": 'Протичовновий вертоліт SH-60R',
    "hijacker": 'Викрадач транспортного засобу',
    "cyberspace": 'Кіберпростір',
    "air": 'Повітряні об’єкти',
    "surface": 'Поверхня',
    "subsurface": 'Підводні об’єкти',
    "space": 'Космос',
    "anti_ballistic": 'Протибалістична',
    "ballistic": 'Балістична',
    "cruise": 'Крилата',
    "hypersonic": 'Гіперзвукова',
}

# Sector 2 modifier - union of MODIFIERS["air"]["sector2"] (fuel/range
# class) and MODIFIERS["air_missile"]["sector2"] (target/range class).
_SECTOR2_LABELS = {
    "heavy": 'Важкий',
    "medium": 'Середній',
    "light": 'Легкий',
    "boom_only": 'Лише жорстка штанга',
    "drogue_only": 'Лише конус',
    "boom_and_drogue": 'Штанга та конус',
    "close_range": 'Ближня дальність',
    "short_range": 'Мала дальність',
    "medium_range": 'Середня дальність',
    "long_range": 'Велика дальність',
    "downlinked": 'Дані отримано низхідним каналом',
    "cyberspace": 'Кіберпростір',
    "air": 'Повітряні об’єкти',
    "surface": 'Поверхня',
    "subsurface": 'Підводні об’єкти',
    "space": 'Космос',
    "launched": 'Запущено',
    "missile": 'Ракета',
    "patriot": 'Зенітний ракетний комплекс Patriot',
    "standard_missile_2": 'Зенітна ракета Standard Missile 2 (SM-2)',
    "standard_missile_6": 'Зенітна ракета Standard Missile 6 (SM-6)',
    "evolved_sea_sparrow_missile": 'Зенітна ракета Evolved Sea Sparrow (ESSM)',
    "rolling_airframe_missile": 'Зенітна ракета Rolling Airframe Missile (RAM)',
    "intermediate_range": 'Проміжна дальність',
    "intercontinental": 'Міжконтинентальна',
}


def add_air_layer(iface, edition=None):

    """
    Add the "Air" layer (Air Equipment/Platform plus
    the single Air Missile entity) - warns and does nothing if one
    already exists, same data-safety guard as every other
    hand-digitized layer in this plugin.
    """

    return add_single_domain_point_layer(
        iface,
        OUTPUT_LAYER_NAME,
        "air",
        _ENTITY_LABELS,
        DEFAULT_ENTITY,
        entity_symbol_set_overrides=_ENTITY_SYMBOL_SET_OVERRIDES,
        include_echelon=False,
        include_headquarters=False,
        sector1_labels=_SECTOR1_LABELS,
        sector2_labels=_SECTOR2_LABELS,
        edition=edition,
    )
