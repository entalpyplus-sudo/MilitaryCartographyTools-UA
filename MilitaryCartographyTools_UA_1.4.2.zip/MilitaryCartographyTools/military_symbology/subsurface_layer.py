# -*- coding: utf-8 -*-

"""
Builds two "Subsurface" / "Mine
Warfare" point layers - MIL-STD-2525D Appendix F (Subsurface Symbols),
split per its own two sections (F.6 Subsurface Unit/Equipment/
Installation, symbol set "35"; F.7 Mine Warfare, symbol set "36" - Table
A-III). Two separate layers, not merged - Mine Warfare's own 64-entity
vocabulary is far too large to fold into a companion the way Space/Air
Missile's single entity was; this mirrors Land's "several genuinely
distinct layers under one action" pattern instead.

Subsurface ("subsurface" in sidc.py) moved here 2026-08-08 from
military_symbology/unit_layer.py, which used to share it across a
cascading multi-domain dropdown with sea_surface/air/ground_unit before
each of those moved to its own dedicated layer in turn -
unit_layer.py itself is retired now that subsurface was its last
remaining domain (see this session's roadmap entry for the full
history).

**This is where the user's originally-reported bug lived**: "Subsurface
- Military Generic is in Air, Sea Surface [but not for Subsurface]".
Investigated directly - `ENTITIES["subsurface"]["military"]` ("110000")
was already correct and matches subsurface.js's own "SU.IC.MILITARY"
exactly (confirmed by a full parse of the source, not a spot check); the
actual root cause was almost certainly `unit_layer.py`'s old
ValueRelation-based cascading "Entity" dropdown, which that module's own
docstring already flagged as having a confirmed native-crash risk during
development. Resolved structurally, not by changing this code: Subsurface
now has its own dedicated layer with a plain ValueMap dropdown, no
cascading, no shared-layer entity-collision risk at all.

No echelon or headquarters fields - Appendix F's own amplifier table
(Table F-II) lists neither, same finding as every icon-based appendix
checked so far.

Entity vocabulary: `ENTITIES["subsurface"]` (22 entities) and
`ENTITIES["mine_warfare"]` (64 entities) are both the FULL vocabulary
from milsymbol-3.0.4's own subsurface.js/minewarfare.js - both small
enough for full coverage (same policy as Sea Surface). Mine Warfare's
own MILCO (Mine-Like Contact) entries have real confidence-level (1-5)
sub-variants for each position (general/bottom/moored/floating) - the
same kind of systematic sub-code axis Land Equipment's light/medium/
heavy variants turned out to be - caught here up front by the same full
multi-line-aware parse, not missed the way it was there.

Subsurface's own sector 1/2 modifiers (`MODIFIERS["subsurface"]`, 22 +
17 codes) are also fully built, same reasoning as Sea Surface's. Mine
Warfare has NO sector modifiers at all - milsymbol's own minewarfare.js
source has zero sIdm1/sIdm2 entries, not a curation choice.

Military Cartography Tools
"""

from ._point_symbol_layer import add_single_domain_point_layer


SUBSURFACE_LAYER_NAME = 'Підводні об’єкти'

MINE_WARFARE_LAYER_NAME = 'Мінна війна'

DEFAULT_SUBSURFACE_ENTITY = "submarine"

DEFAULT_MINE_WARFARE_ENTITY = "sea_mine"

_SUBSURFACE_ENTITY_LABELS = {
    "military": 'Військовий об’єкт (загальне позначення)',
    "submarine": 'Підводний човен',
    "submarine_surfaced": 'Підводний човен у надводному положенні',
    "submarine_snorkeling": 'Підводний човен під шноркелем',
    "submarine_bottomed": 'Підводний човен на ґрунті',
    "other_submersible": 'Інший підводний апарат',
    "non_submarine": 'Об’єкт, що не є підводним човном',
    "autonomous_underwater_vehicle": 'Автономний підводний апарат (AUV/UUV)',
    "diver_military": 'Водолаз (військовий)',
    "civilian": 'Цивільний об’єкт (загальне позначення)',
    "submersible_civilian": 'Підводний апарат (цивільний)',
    "autonomous_underwater_vehicle_civilian": 'Автономний підводний апарат (цивільний)',
    "diver_civilian": 'Водолаз (цивільний)',
    "underwater_weapon": 'Підводна зброя (загальне позначення)',
    "torpedo": 'Торпеда',
    "improvised_explosive_device": 'Саморобний вибуховий пристрій (СВП)',
    "underwater_decoy": 'Підводна хибна ціль',
    "echo_tracker_classifier": 'Класифікатор ехосигналів (ETC) / можливий контакт (POSCON)',
    "fused_track": 'Об’єднана траса',
    "manual_track": 'Ручний супровід',
    "seabed_installation_military": 'Штучний військовий об’єкт на морському дні',
    "seabed_installation_non_military": 'Штучний невійськовий об’єкт на морському дні',
}

_SUBSURFACE_SECTOR1_LABELS = {
    "antisubmarine_warfare": 'Протичовнова боротьба',
    "auxiliary": 'Допоміжний',
    "command_and_control": 'Командування та управління',
    "intelligence_surveillance_reconnaissance": 'Розвідка, спостереження та рекогносцировка',
    "mine_countermeasures": 'Протимінні заходи',
    "mine_warfare": 'Мінна війна',
    "surface_warfare": 'Надводні бойові дії',
    "attack": 'Атака',
    "ballistic_missile": 'Балістична ракета',
    "guided_missile": 'Керована ракета',
    "other_guided_missiles_point_defence": 'Інші керовані ракети об’єктової оборони',
    "special_operations_force": 'Підрозділ сил спеціальних операцій',
    "possible_submarine_low_1": 'Можливий підводний човен — низький рівень 1',
    "possible_submarine_low_2": 'Можливий підводний човен — низький рівень 2',
    "possible_submarine_high_3": 'Можливий підводний човен — високий рівень 3',
    "possible_submarine_high_4": 'Можливий підводний човен — високий рівень 4',
    "probable_submarine": 'Імовірний підводний човен',
    "certain_submarine": 'Достовірно визначений підводний човен',
    "anti_torpedo_torpedo": 'Протиторпедна торпеда',
    "hijacking_hijacked": 'Захоплення / захоплений транспорт',
    "hijacker": 'Викрадач транспортного засобу',
    "cyberspace": 'Кіберпростір',
}

_SUBSURFACE_SECTOR2_LABELS = {
    "air_independent_propulsion": 'Повітронезалежна енергетична установка',
    "diesel_propulsion": 'Дизельна силова установка',
    "diesel_type_1": 'Дизельна силова установка — тип 1',
    "diesel_type_2": 'Дизельна силова установка — тип 2',
    "diesel_type_3": 'Дизельна силова установка — тип 3',
    "nuclear_powered": 'З ядерною енергетичною установкою',
    "nuclear_type_1": 'Ядерна енергетична установка — тип 1',
    "nuclear_type_2": 'Ядерна енергетична установка — тип 2',
    "nuclear_type_3": 'Ядерна енергетична установка — тип 3',
    "nuclear_type_4": 'Ядерна енергетична установка — тип 4',
    "nuclear_type_5": 'Ядерна енергетична установка — тип 5',
    "nuclear_type_6": 'Ядерна енергетична установка — тип 6',
    "nuclear_type_7": 'Ядерна енергетична установка — тип 7',
    "autonomous_control": 'Автономне керування',
    "remotely_piloted": 'Дистанційно пілотований',
    "expendable": 'Одноразовий',
    "cyberspace": 'Кіберпростір',
}

_MINE_WARFARE_ENTITY_LABELS = {
    "sea_mine": 'Морська міна (загальне позначення)',
    "sea_mine_bottom": 'Донна морська міна',
    "sea_mine_moored": 'Якірна морська міна',
    "sea_mine_floating": 'Плавуча морська міна',
    "sea_mine_rising": 'Спливаюча морська міна',
    "sea_mine_other_position": 'Морська міна в іншому положенні',
    "sea_mine_kingfisher": 'Морська міна Kingfisher',
    "sea_mine_small_object": 'Морська міна — малий об’єкт',
    "sea_mine_exercise": 'Навчальна морська міна',
    "sea_mine_exercise_bottom": 'Навчальна донна морська міна',
    "sea_mine_exercise_moored": 'Навчальна якірна морська міна',
    "sea_mine_exercise_floating": 'Навчальна плавуча морська міна',
    "sea_mine_exercise_rising": 'Навчальна спливаюча морська міна',
    "sea_mine_neutralized": 'Знешкоджена морська міна',
    "sea_mine_neutralized_bottom": 'Знешкоджена донна морська міна',
    "sea_mine_neutralized_moored": 'Знешкоджена якірна морська міна',
    "sea_mine_neutralized_floating": 'Знешкоджена плавуча морська міна',
    "sea_mine_neutralized_rising": 'Знешкоджена спливаюча морська міна',
    "sea_mine_other_position_neutralized": 'Знешкоджена морська міна в іншому положенні',
    "unexploded_explosive_ordnance": 'Вибухонебезпечний боєприпас, що не вибухнув',
    "sea_mine_decoy": 'Імітатор морської міни (загальне позначення)',
    "sea_mine_decoy_bottom_ground": 'Донний / ґрунтовий імітатор морської міни',
    "sea_mine_decoy_moored": 'Якірний імітатор морської міни',
    "sea_mine_milco": 'Міноподібний контакт (MILCO)',
    "sea_mine_milco_confidence_1": 'Міноподібний контакт MILCO (загальний), рівень достовірності 1',
    "sea_mine_milco_confidence_2": 'Міноподібний контакт MILCO (загальний), рівень достовірності 2',
    "sea_mine_milco_confidence_3": 'Міноподібний контакт MILCO (загальний), рівень достовірності 3',
    "sea_mine_milco_confidence_4": 'Міноподібний контакт MILCO (загальний), рівень достовірності 4',
    "sea_mine_milco_confidence_5": 'Міноподібний контакт MILCO (загальний), рівень достовірності 5',
    "sea_mine_milco_bottom": 'Міноподібний контакт MILCO (донний)',
    "sea_mine_milco_bottom_confidence_1": 'Міноподібний контакт MILCO (донний), рівень достовірності 1',
    "sea_mine_milco_bottom_confidence_2": 'Міноподібний контакт MILCO (донний), рівень достовірності 2',
    "sea_mine_milco_bottom_confidence_3": 'Міноподібний контакт MILCO (донний), рівень достовірності 3',
    "sea_mine_milco_bottom_confidence_4": 'Міноподібний контакт MILCO (донний), рівень достовірності 4',
    "sea_mine_milco_bottom_confidence_5": 'Міноподібний контакт MILCO (донний), рівень достовірності 5',
    "sea_mine_milco_moored": 'Міноподібний контакт MILCO (якірний)',
    "sea_mine_milco_moored_confidence_1": 'Міноподібний контакт MILCO (якірний), рівень достовірності 1',
    "sea_mine_milco_moored_confidence_2": 'Міноподібний контакт MILCO (якірний), рівень достовірності 2',
    "sea_mine_milco_moored_confidence_3": 'Міноподібний контакт MILCO (якірний), рівень достовірності 3',
    "sea_mine_milco_moored_confidence_4": 'Міноподібний контакт MILCO (якірний), рівень достовірності 4',
    "sea_mine_milco_moored_confidence_5": 'Міноподібний контакт MILCO (якірний), рівень достовірності 5',
    "sea_mine_milco_floating": 'Міноподібний контакт MILCO (плавучий)',
    "sea_mine_milco_floating_confidence_1": 'Міноподібний контакт MILCO (плавучий), рівень достовірності 1',
    "sea_mine_milco_floating_confidence_2": 'Міноподібний контакт MILCO (плавучий), рівень достовірності 2',
    "sea_mine_milco_floating_confidence_3": 'Міноподібний контакт MILCO (плавучий), рівень достовірності 3',
    "sea_mine_milco_floating_confidence_4": 'Міноподібний контакт MILCO (плавучий), рівень достовірності 4',
    "sea_mine_milco_floating_confidence_5": 'Міноподібний контакт MILCO (плавучий), рівень достовірності 5',
    "sea_mine_milec": 'Міноподібний ехосигнал (MILEC)',
    "sea_mine_milec_bottom": 'Донний міноподібний ехосигнал (MILEC)',
    "sea_mine_milec_moored": 'Якірний міноподібний ехосигнал (MILEC)',
    "sea_mine_milec_floating": 'Плавучий міноподібний ехосигнал (MILEC)',
    "sea_mine_negative_reacquisition": 'Морська міна, повторно не виявлена',
    "sea_mine_negative_reacquisition_bottom": 'Донна морська міна, повторно не виявлена',
    "sea_mine_negative_reacquisition_moored": 'Якірна морська міна, повторно не виявлена',
    "sea_mine_negative_reacquisition_floating": 'Плавуча морська міна, повторно не виявлена',
    "sea_mine_general_obstructor": 'Морський протитральний захисник',
    "sea_mine_general_obstructor_neutralized": 'Знешкоджений морський протитральний захисник',
    "sea_mine_anchor": 'Якір морської міни',
    "sea_mine_non_mine_like_contact": 'Міноподібний контакт, що не є міною',
    "sea_mine_non_mine_like_contact_bottom": 'Донний міноподібний контакт, що не є міною',
    "sea_mine_non_mine_like_contact_moored": 'Якірний міноподібний контакт, що не є міною',
    "sea_mine_non_mine_like_contact_floating": 'Плавучий міноподібний контакт, що не є міною',
    "environmental_report_location": 'Місце донесення про стан довкілля',
    "dive_report_location": 'Місце донесення про занурення',
}


def add_subsurface_layer(iface, edition=None):

    """
    Add the "Subsurface" layer - warns and does
    nothing if one already exists, same data-safety guard as every other
    hand-digitized layer in this plugin.
    """

    return add_single_domain_point_layer(
        iface,
        SUBSURFACE_LAYER_NAME,
        "subsurface",
        _SUBSURFACE_ENTITY_LABELS,
        DEFAULT_SUBSURFACE_ENTITY,
        include_echelon=False,
        include_headquarters=False,
        sector1_labels=_SUBSURFACE_SECTOR1_LABELS,
        sector2_labels=_SUBSURFACE_SECTOR2_LABELS,
        edition=edition,
    )


def add_mine_warfare_layer(iface, edition=None):

    """Add the "Mine Warfare" layer - same guard."""

    return add_single_domain_point_layer(
        iface,
        MINE_WARFARE_LAYER_NAME,
        "mine_warfare",
        _MINE_WARFARE_ENTITY_LABELS,
        DEFAULT_MINE_WARFARE_ENTITY,
        include_echelon=False,
        include_headquarters=False,
        edition=edition,
    )


def add_subsurface_layers(iface):

    """
    Add both Appendix F layers (Subsurface, Mine Warfare) in one call -
    the toolbar action's own callback. Each has its own already-exists
    guard, so calling this again only adds whichever is still missing.
    Returns a dict of {layer_name: layer_or_None}.
    """

    return {
        SUBSURFACE_LAYER_NAME: add_subsurface_layer(iface),
        MINE_WARFARE_LAYER_NAME: add_mine_warfare_layer(iface),
    }
