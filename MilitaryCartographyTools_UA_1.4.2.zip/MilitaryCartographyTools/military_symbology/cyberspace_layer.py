# -*- coding: utf-8 -*-

"""
Builds the "Cyberspace" point layer - MIL-STD-2525D
Appendix L (Cyberspace Symbols), symbol set "60" (Table A-III). A single
symbol set (unlike Appendix J/SIGINT's five) - every entry in Table L-II
lists exactly one SymbolSetCode ("60"), so this is a plain single-domain
layer, no Dimension field needed despite L.5.3.3's own boilerplate text
about a cyberspace symbol's dimension (see below).

No modifier fields at all - L.5.3.2's own text states explicitly "There
are no modifiers in cyberspace symbols" (also noted in Table L-I's own
step 2). milsymbol's own cyberspace.js source does define 13 sIdm1 and
8 sIdm2 codes, but these read as 2525E/APP-6E-only additions with no
sanction in 2525D's own Table L-II/L-III (there is no Table L-III at
all in this appendix) - excluded entirely, the same "trust the
standard's own text over milsymbol.js's extra entries" call already
made for Activities/SIGINT.

No echelon/headquarters fields either - L.5.3.3 says a cyberspace
symbol's amplifiers "follow the amplifier requirements as stated in
[whichever dimension's] appendix" it's associated with (space/air/land/
sea surface/subsurface), the same cross-reference text Appendix J's own
SIGINT symbols use - but unlike SIGINT, Cyberspace entities are NOT
actually split across five symbol sets (Table L-II uses only "60"
throughout), so this text reads as general amplifier guidance rather
than a real per-dimension field requirement this plugin needs to model.
Combined with the same genuine ambiguity already documented in
sigint_layer.py (which of Appendix D's four different field sets "the
land appendix" would even mean), this plugin does not attempt a
per-dimension conditional field set here either - a deliberate,
documented simplification, not a guessed rule.

Entity vocabulary is sidc.py's ENTITIES["cyberspace"] - the FULL
50-entity vocabulary Table L-II actually defines (milsymbol's own
source has 72 sId entries; 22 are excluded as absent from the standard's
own table - see sidc.py's own comment on ENTITIES["cyberspace"] for the
full breakdown, including the edition-dependent icon selection this
project's SIDC version always resolves to the "D" branch of).

Military Cartography Tools
"""

from ._point_symbol_layer import add_single_domain_point_layer


OUTPUT_LAYER_NAME = 'Кіберпростір'

DEFAULT_ENTITY = "web_server"

_ENTITY_LABELS = {
    "botnet": 'Ботнет (загальне позначення)',
    "command_and_control": 'Командування та управління (C2)',
    "herder": 'Оператор ботнету',
    "callback_domain": 'Домен зворотного зв’язку',
    "zombie": 'Заражений вузол («зомбі»)',
    "infection": 'Зараження (загальне позначення)',
    "advanced_persistent_threat": 'Удосконалена стійка загроза (APT)',
    "apt_with_c2": 'APT з командним управлінням',
    "apt_with_self_propagation": 'APT із самопоширенням',
    "apt_with_c2_and_self_propagation": 'APT з командним управлінням і самопоширенням',
    "apt_other": 'Інша APT',
    "non_advanced_persistent_threat": 'Неудосконалена стійка загроза (NAPT)',
    "napt_with_c2": 'NAPT з командним управлінням',
    "napt_with_self_propagation": 'NAPT із самопоширенням',
    "napt_with_c2_and_self_propagation": 'NAPT з командним управлінням і самопоширенням',
    "napt_other": 'Інша NAPT',
    "health_and_status": 'Справність і стан (загальне позначення)',
    "normal": 'Нормальний стан',
    "network_outage_health_status": 'Недоступність мережі (стан)',
    "unknown": 'Невідомий',
    "impaired": 'Порушення працездатності',
    "device_type": 'Тип пристрою (загальне позначення)',
    "core_router": 'Магістральний маршрутизатор',
    "router": 'Маршрутизатор',
    "cross_domain_solution": 'Засіб міждоменного обміну',
    "mail_server": 'Поштовий сервер',
    "web_server": 'Вебсервер',
    "domain_server": 'Сервер домену',
    "file_server": 'Файловий сервер',
    "peer_to_peer_node": 'Вузол однорангової мережі',
    "firewall": 'Міжмережевий екран',
    "switch": 'Комутатор',
    "host": 'Хост',
    "virtual_private_network": 'Віртуальна приватна мережа (VPN)',
    "device_domain": 'Домен пристрою (загальне позначення)',
    "department_of_defense": 'Міністерство оборони США (DOD)',
    "government": 'Державний',
    "contractor": 'Підрядник',
    "supervisory_control_and_data_acquisition": 'Диспетчерське керування та збір даних (SCADA)',
    "non_government": 'Недержавний',
    "effect": 'Вплив (загальне позначення)',
    "infection_effect": 'Зараження (вплив)',
    "degradation": 'Погіршення роботи',
    "data_spoofing": 'Підміна даних',
    "data_manipulation": 'Маніпулювання даними',
    "exfiltration": 'Виведення з району дій',
    "power_outage": 'Відсутність електроживлення',
    "network_outage_effect": 'Відмова мережі (вплив)',
    "service_outage": 'Недоступність сервісу',
    "device_outage": 'Відмова пристрою',
}


def add_cyberspace_layer(iface, edition=None):

    """
    Add the "Cyberspace" layer - warns and does
    nothing if one already exists, same data-safety guard as every other
    hand-digitized layer in this plugin.
    """

    return add_single_domain_point_layer(
        iface,
        OUTPUT_LAYER_NAME,
        "cyberspace",
        _ENTITY_LABELS,
        DEFAULT_ENTITY,
        include_echelon=False,
        include_headquarters=False,
        edition=edition,
    )
