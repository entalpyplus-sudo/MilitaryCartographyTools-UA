# -*- coding: utf-8 -*-

"""
Builds the "SIGINT" point layer - MIL-STD-2525D
Appendix J (Signals Intelligence Symbols), symbol sets "50" through "54"
(Table A-III / Table J-II's own SymbolSetCode column).

Structurally different from every appendix built so far (B-G): SIGINT's
own four entities (Signal Intercept, Communications, Jammer, Radar) are
identical across FIVE symbol sets - Space (50), Air (51), Land (52), Sea
Surface (53), Subsurface (54) - chosen by which "dimension" the SIGINT
platform is actually in (J.5.3.3: "A SIGINT symbol may be in the space,
air, land, sea surface, or subsurface dimension... that symbol shall
follow the amplifier requirements as stated in [that] appendix"), not by
a different entity code per dimension the way every other appendix
works. This is exactly the case _point_symbol_layer.py's
dimension_labels/dimension_symbol_sets mechanism (added alongside this
layer) exists for - a small, fixed "Dimension" field driving a CASE
expression on symbol_set, instead of either a whole separate layer per
dimension (needless duplication for a 4-entity vocabulary) or a
ValueRelation cascading dropdown (the exact mechanism already retired
from unit_layer.py for its own crash risk).

No echelon/headquarters/sector 2 modifier fields. J.5.3.3's own
cross-reference to "the amplifier requirements as stated in [the
matching] appendix" would suggest these SHOULD vary per dimension (e.g.
Echelon for a Land SIGINT symbol) - but which of Appendix D's own four
Land layers' amplifier rules would even apply to a Land-dimension SIGINT
entity is genuinely ambiguous from the appendix's own text (Land itself
splits Unit/Civilian/Equipment/Installation, each with different
fields), so this plugin deliberately does NOT attempt to fabricate a
per-dimension conditional field set - a known, documented simplification
rather than a guessed doctrinal rule, the same kind of restriction this
project already doesn't enforce elsewhere (e.g. which sector modifier
pairs with which entity). Sector 1 modifiers ARE built (the FULL
64-entry vocabulary Table J-III actually defines - see sidc.py's own
comment on MODIFIERS["sigint_space"] for the one excluded milsymbol-only
code); there is no sector 2 at all (J.5.3.2's own text: "There are no
sector 2 modifiers in SIGINT").

Military Cartography Tools
"""

from ._point_symbol_layer import add_single_domain_point_layer


OUTPUT_LAYER_NAME = 'Радіоелектронна розвідка (SIGINT)'

DEFAULT_ENTITY = "radar"

DEFAULT_DIMENSION = "air"

_ENTITY_LABELS = {
    "signal_intercept": 'Перехоплення сигналів (загальне позначення)',
    "communications": 'Зв’язок',
    "jammer": 'Постановник перешкод',
    "radar": 'Радіолокаційна станція',
}

_DIMENSION_LABELS = {
    "space": 'Космос',
    "air": 'Повітряні об’єкти',
    "land": 'Наземні об’єкти',
    "sea_surface": 'Надводні об’єкти',
    "subsurface": 'Підводні об’єкти',
}

_DIMENSION_SYMBOL_SETS = {
    "space": "sigint_space",
    "air": "sigint_air",
    "land": "sigint_land",
    "sea_surface": "sigint_sea_surface",
    "subsurface": "sigint_subsurface",
}

_SECTOR1_LABELS = {
    "anti_aircraft_fire_control": 'Управління зенітним вогнем',
    "airborne_search_and_bombing": 'Повітряний пошук і бомбардування',
    "airborne_intercept": 'Повітряне перехоплення',
    "altimeter": 'Висотомір',
    "airborne_reconnaissance_and_mapping": 'Повітряна розвідка та картографування',
    "air_traffic_control": 'Управління повітряним рухом',
    "beacon_transponder_not_iff": 'Радіомаяк-відповідач (не системи «свій — чужий»)',
    "battlefield_surveillance": 'Спостереження за полем бою',
    "controlled_approach": 'Заходження на посадку під управлінням',
    "controlled_intercept": 'Перехоплення під управлінням',
    "cellular_mobile": 'Стільниковий / мобільний зв’язок',
    "coastal_surveillance": 'Спостереження за узбережжям',
    "decoy_mimic": 'Хибна ціль / імітатор',
    "data_transmission": 'Передавання даних',
    "earth_surveillance": 'Спостереження за Землею',
    "early_warning": 'Раннє попередження',
    "fire_control": 'Управління вогнем',
    "ground_mapping": 'Картографування місцевості',
    "height_finding": 'Визначення висоти',
    "harbor_surveillance": 'Спостереження за гаванню',
    "identification_friend_or_foe_interrogator": 'Запитувач системи «свій — чужий»',
    "instrument_landing_system": 'Система посадки за приладами',
    "ionospheric_sounding": 'Іоносферне зондування',
    "identification_friend_or_foe_transponder": 'Відповідач системи «свій — чужий»',
    "barrage_jammer": 'Постановник загороджувальних перешкод',
    "click_jammer": 'Постановник імпульсних перешкод типу Click',
    "deceptive_jammer": 'Постановник імітаційних перешкод',
    "frequency_swept_jammer": 'Постановник перешкод із перебудовою частоти',
    "jammer_general": 'Постановник перешкод загального призначення',
    "noise_jammer": 'Постановник шумових перешкод',
    "pulsed_jammer": 'Постановник імпульсних перешкод',
    "repeater_jammer": 'Ретрансляційний постановник перешкод',
    "spot_noise_jammer": 'Постановник прицільних шумових перешкод',
    "transponder_jammer": 'Постановник перешкод відповідачам',
    "missile_acquisition": 'Захоплення ракети',
    "missile_control": 'Управління ракетою',
    "missile_downlink": 'Низхідний канал зв’язку ракети',
    "meteorological": 'Метеорологічний',
    "multi_function": 'Багатофункціональний',
    "missile_guidance": 'Наведення ракети',
    "missile_homing": 'Самонаведення ракети',
    "missile_tracking": 'Супровід ракети',
    "navigational_general": 'Навігація загального призначення',
    "navigational_distance_measuring_equipment": 'Навігація / далекомірне обладнання',
    "navigation_terrain_following": 'Навігація / огинання рельєфу',
    "navigational_weather_avoidance": 'Навігація / обхід небезпечних метеоявищ',
    "omni_line_of_sight_los": 'Всеспрямований зв’язок прямої видимості (LOS)',
    "proximity_use": 'Застосування неконтактного датчика',
    "point_to_point_line_of_sight_los": 'Зв’язок між двома точками прямої видимості (LOS)',
    "instrumentation": 'Вимірювальна апаратура',
    "range_only": 'Лише визначення дальності',
    "sonobuoy": 'Гідроакустичний буй',
    "satellite_downlink": 'Низхідний супутниковий канал',
    "space": 'Космос',
    "surface_search": 'Пошук надводних цілей',
    "shell_tracking": 'Супровід артилерійських снарядів',
    "satellite_uplink": 'Висхідний супутниковий канал',
    "target_acquisition": 'Виявлення та визначення координат цілей',
    "target_illumination": 'Підсвічування цілі',
    "tropospheric_scatter": 'Тропосферний зв’язок',
    "target_tracking": 'Супровід цілі',
    "unknown": 'Невідомий',
    "video_remoting": 'Дистанційне передавання відео',
    "experimental": 'Експериментальний',
}


def add_sigint_layer(iface, edition=None):

    """
    Add the "SIGINT" layer - warns and does nothing
    if one already exists, same data-safety guard as every other
    hand-digitized layer in this plugin.
    """

    return add_single_domain_point_layer(
        iface,
        OUTPUT_LAYER_NAME,
        # The literal fallback symbol_set - never actually used once the
        # "dimension" field has a real value (its default is set below),
        # but build_single_domain_point_layer() always needs one.
        "sigint_air",
        _ENTITY_LABELS,
        DEFAULT_ENTITY,
        include_echelon=False,
        include_headquarters=False,
        sector1_labels=_SECTOR1_LABELS,
        dimension_labels=_DIMENSION_LABELS,
        dimension_symbol_sets=_DIMENSION_SYMBOL_SETS,
        default_dimension=DEFAULT_DIMENSION,
        edition=edition,
    )
