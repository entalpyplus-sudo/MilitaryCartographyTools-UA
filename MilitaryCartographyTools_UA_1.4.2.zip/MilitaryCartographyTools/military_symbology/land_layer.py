# -*- coding: utf-8 -*-

"""
Builds four "Land <Domain>" point layers -
MIL-STD-2525D Appendix D (Land Symbols), one per D.6-D.9 section, each a
genuinely distinct SIDC symbol_set (Table A-III: Land Unit=10, Land
Civilian Unit/Organization=11, Land Equipment=15, Land Installation=20).

Unlike Space/Air (military_symbology/space_layer.py, air_layer.py),
these are NOT merged into one layer via entity_symbol_set_overrides -
that mechanism is meant for folding in a small single-entity companion
(Space/Air Missile), not four substantial, independently-sized
vocabularies. Four separate layers, added together under one toolbar
action, mirrors c2_measures.py's own "one action, several layers"
precedent instead.

Land Unit ("ground_unit" in sidc.py - kept as the existing key rather
than renamed, since it's already used throughout sidc.py/tests/roadmap
and Table A-III's own code "10" doesn't change either way) moved here
2026-08-08 from military_symbology/unit_layer.py, which used to share it
across a cascading multi-domain dropdown with air/sea_surface/subsurface
- see that module's own docstring for what's left there.

Field applicability (echelon/headquarters) follows Chapter 5's Table VII
literally, since Appendix D's own Table D-II doesn't restate per-domain
columns the way the base document's Table VII does: Field B (Echelon)
applies only to Units (the "U" column) - so Land Unit gets it, Land
Civilian/Equipment/Installation don't. Field S (Headquarters Staff
Indicator) applies to Units/Equipment/Installations (not SIGINT) - all
four Land layers get it, including Land Civilian, whose own "civilian
unit/organization" framing reads closest to Table VII's "U" category for
this purpose.

Entity vocabulary: Land Unit is milsymbol-3.0.4's own
src/numbersidc/sidc/landunit.js, kept as the pre-existing curated 50-
entity subset (of 219 total) already in sidc.py's ENTITIES["ground_unit"]
- re-verified entity-by-entity against that source directly this session
(every code confirmed correct, no bugs found). Land Civilian is
landcivilian.js's FULL 11-entity vocabulary (small enough that no
curation is needed). Land Equipment (153 entities, of 229 total in
landequipment.js) and Land Installation (130 entities, of 131 total in
landinstallation.js) are curated subsets - see sidc.py's own
ENTITIES["land_equipment"]/["land_installation"] comments for the
categories covered and for two follow-up fixes, both caught by the user,
not self-discovered: (1) the first pass at both (50-ish entries each)
silently dropped an entire axis of real entries - Equipment's weapon/
vehicle weight-class variants, Installation's remaining sibling facility
types within a category (e.g. ATM/bullion storage/federal reserve bank
alongside bank) - fixed the same day by a full multi-line-aware parse of
each source file rather than another round of shallow spot-picking; (2)
those newly-added weapon variants were then mislabeled Short/
Intermediate/Long Range - trusted milsymbol.js's own internal icon-part
constant names (e.g. "GR.EQ.SHORT RANGE") instead of the standard's own
printed text, which actually reads Light/Medium/Heavy for every weapon
category except Rifle (Single Shot/Semiautomatic/Automatic, confirmed
directly against Table D-XI, printed page 229) - fixed by renaming the
entity keys/labels to match the standard's own wording, not milsymbol's
internal naming. (3) Land Equipment's law-enforcement family
(Table A-XXV, codes 1700xx-1711xx) shipped with only four of its twelve
entries through 1.0.3 - generic, Border Patrol, Customs, DEA - stopping
mid-family rather than at a category boundary, so it read as complete
when it was not; the eight missing entries were added 2026-08-18 after
confirming milsymbol draws every one of them. Note the family's tail is
NOT shared with the Activities or Land Installation law-enforcement
lists: 171000 is Coast Guard here, and there is no Prison or Law
Enforcement Vessel in Land Equipment at all.
(4) Land Installation's own law-enforcement family had the same shape of
problem plus a worse one, both fixed 2026-08-18 after the maintainer read
the live dropdown: ATF (112101) and Police (112107) were simply absent,
and 112111 - printed **Coast Guard** in Table A-XXVII - was offered to
users as "Law Enforcement Vessel", a row that does not exist in that
table at all (the standard's real one is Sea Surface 140300). Two labels
also read "Agency" where the standard reads "Administration" (DEA, TSA).
Every fix here changed labels and added entries; no shipped entity KEY
was renamed, because keys are written into saved features.
(5) Land Installation's vocabulary completed 2026-08-18 (D-3): 99 -> 130
entities, every code Table A-XXVII prints. The only code in
landinstallation.js left out is 112001, a grenade icon in a gap the
standard does not use. Two codes we already shipped are the same case -
112300 "Home" and 120803 "Airport" appear NOWHERE in MIL-STD-2525D - and
are kept, since they are in users' saved features, but their labels now
say "(non-standard)". The standard's own airport is 121301 Airport/Air
Base, which was among the 31 added.
The same pass corrected twelve labels against Table A-XXVII, two of them
the Coast Guard defect again: 120500 was labelled "Electric Power" and
121400 "Water (Generic)", but both are GROUP headers (Energy Facility
Infrastructure / Water Supply Infrastructure) and the standard's real
Electric Power and Water are their children 120501 and 121410 - both
added in this pass, so leaving the parents alone would have put identical
text on two rows. The children take `electric_power_facility` and
`water_facility` because the legacy keys already held the obvious names
and keys are never renamed here.

Sector 1/2 modifiers deliberately NOT built for any of these four layers
in this pass - Land Unit alone has ~50+ sector 1 and ~50+ sector 2
modifier codes (Tables D-VI/D-VII), and all four domains combined would
be a disproportionately large addition on top of an already-large
appendix; a documented, deliberate scope decision (same "not everything
has to be built every mini-phase" precedent already used for
ground_unit's own entity curation), not an oversight.

Military Cartography Tools
"""

from ._point_symbol_layer import add_single_domain_point_layer


UNIT_LAYER_NAME = 'Сухопутний підрозділ'

CIVILIAN_LAYER_NAME = 'Цивільні наземні об’єкти'

EQUIPMENT_LAYER_NAME = 'Наземна техніка'

INSTALLATION_LAYER_NAME = 'Наземні об’єкти інфраструктури'

DEFAULT_UNIT_ENTITY = "infantry"

DEFAULT_CIVILIAN_ENTITY = "civilian"

DEFAULT_EQUIPMENT_ENTITY = "tank"

DEFAULT_INSTALLATION_ENTITY = "military"

# Display labels - kept separate from sidc.py's own vocabulary dicts,
# which are the data model (real SIDC component codes), not presentation
# text. Reused verbatim from unit_layer.py's own former
# _ENTITY_LABELS_BY_SYMBOL_SET["ground_unit"] (moved here, not
# retyped) - organised by the same functional-area breakdown (command/
# signal, maneuver, fires, air defense, combat support, intelligence,
# combat service support).
_UNIT_ENTITY_LABELS = {
    # Command & signal
    "command_and_control": 'Командування та управління',
    "signal": 'Підрозділ зв’язку',
    "liaison": 'Взаємодія',
    # Maneuver
    "infantry": 'Піхотний підрозділ',
    "infantry_amphibious": 'Амфібійна піхота',
    "motorized_infantry": 'Мотопіхотний підрозділ',
    "mechanized_infantry": 'Механізований підрозділ',
    "armor": 'Танковий підрозділ',
    "reconnaissance": 'Розвідка',
    "antitank": 'Протитанковий підрозділ',
    "combined_arms": 'Загальновійськовий підрозділ',
    "aviation_rotary_wing": 'Армійська авіація (вертольоти)',
    "aviation_fixed_wing": 'Авіація (літаки)',
    "air_assault": 'Десантно-штурмовий підрозділ',
    "amphibious": 'Морський десант',
    "special_forces": 'Підрозділ спеціального призначення',
    "ranger": 'Рейнджери',
    "sniper": 'Снайпери',
    "surveillance": 'Спостереження',
    "unmanned_systems": 'Підрозділ безпілотних систем',
    # Fires
    "field_artillery": 'Артилерійський підрозділ',
    "field_artillery_self_propelled": 'Самохідний артилерійський підрозділ',
    "field_artillery_observer": 'Артилерійський спостерігач',
    "mortar": 'Міномет',
    "missile": 'Ракета',
    "joint_fire_support": 'Об’єднана вогнева підтримка',
    # Air defense
    "air_defense": 'Протиповітряна оборона',
    "air_defense_gun": 'Зенітна гармата',
    "air_defense_missile": 'Зенітна ракета',
    "air_and_missile_defense": 'Протиповітряна та протиракетна оборона',
    # Combat support
    "engineer": 'Інженерний підрозділ',
    "engineer_mechanized": 'Механізований інженерний підрозділ',
    "cbrn": 'Радіаційний, хімічний, біологічний та ядерний захист',
    "explosive_ordnance_disposal": 'Знешкодження вибухонебезпечних предметів (EOD)',
    "military_police": 'Військовий правопорядок (MP)',
    "mine_clearing": 'Розмінування',
    "search_and_rescue": 'Пошук і рятування',
    "security": 'Охорона',
    # Intelligence & electronic warfare
    "military_intelligence": 'Військова розвідка',
    "electronic_warfare": 'Радіоелектронна боротьба (РЕБ)',
    "counter_intelligence": 'Контррозвідка',
    "sensor": 'Сенсор',
    # Combat service support
    "sustainment": 'Підрозділ забезпечення',
    "maintenance": 'Ремонтний підрозділ',
    "medical": 'Медичний підрозділ',
    "supply": 'Підрозділ постачання',
    "transportation": 'Транспортне забезпечення',
    "quartermaster": 'Речове та продовольче забезпечення',
    "ordnance": 'Служба озброєння',
    "ammunition": 'Боєприпаси',
    "petroleum_oil_lubricants": 'Пально-мастильні матеріали (ПММ)',
}

_CIVILIAN_ENTITY_LABELS = {
    "civilian": 'Цивільний об’єкт (загальне позначення)',
    "environmental_protection": 'Охорона довкілля',
    "government_organization": 'Державна установа',
    "individual": 'Окрема особа',
    "group": 'Група',
    "killing_victim": 'Жертва вбивства',
    "killing_victims": 'Жертви вбивства',
    "victim_of_attempted_crime": 'Потерпілий від замаху на злочин',
    "spy": 'Шпигун',
    "composite_loss": 'Сукупні втрати',
    "emergency_medical_operation": 'Невідкладна медична допомога',
}

_EQUIPMENT_ENTITY_LABELS = {
    "weapon": 'Зброя (загальне позначення)',
    "rifle": 'Гвинтівка',
    "rifle_single_shot": 'Однозарядна гвинтівка',
    "rifle_semiautomatic": 'Самозарядна гвинтівка',
    "rifle_automatic": 'Автоматична гвинтівка',
    "machine_gun": 'Кулемет',
    "machine_gun_light": 'Кулемет (легкий клас)',
    "machine_gun_medium": 'Кулемет (середній клас)',
    "machine_gun_heavy": 'Кулемет (важкий клас)',
    "grenade_launcher": 'Гранатомет',
    "grenade_launcher_light": 'Гранатомет (легкий клас)',
    "grenade_launcher_medium": 'Гранатомет (середній клас)',
    "grenade_launcher_heavy": 'Гранатомет (важкий клас)',
    "flame_thrower": 'Вогнемет',
    "air_defense_gun": 'Зенітна гармата',
    "air_defense_gun_light": 'Зенітна гармата (легкий клас)',
    "air_defense_gun_medium": 'Зенітна гармата (середній клас)',
    "air_defense_gun_heavy": 'Зенітна гармата (важкий клас)',
    "antitank_gun": 'Протитанкова гармата',
    "antitank_gun_light": 'Протитанкова гармата (легкий клас)',
    "antitank_gun_medium": 'Протитанкова гармата (середній клас)',
    "antitank_gun_heavy": 'Протитанкова гармата (важкий клас)',
    "direct_fire_gun": 'Гармата прямої наводки',
    "direct_fire_gun_light": 'Гармата прямої наводки (легкий клас)',
    "direct_fire_gun_medium": 'Гармата прямої наводки (середній клас)',
    "direct_fire_gun_heavy": 'Гармата прямої наводки (важкий клас)',
    "recoilless_gun": 'Безвідкатна гармата',
    "recoilless_gun_light": 'Безвідкатна гармата (легкий клас)',
    "recoilless_gun_medium": 'Безвідкатна гармата (середній клас)',
    "recoilless_gun_heavy": 'Безвідкатна гармата (важкий клас)',
    "howitzer": 'Гаубиця',
    "howitzer_light": 'Гаубиця (легкий клас)',
    "howitzer_medium": 'Гаубиця (середній клас)',
    "howitzer_heavy": 'Гаубиця (важкий клас)',
    "missile_launcher": 'Ракетна пускова установка',
    "missile_launcher_light": 'Ракетна пускова установка (легкий клас)',
    "missile_launcher_medium": 'Ракетна пускова установка (середній клас)',
    "missile_launcher_heavy": 'Ракетна пускова установка (важкий клас)',
    "air_defense_missile_launcher_surface_to_air": 'Пускова установка зенітних ракет',
    "air_defense_missile_launcher_surface_to_air_light": 'Пускова установка зенітних ракет (легкий клас)',
    "air_defense_missile_launcher_surface_to_air_medium": 'Пускова установка зенітних ракет (середній клас)',
    "air_defense_missile_launcher_surface_to_air_heavy": 'Пускова установка зенітних ракет (важкий клас)',
    "antitank_missile_launcher": 'Протитанкова ракетна пускова установка',
    "antitank_missile_launcher_light": 'Протитанкова ракетна пускова установка (легкий клас)',
    "antitank_missile_launcher_medium": 'Протитанкова ракетна пускова установка (середній клас)',
    "antitank_missile_launcher_heavy": 'Протитанкова ракетна пускова установка (важкий клас)',
    "surface_to_surface_missile_launcher": 'Пускова установка ракет «земля — земля»',
    "surface_to_surface_missile_launcher_light": 'Пускова установка ракет «земля — земля» (легкий клас)',
    "surface_to_surface_missile_launcher_medium": 'Пускова установка ракет «земля — земля» (середній клас)',
    "surface_to_surface_missile_launcher_heavy": 'Пускова установка ракет «земля — земля» (важкий клас)',
    "mortar": 'Міномет',
    "mortar_light": 'Міномет (легкий клас)',
    "mortar_medium": 'Міномет (середній клас)',
    "mortar_heavy": 'Міномет (важкий клас)',
    "single_rocket_launcher": 'Одноствольна реактивна пускова установка',
    "single_rocket_launcher_light": 'Одноствольна реактивна пускова установка (легкий клас)',
    "single_rocket_launcher_medium": 'Одноствольна реактивна пускова установка (середній клас)',
    "single_rocket_launcher_heavy": 'Одноствольна реактивна пускова установка (важкий клас)',
    "multiple_rocket_launcher": 'Реактивна система залпового вогню',
    "multiple_rocket_launcher_light": 'Реактивна система залпового вогню (легкий клас)',
    "multiple_rocket_launcher_medium": 'Реактивна система залпового вогню (середній клас)',
    "multiple_rocket_launcher_heavy": 'Реактивна система залпового вогню (важкий клас)',
    "antitank_rocket_launcher": 'Протитанковий реактивний гранатомет',
    "antitank_rocket_launcher_light": 'Протитанковий реактивний гранатомет (легкий клас)',
    "antitank_rocket_launcher_medium": 'Протитанковий реактивний гранатомет (середній клас)',
    "antitank_rocket_launcher_heavy": 'Протитанковий реактивний гранатомет (важкий клас)',
    "non_lethal_weapon": 'Нелетальна зброя',
    "taser": 'Електрошоковий пристрій',
    "water_cannon": 'Водомет',
    "armoured_vehicle": 'Броньована машина (загальне позначення)',
    "armored_fighting_vehicle": 'Бойова броньована машина',
    "armored_fighting_vehicle_command_and_control": 'Командно-штабна броньована машина',
    "armored_personnel_carrier": 'Бронетранспортер',
    "armored_personnel_carrier_medical_evacuation": 'Медико-евакуаційний бронетранспортер',
    "tank": 'Танк',
    "tank_light": 'Танк (легкий клас)',
    "tank_medium": 'Танк (середній клас)',
    "tank_heavy": 'Танк (важкий клас)',
    "tank_recovery_vehicle": 'Броньована ремонтно-евакуаційна машина',
    "bridge": 'Міст',
    "fixed_bridge": 'Стаціонарний міст',
    "folding_girder_bridge": 'Розкладний балковий міст',
    "hollow_deck_bridge": 'Міст із порожнистим настилом',
    "drilling": 'Буріння',
    "earthmover": 'Землерийна машина',
    "multifunctional_earthmover_digger": 'Багатофункціональна землерийна машина / екскаватор',
    "mine_clearing_equipment": 'Засоби розмінування',
    "mine_clearing_equipment_tank": 'Танкові засоби розмінування',
    "mine_laying": 'Встановлення мін',
    "dozer": 'Бульдозер',
    "dozer_armored": 'Броньований бульдозер',
    "utility_vehicle": 'Допоміжний автомобіль',
    "bus": 'Автобус',
    "semi_trailer_truck": 'Сідловий тягач із напівпричепом',
    "semi_trailer_truck_light": 'Сідловий тягач із напівпричепом (легкий клас)',
    "semi_trailer_truck_medium": 'Сідловий тягач із напівпричепом (середній клас)',
    "semi_trailer_truck_heavy": 'Сідловий тягач із напівпричепом (важкий клас)',
    "train_locomotive": 'Залізничний локомотив',
    "railcar": 'Залізничний вагон',
    "automobile": 'Легковий автомобіль',
    "automobile_light": 'Легковий автомобіль (легкий клас)',
    "automobile_medium": 'Легковий автомобіль (середній клас)',
    "automobile_heavy": 'Легковий автомобіль (важкий клас)',
    "open_bed_truck": 'Бортовий вантажний автомобіль',
    "open_bed_truck_light": 'Бортовий вантажний автомобіль (легкий клас)',
    "open_bed_truck_medium": 'Бортовий вантажний автомобіль (середній клас)',
    "open_bed_truck_heavy": 'Бортовий вантажний автомобіль (важкий клас)',
    "multiple_passenger_vehicle": 'Багатомісний пасажирський автомобіль',
    "multiple_passenger_vehicle_light": 'Багатомісний пасажирський автомобіль (легкий клас)',
    "multiple_passenger_vehicle_medium": 'Багатомісний пасажирський автомобіль (середній клас)',
    "multiple_passenger_vehicle_heavy": 'Багатомісний пасажирський автомобіль (важкий клас)',
    "civilian_utility_vehicle": 'Цивільний допоміжний автомобіль',
    "civilian_utility_vehicle_light": 'Цивільний допоміжний автомобіль (легкий клас)',
    "civilian_utility_vehicle_medium": 'Цивільний допоміжний автомобіль (середній клас)',
    "civilian_utility_vehicle_heavy": 'Цивільний допоміжний автомобіль (важкий клас)',
    "jeep_type_vehicle": 'Автомобіль підвищеної прохідності',
    "jeep_type_vehicle_light": 'Автомобіль підвищеної прохідності (легкий клас)',
    "jeep_type_vehicle_medium": 'Автомобіль підвищеної прохідності (середній клас)',
    "jeep_type_vehicle_heavy": 'Автомобіль підвищеної прохідності (важкий клас)',
    "known_insurgent_vehicle": 'Підтверджений транспортний засіб повстанців',
    "law_enforcement": 'Правоохоронні органи',
    "bureau_of_alcohol_tobacco_firearms_and_explosives":
        'Бюро алкоголю, тютюну, вогнепальної зброї та вибухових речовин США (ATF)',
    "border_patrol": 'Прикордонний патруль',
    "customs_service": 'Митна служба',
    "drug_enforcement_agency": 'Управління боротьби з наркотиками США (DEA)',
    "department_of_justice": 'Міністерство юстиції США (DOJ)',
    "federal_bureau_of_investigation": 'Федеральне бюро розслідувань США (FBI)',
    "police": 'Поліція',
    # "secret" here is the US Secret Service, a MIL-STD-2525D entity
    # name - not a credential. Suppressions are for the scanners' own
    # keyword heuristics (1.0.0's automated review, 2026-08-17).
    "united_states_secret_service": 'Секретна служба США (USSS)',  # nosec B105 # pragma: allowlist secret
    "transportation_security_administration":
        'Управління транспортної безпеки США (TSA)',
    "coast_guard": 'Берегова охорона',
    "us_marshals_service": 'Служба маршалів США',
    "missile_support": 'Забезпечення ракетних підрозділів (загальне позначення)',
    "missile_transloader": 'Транспортно-перевантажувальна машина ракет',
    "missile_transporter": 'Транспортер ракет',
    "missile_crane_loading_device": 'Кран / пристрій завантаження ракет',
    "pack_animal": 'В’ючна тварина',
    "bomb": 'Бомба',
    "booby_trap": 'Міна-пастка',
    "cbrn_equipment": 'Обладнання РХБ захисту',
    "computer_system": 'Комп’ютерна система',
    "command_launch_equipment": 'Командно-пускове обладнання (CLE)',
    "generator_set": 'Генераторна установка',
    "laser": 'Лазер',
    "tent": 'Намет',
    "land_mine": 'Наземна міна',
    "antipersonnel_land_mine": 'Протипіхотна міна',
    "antitank_mine": 'Протитанкова міна',
    "improvised_explosive_device": 'Саморобний вибуховий пристрій (СВП)',
    "sensor": 'Сенсор',
    "radar": 'Радіолокаційна станція',
    "fire_protection": 'Протипожежний захист',
    "manual_track": 'Ручний супровід',
}

_INSTALLATION_ENTITY_LABELS = {
    # Table A-XXVII prints 110000 as "Military/Civilian", but the
    # maintainer's own call (2026-08-18) is to keep the shorter
    # "Military (Generic)" a user already knows in the dropdown.
    "military": 'Військовий об’єкт (загальне позначення)',
    "aircraft_production_and_assembly": 'Виробництво та складання літальних апаратів',
    "ammunition_and_explosives_assembly": 'Боєприпаси та вибухові речовини / спорядження',
    "ammunition_cache": 'Схованка боєприпасів',
    "armament_production": 'Виробництво озброєння',
    "black_list_location": 'Об’єкт чорного списку',
    "cbrn": 'РХБ захист (CBRN)',
    "engineering_equipment_production": 'Виробництво інженерного обладнання',
    "bridge": 'Міст',
    "equipment_manufacture": 'Виробництво техніки',
    "government": 'Державне керівництво',
    "gray_list_location": 'Об’єкт сірого списку',
    "mass_grave_site": 'Місце масового поховання',
    "materiel": 'Матеріальні засоби',
    "mine": 'Міна',
    "missile_and_space_system_production":
        'Виробництво ракетних і космічних систем',
    "nuclear_non_cbrn_defense": 'Ядерний об’єкт (не РХБ захист)',
    "printed_media": 'Друковані засоби інформації',
    "safe_house": 'Конспіративна квартира',
    "white_list_location": 'Об’єкт білого списку',
    "tented_camp": 'Наметовий табір переміщених осіб / біженців / евакуйованих',
    "camp": 'Табір',
    "training_camp": 'Навчальний табір',
    "warehouse_storage_facility": 'Склад / сховище',
    "law_enforcement": 'Правоохоронні органи (загальне позначення)',
    "bureau_of_alcohol_tobacco_firearms_and_explosives":
        'Бюро алкоголю, тютюну, вогнепальної зброї та вибухових речовин США (ATF)',
    "border_patrol": 'Прикордонний патруль',
    "customs_service": 'Митна служба',
    # Table A-XXVII reads "Drug Enforcement Administration (DEA)" and
    # "Transportation Security Administration (TSA)". Both labels said
    # "Agency" until 2026-08-18. Keys keep their shipped spellings -
    # they are written into saved features' "entity" field - so only the
    # text a user reads in the dropdown changed.
    "drug_enforcement_agency": 'Управління боротьби з наркотиками США (DEA)',
    "department_of_justice": 'Міністерство юстиції США (DOJ)',
    "federal_bureau_of_investigation": 'Федеральне бюро розслідувань США (FBI)',
    "police": 'Поліція',
    "prison": 'В’язниця',
    # "secret" here is the US Secret Service, a MIL-STD-2525D entity
    # name - not a credential. Suppressions are for the scanners' own
    # keyword heuristics (1.0.0's automated review, 2026-08-17).
    "secret_service": 'Секретна служба США (USSS)',  # nosec B105 # pragma: allowlist secret
    "transportation_security_agency": 'Управління транспортної безпеки США (TSA)',
    # Table A-XXVII prints 112111 as Coast Guard; there is no "Law
    # Enforcement Vessel" row in this table. The key is left alone (it
    # is in users' saved features); this is the text they read.
    "law_enforcement_vessel": 'Берегова охорона',
    "us_marshals_service": 'Служба маршалів США',
    "emergency_operation": 'Аварійно-рятувальна операція',
    "fire_protection": 'Пожежна частина',
    "emergency_medical_operation": 'Невідкладна медична допомога',
    # 112300 and 120803 render in milsymbol but appear NOWHERE in
    # MIL-STD-2525D - not in Table A-XXVII, not anywhere in the
    # document. Kept (they shipped in 1.0.3 and are in users' saved
    # features) but marked in the label, so nobody reads them as
    # standard entities. Note the standard's own airport is 121301
    # Airport/Air Base, added 2026-08-18.
    "home": 'Житловий будинок (нестандартне позначення)',
    "infrastructure": 'Інфраструктура (загальне позначення)',
    "agriculture_and_food_infrastructure": 'Сільськогосподарська та продовольча інфраструктура (загальне позначення)',
    "agricultural_laboratory": 'Сільськогосподарська лабораторія',
    "animal_feedlot": 'Майданчик відгодівлі тварин',
    "commercial_food_distribution_center":
        'Комерційний центр розподілу продовольства',
    "farm_ranch": 'Ферма / ранчо',
    "food_distribution": 'Роздача продовольства',
    "food_distribution_production": 'Центр виробництва продовольства',
    "food_distribution_retail": 'Роздрібна торгівля продовольством',
    "grain_storage": 'Зерносховище',
    "banking_finance_and_insurance_infrastructure": 'Банківська, фінансова та страхова інфраструктура (загальне позначення)',
    "atm": 'Банкомат',
    "bank": 'Банк',
    "bullion_storage": 'Сховище дорогоцінних металів',
    "economic_infrastructure_asset": 'Об’єкт економічної інфраструктури',
    "federal_reserve_bank": 'Федеральний резервний банк',
    "financial_exchange": 'Фінансова біржа',
    "financial_services_other": 'Інші фінансові послуги',
    "commercial_infrastructure": 'Комерційна інфраструктура (загальне позначення)',
    "chemical_plant": 'Хімічний завод',
    "firearms_manufacturer": 'Виробник вогнепальної зброї',
    "firearms_retailer": 'Магазин вогнепальної зброї',
    "hazardous_material_production": 'Виробництво небезпечних речовин',
    "hazardous_material_storage": 'Зберігання небезпечних речовин',
    "industrial_site": 'Промисловий об’єкт',
    "landfill": 'Полігон відходів',
    "pharmaceutical_manufacturer": 'Фармацевтичне виробництво',
    "contaminated_hazardous_waste_site": 'Забруднений майданчик небезпечних відходів',
    "toxic_release_inventory": 'Облік викидів токсичних речовин',
    "educational_facilities_infrastructure": 'Інфраструктура освітніх закладів (загальне позначення)',
    "college_university": 'Коледж / університет',
    "school": 'Школа',
    # 120500 is the GROUP header - Table A-XXVII prints it "Energy
    # Facility Infrastructure". The standard's own "Electric Power" is
    # its child 120501, added 2026-08-18 as "electric_power_facility"
    # because this legacy key already occupied the obvious name and is
    # written into saved features. Same shape as the water pair below.
    "electric_power": 'Енергетична інфраструктура (загальне позначення)',
    "electric_power_facility": 'Електроенергетика',
    "generation_station": 'Електростанція',
    "natural_gas_facility": 'Газовий об’єкт',
    "petroleum_facility": 'Нафтовий об’єкт',
    "petroleum_gas_oil": 'Нафта / газ / олива',
    "propane_facility": 'Пропановий об’єкт',
    "government_site_infrastructure": 'Інфраструктура державних об’єктів',
    "medical_infrastructure": 'Медична інфраструктура (загальне позначення)',
    "medical": 'Медичний підрозділ',
    "medical_treatment_facility": 'Лікувальний заклад',
    "military_infrastructure": 'Військова інфраструктура (загальне позначення)',
    "military_armory": 'Військовий склад озброєння',
    "base": 'Військова база',
    "airport": 'Аеропорт (нестандартне позначення)',
    "postal_service_infrastructure": 'Поштова інфраструктура (загальне позначення)',
    "postal_distribution_center": 'Поштовий сортувальний центр',
    "post_office": 'Поштове відділення',
    "public_venues_infrastructure": 'Інфраструктура громадських місць (загальне позначення)',
    "enclosed_facility": 'Закритий об’єкт громадського користування',
    "open_facility": 'Відкритий громадський майданчик',
    "recreational_area": 'Зона відпочинку',
    "religious_institution": 'Релігійна установа',
    "special_needs_infrastructure": 'Інфраструктура для осіб з особливими потребами (загальне позначення)',
    "adult_day_care": 'Денний догляд за дорослими',
    "child_day_care": 'Денний догляд за дітьми',
    "elder_care": 'Догляд за літніми людьми',
    "telecommunications_infrastructure": 'Телекомунікаційна інфраструктура (загальне позначення)',
    "broadcast_transmitter_antenna": 'Антена передавача мовлення',
    "telecommunications": 'Телекомунікації',
    "telecommunications_tower": 'Телекомунікаційна вежа',
    "transportation": 'Транспортне забезпечення (загальне позначення)',
    "airport_air_base": 'Аеропорт / авіабаза',
    "air_traffic_control_facility": 'Об’єкт управління повітряним рухом',
    "bus_station": 'Автобусна станція',
    "ferry": 'Поромний термінал',
    "helicopter_landing_site": 'Вертолітний посадковий майданчик',
    "maintenance": 'Об’єкт технічного обслуговування',
    "railhead": 'Залізничний пункт вивантаження / станція',
    "rest_stop": 'Майданчик відпочинку',
    "sea_port_naval_base": 'Морський порт / військово-морська база',
    "ship_yard": 'Суднобудівна верф',
    "toll_facility": 'Пункт оплати проїзду',
    "traffic_inspection_facility": 'Об’єкт транспортного контролю',
    "tunnel": 'Тунель',
    # 121400 is the GROUP header - "Water Supply Infrastructure". The
    # standard's own "Water" is its child 121410, added as
    # "water_facility" for the same legacy-key reason as electric power.
    "water": 'Інфраструктура водопостачання (загальне позначення)',
    "control_valve": 'Регулювальний клапан',
    "dam": 'Дамба',
    "discharge_outfall": 'Місце скидання стічних вод',
    "ground_water_well": 'Свердловина підземних вод',
    "pumping_station": 'Насосна станція',
    "reservoir": 'Водосховище',
    "storage_tower": 'Водонапірна башта',
    "surface_water_intake": 'Водозабір із поверхневого джерела',
    "wastewater_treatment_facility": 'Споруди очищення стічних вод',
    "water_facility": 'Вода',
    "water_purification": 'Водопідготовка',
}



# D-4, 2026-08-18: sector 1/2 modifier vocabularies for three of the four
# Land layers. Land Unit's own (Tables D-VI/D-VII, 99 + 85 codes in
# milsymbol) is a separate pass - see docs/roadmap.md.
#
# These follow MIL-STD-2525D's tables, not milsymbol's supersets; see
# sidc.py's MODIFIERS comment for exactly what was left out and why.
# D-4b, 2026-08-18: Land Unit's own sector 1/2 modifiers (Tables D-VI/
# D-VII) - the largest of the four Land layers by a wide margin, and the
# one that took real verification. See sidc.py's own MODIFIERS
# ["ground_unit"] comment for what went wrong trusting milsymbol/TSV
# sources directly here: 8 sector-1 codes where milsymbol's own
# _STD2525 ternary picks the wrong branch for MIL-STD-2525D, and both
# tables silently extended past where the real standard's tables stop
# (D-VI ends at 78, D-VII at 57 - not the 99/78 milsymbol defines).
_UNIT_SECTOR1_LABELS = {
    "airmobile_air_assault": 'Аеромобільний / десантно-штурмовий',
    "area": 'Район',
    "attack": 'Атака',
    "biological": 'Біологічний',
    "border": 'Кордон',
    "bridging": 'Наведення мостів',
    "chemical": 'Хімічний',
    "close_protection": 'Особиста охорона',
    "combat": 'Бойовий',
    "command_and_control": 'Командування та управління',
    "communications_contingency_package": 'Комплект засобів зв’язку на випадок надзвичайних обставин',
    "construction": 'Будівництво',
    "cross_cultural_communication": 'Міжкультурна комунікація',
    "crowd_and_riot_control": 'Контроль натовпу та масових заворушень',
    "decontamination": 'Спеціальна обробка',
    "detention": 'Утримання під вартою',
    "direct_communications": 'Прямий зв’язок',
    "diving": 'Водолазні роботи',
    "division": 'Дивізія',
    "dog": 'Службовий собака',
    "drilling": 'Буріння',
    "electro_optical": 'Оптико-електронний',
    "enhanced": 'Посилений',
    "explosive_ordnance_disposal": 'Знешкодження вибухонебезпечних предметів (EOD)',
    "fire_direction_center": 'Центр управління вогнем',
    "force": 'Сили',
    "forward": 'Передовий',
    "ground_station_module": 'Модуль наземної станції',
    "landing_support": 'Забезпечення висадки',
    "maintenance": 'Ремонтний підрозділ',
    "meteorological": 'Метеорологічний',
    "mine_countermeasure": 'Протимінний',
    "missile": 'Ракета',
    "mobile_advisor_and_support": 'Мобільна дорадча група та підтримка',
    "mobile_subscriber_equipment": 'Мобільне абонентське обладнання',
    "mobility_support": 'Забезпечення мобільності',
    "multinational": 'Багатонаціональний',
    "multinational_specialized_unit": 'Багатонаціональний спеціалізований підрозділ',
    "multiple_rocket_launcher": 'Реактивна система залпового вогню',
    "nato_medical_role_1": 'Медичне забезпечення НАТО, рівень 1',
    "nato_medical_role_2": 'Медичне забезпечення НАТО, рівень 2',
    "nato_medical_role_3": 'Медичне забезпечення НАТО, рівень 3',
    "nato_medical_role_4": 'Медичне забезпечення НАТО, рівень 4',
    "naval": 'Військово-морський',
    "node_center": 'Вузловий центр',
    "nuclear": 'Ядерний',
    "operations": 'Операції',
    "radar": 'Радіолокаційна станція',
    "radio_frequency_identification_interrogator_sensor": 'Запитувач / сенсор радіочастотної ідентифікації (RFID)',
    "radiological": 'Радіаційний',
    "search_and_rescue": 'Пошук і рятування',
    "security": 'Охорона',
    "sensor": 'Сенсор',
    "sensor_control_module": 'Модуль управління сенсорами (SCM)',
    "signals_intelligence": 'Радіоелектронна розвідка',
    "single_shelter_switch": 'Комутаційний вузол в одному контейнері',
    "single_rocket_launcher": 'Одноствольна реактивна пускова установка',
    "smoke": 'Дим',
    "sniper": 'Снайпери',
    "sound_ranging": 'Звукометрична розвідка',
    "special_operations_forces": 'Сили спеціальних операцій (SOF)',
    "special_weapons_and_tactics": 'Спеціальне озброєння та тактика',
    "survey": 'Геодезична розвідка',
    "tactical_exploitation": 'Тактичне використання розвідувальних даних',
    "target_acquisition": 'Виявлення та визначення координат цілей',
    "topographic_geospatial": 'Топографічний / геопросторовий',
    "utility": 'Допоміжний',
    "video_imagery": 'Відеозйомка (бойова камера)',
    "accident": 'Аварія',
    "other": 'Інше',
    "civilian": 'Цивільний',
    "antisubmarine_warfare": 'Протичовнова боротьба',
    "medevac": 'Медична евакуація',
    "ranger": 'Рейнджери',
    "support": 'Підтримка',
    "aviation": 'Авіація',
}

_UNIT_SECTOR2_LABELS = {
    "airborne": 'Повітрянодесантний',
    "arctic": 'Арктичний',
    "battle_damage_repair": 'Відновлення бойових пошкоджень',
    "bicycle_equipped": 'Оснащений велосипедами',
    "casualty_staging": 'Проміжний пункт розміщення поранених',
    "clearing": 'Розчищення',
    "close_range": 'Ближня дальність',
    "control": 'Управління',
    "decontamination": 'Спеціальна обробка',
    "demolition": 'Підривні роботи',
    "dental": 'Стоматологічний',
    "digital": 'Цифровий',
    "enhanced_position_location_reporting_system": 'Удосконалена система повідомлень про місцеположення (EPLRS)',
    "equipment": 'Техніка та обладнання',
    "heavy": 'Важкий',
    "high_altitude": 'Велика висота',
    "intermodal": 'Інтермодальний',
    "intensive_care": 'Інтенсивна терапія',
    "light": 'Легкий',
    "laboratory": 'Лабораторія',
    "launcher": 'Пускова установка',
    "long_range": 'Велика дальність',
    "low_altitude": 'Мала висота',
    "medium": 'Середній',
    "medium_altitude": 'Середня висота',
    "medium_range": 'Середня дальність',
    "mountain": 'Гірський',
    "high_to_medium_altitude": 'Від великих до середніх висот',
    "multi_channel": 'Багатоканальний',
    "optical": 'Оптичне виявлення спалахів',
    "pack_animal": 'В’ючна тварина',
    "patient_evacuation_coordination": 'Координація евакуації пацієнтів',
    "preventive_maintenance": 'Профілактичне технічне обслуговування',
    "psychological": 'Психологічний',
    "radio_relay_line_of_sight": 'Радіорелейний зв’язок прямої видимості',
    "railroad": 'Залізниця',
    "recovery_unmanned_systems": 'Повернення безпілотних систем',
    "recovery_maintenance": 'Евакуація пошкодженої техніки',
    "rescue_coordination_center": 'Координаційний центр рятування',
    "riverine": 'Річковий',
    "single_channel": 'Одноканальний',
    "ski": 'Лижний',
    "short_range": 'Мала дальність',
    "strategic": 'Стратегічний',
    "support": 'Підтримка',
    "tactical": 'Тактичний',
    "towed": 'Буксирований',
    "troop": 'Особовий склад',
    "vertical_or_short_take_off_and_landing": 'Вертикальний / короткий зліт і посадка (VTOL/VSTOL)',
    "veterinary": 'Ветеринарний',
    "wheeled": 'Колісний',
    "high_to_low_altitude": 'Від великих до малих висот',
    "medium_to_low_altitude": 'Від середніх до малих висот',
    "attack": 'Атака',
    "refuel": 'Заправлення пальним',
    "utility": 'Допоміжний',
    "combat_search_and_rescue": 'Бойовий пошук і рятування',
}


_CIVILIAN_SECTOR1_LABELS = {
    "assassination": 'Політичне вбивство',
    "execution_wrongful_killing": 'Позасудова страта',
    "murder_victims": 'Жертви умисного вбивства',
    "hijacking": 'Захоплення транспортного засобу',
    "kidnapping": 'Викрадення людини',
    "piracy": 'Піратство',
    "rape": 'Зґвалтування',
    "civilian": 'Цивільний',
    "displaced_persons_refugees_and_evacuees":
        'Переміщені особи, біженці та евакуйовані',
    "foreign_fighters": 'Іноземні бойовики',
    "gang_member_or_gang": 'Член банди або банда',
    "government_organization": 'Державна установа',
    "leader_or_leadership": 'Лідер або керівництво',
    "nongovernmental_organization":
        'Член неурядової організації або організація',
    "coerced_impressed_recruit": 'Примусово залучений новобранець',
    "willing_recruit": 'Доброволець',
    "religious_or_religious_organization":
        'Релігійна особа або організація',
    "targeted_individual_or_organization":
        'Цільова особа або організація',
    "terrorist_or_terrorist_organization":
        'Терорист або терористична організація',
    "speaker": 'Промовець',
    "accident": 'Аварія',
    "combat": 'Бойовий',
    "other": 'Інше',
    "loot": 'Мародерство',
}

_CIVILIAN_SECTOR2_LABELS = {
    "leader_or_leadership": 'Лідер або керівництво',
}

# Table A-XXVI: "sensor type category". The standard has no Land
# Equipment sector 2 at all, so no _EQUIPMENT_SECTOR2_LABELS exists.
_EQUIPMENT_SECTOR1_LABELS = {
    "biological": 'Біологічний',
    "chemical": 'Хімічний',
    "early_warning_radar": 'РЛС раннього попередження',
    "intrusion": 'Проникнення',
    "nuclear": 'Ядерний',
    "radiological": 'Радіаційний',
    "upgraded_early_warning_radar": 'Модернізована РЛС раннього попередження',
    "hijacking": 'Захоплення транспортного засобу',
    "civilian": 'Цивільний',
}

_INSTALLATION_SECTOR1_LABELS = {
    "biological": 'Біологічний',
    "chemical": 'Хімічний',
    "nuclear": 'Ядерний',
    "radiological": 'Радіаційний',
    "decontamination": 'Спеціальна обробка',
    "coal": 'Вугільна електроенергетика',
    "geothermal": 'Геотермальна електроенергетика',
    "hydroelectric": 'Гідроелектроенергетика',
    "natural_gas": 'Газова електроенергетика',
    "petroleum": 'Нафтова електроенергетика',
    "civilian": 'Цивільний',
    "civilian_telephone": 'Цивільна телефонна мережа',
    "civilian_television": 'Цивільне телебачення',
}

_INSTALLATION_SECTOR2_LABELS = {
    "biological": 'Біологічний (CBRN)',
    "chemical": 'Хімічний (CBRN)',
    "nuclear": 'Ядерний (CBRN)',
    "radiological": 'Радіаційний (CBRN)',
    "atomic_energy_reactor": 'Ядерний реактор (CBRN)',
    "nuclear_material_production": 'Виробництво ядерних матеріалів (CBRN)',
    "nuclear_material_storage": 'Зберігання ядерних матеріалів (CBRN)',
    "weapons_grade": 'Матеріал збройової якості (РХБ)',
}


def add_land_unit_layer(iface, edition=None):

    """Add "Land Unit" (D.6) - echelon and headquarters both apply (Table VII's "U" column)."""

    return add_single_domain_point_layer(
        iface,
        UNIT_LAYER_NAME,
        "ground_unit",
        _UNIT_ENTITY_LABELS,
        DEFAULT_UNIT_ENTITY,
        include_echelon=True,
        include_headquarters=True,
        sector1_labels=_UNIT_SECTOR1_LABELS,
        sector2_labels=_UNIT_SECTOR2_LABELS,
        edition=edition,
    )


def add_land_civilian_layer(iface, edition=None):

    """Add "Land Civilian" (D.7) - no echelon, headquarters applies."""

    return add_single_domain_point_layer(
        iface,
        CIVILIAN_LAYER_NAME,
        "land_civilian",
        _CIVILIAN_ENTITY_LABELS,
        DEFAULT_CIVILIAN_ENTITY,
        include_echelon=False,
        include_headquarters=True,
        sector1_labels=_CIVILIAN_SECTOR1_LABELS,
        sector2_labels=_CIVILIAN_SECTOR2_LABELS,
        edition=edition,
    )


def add_land_equipment_layer(iface, edition=None):

    """Add "Land Equipment" (D.8) - no echelon, headquarters applies."""

    return add_single_domain_point_layer(
        iface,
        EQUIPMENT_LAYER_NAME,
        "land_equipment",
        _EQUIPMENT_ENTITY_LABELS,
        DEFAULT_EQUIPMENT_ENTITY,
        include_echelon=False,
        include_headquarters=True,
        sector1_labels=_EQUIPMENT_SECTOR1_LABELS,
        edition=edition,
    )


def add_land_installation_layer(iface, edition=None):

    """Add "Land Installation" (D.9) - no echelon, headquarters applies."""

    return add_single_domain_point_layer(
        iface,
        INSTALLATION_LAYER_NAME,
        "land_installation",
        _INSTALLATION_ENTITY_LABELS,
        DEFAULT_INSTALLATION_ENTITY,
        include_echelon=False,
        include_headquarters=True,
        sector1_labels=_INSTALLATION_SECTOR1_LABELS,
        sector2_labels=_INSTALLATION_SECTOR2_LABELS,
        edition=edition,
    )


def add_land_layers(iface, edition=None):

    """
    Add all four Land layers (Unit/Civilian/Equipment/Installation) in
    one call - the toolbar action's own callback. Each has its own
    already-exists guard (add_single_domain_point_layer()), so calling
    this again only adds whichever of the four are still missing.
    Returns a dict of {layer_name: layer_or_None}, keyed by the BASE
    name - the layers themselves carry the edition suffix.
    """

    return {
        UNIT_LAYER_NAME: add_land_unit_layer(iface, edition),
        CIVILIAN_LAYER_NAME: add_land_civilian_layer(iface, edition),
        EQUIPMENT_LAYER_NAME: add_land_equipment_layer(iface, edition),
        INSTALLATION_LAYER_NAME: add_land_installation_layer(iface, edition),
    }
