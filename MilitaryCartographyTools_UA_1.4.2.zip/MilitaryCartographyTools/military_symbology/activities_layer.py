# -*- coding: utf-8 -*-

"""
Builds the "Activities" point layer - MIL-STD-2525D
Appendix G (Activities Symbols), symbol set "40" (Table A-III). A single
layer - Table A-III has no companion symbol set for Activities the way
Space/Air have a Missile counterpart.

No echelon or headquarters fields - Appendix G's own amplifier table
(Table G-II) lists neither Field B (Echelon) nor Field S (Headquarters
Staff Indicator) - Table G-II's own "S" field is actually "Offset
Location Indicator", an unrelated graphic amplifier this plugin doesn't
model, not Field S from Table VII's master list.

Entity vocabulary is sidc.py's ENTITIES["activities"] - the FULL
153-entity vocabulary from milsymbol-3.0.4's own activites.js, cross-
checked against the standard's own Table G-III (printed pages 357-363).
Includes the hierarchy-only parent codes (110000/130000/150000/180000/
etc.) that render frame-only, per that table's own remarks column - see
sidc.py's own comment on ENTITIES["activities"] for detail.

Sector 1 modifiers ARE built here (sidc.py's MODIFIERS["activities"]
["sector1"], 18 codes - the FULL vocabulary Table G-IV actually defines).
There is deliberately NO sector 2 field: Appendix G's own text says so
explicitly ("Note: There are no sector 2 modifiers in activities
symbols.", G.5.3.1 step 3) and Table G-IV itself only ever lists a
sector 1 column - see sidc.py's own comment on MODIFIERS["activities"]
for why the four extra sIdm1 codes and two sIdm2 codes present in
milsymbol's own source were excluded as unsanctioned by the standard.

Military Cartography Tools
"""

from ._point_symbol_layer import add_single_domain_point_layer


OUTPUT_LAYER_NAME = 'Діяльність'

DEFAULT_ENTITY = "criminal_activity_incident_type"

_ENTITY_LABELS = {
    "criminal_activity_incident": 'Злочинна діяльність / подія (загальне позначення)',
    "criminal_activity_incident_type": 'Злочинна подія',
    "arrest": 'Арешт',
    "arson_fire": 'Підпал / пожежа',
    "attempted_criminal_activity": 'Замах на злочин',
    "drive_by_shooting": 'Стрілянина з автомобіля',
    "drug_related_activities": 'Діяльність, пов’язана з наркотиками',
    "extortion": 'Вимагання',
    "graffiti": 'Графіті',
    "killing_victim": 'Жертва вбивства',
    "poisoning": 'Отруєння',
    "riot": 'Масові заворушення',
    "booby_trap": 'Міна-пастка',
    "eviction": 'Виселення',
    "black_marketing": 'Чорний ринок',
    "vandalism_loot_ransack_plunder_sack": 'Вандалізм / мародерство / пограбування',
    "jail_break": 'Втеча з в’язниці',
    "robbery": 'Розбій',
    "theft": 'Крадіжка',
    "burglary": 'Крадіжка зі зломом',
    "smuggling": 'Контрабанда',
    "rock_throwing": 'Кидання каміння',
    "dead_body": 'Тіло загиблого',
    "sabotage": 'Диверсія',
    "threat_of_criminal_activity": 'Загроза злочинної діяльності',
    "bomb": 'Бомба',
    "bomb_threat": 'Загроза вибуху',
    "ied": 'Саморобний вибуховий пристрій (СВП)',
    "ied_explosion": 'Вибух СВП',
    "premature_ied_explosion": 'Передчасний вибух СВП',
    "ied_supply_cache": 'Схованка компонентів СВП',
    "individual_with_ied": 'Особа зі СВП',
    "shooting": 'Стрілянина',
    "sniping": 'Снайперський вогонь',
    "illegal_drug_operation": 'Незаконні операції з наркотиками',
    "drug_trafficking": 'Наркоторгівля',
    "drug_laboratory": 'Нарколабораторія',
    "explosion": 'Вибух',
    "grenade_explosion": 'Вибух гранати',
    "incendiary_explosion": 'Вибух запалювального боєприпасу',
    "mine_explosion": 'Вибух міни',
    "mortar_fire_explosion": 'Розрив мінометної міни',
    "rocket_explosion": 'Вибух ракети',
    "bomb_explosion": 'Вибух бомби',
    "home": 'Житловий будинок',
    "civil_disturbance": 'Громадські заворушення',
    "demonstration": 'Демонстрація',
    "operations": 'Операції (загальне позначення)',
    "patrolling": 'Патрулювання',
    "psychological_operations": 'Психологічні операції',
    "radio_and_television_psychological_operations": 'Психологічні операції через радіо й телебачення',
    "searching": 'Пошук',
    "willing_coerced_qualifier": 'Добровільність / примус (загальне позначення)',
    "willing": 'Добровільно',
    "coerced_impressed": 'Примусово залучений',
    "mine_laying": 'Встановлення мін',
    "spy": 'Шпигун',
    "warrant_served": 'Виконання судового ордера',
    "exfiltration": 'Виведення з району дій',
    "infiltration": 'Просочування',
    "meeting": 'Зустріч',
    "polling_place_election": 'Виборча дільниця / вибори',
    "raid": 'Рейд',
    "emergency_operation": 'Аварійно-рятувальна операція',
    "emergency_collection_evacuation_point": 'Пункт екстреного збору / евакуації',
    "food_distribution": 'Роздача продовольства',
    "emergency_incident_command_center": 'Центр управління реагуванням на надзвичайну подію',
    "emergency_operations_center": 'Центр управління надзвичайними ситуаціями',
    "emergency_public_information_center": 'Центр інформування населення про надзвичайну ситуацію',
    "emergency_shelter": 'Тимчасове укриття',
    "emergency_staging_area": 'Район зосередження рятувальних сил',
    "water_distribution_center": 'Центр роздачі води',
    "emergency_medical_operation": 'Невідкладна медична допомога',
    "emt_station_location": 'Пункт екстреної медичної допомоги',
    "health_department_facility": 'Установа охорони здоров’я',
    "medical_facilities_outpatient": 'Амбулаторний медичний заклад',
    "emergency_medical_operation_facility": 'Заклад невідкладної медичної допомоги',
    "pharmacy": 'Аптека',
    "triage": 'Медичне сортування',
    "fire_protection": 'Протипожежний захист',
    "fire_hydrant": 'Пожежний гідрант',
    "fire_station": 'Пожежна частина',
    "other_water_supply_location": 'Інше джерело водопостачання',
    # Table A-XXXVIII prints 131500 as "Law Enforcement Operation";
    # the shorter form was ours. Corrected 2026-08-18 after 2525E
    # showed the standard's own wording side by side with it.
    "law_enforcement": 'Правоохоронна операція',
    "bureau_of_alcohol_tobacco_firearms_and_explosives": 'Бюро алкоголю, тютюну, вогнепальної зброї та вибухових речовин США (ATF)',
    "border_patrol": 'Прикордонний патруль',
    "customs_service": 'Митна служба',
    "drug_enforcement_administration": 'Управління боротьби з наркотиками США (DEA)',
    "department_of_justice": 'Міністерство юстиції США (DOJ)',
    "federal_bureau_of_investigation": 'Федеральне бюро розслідувань США (FBI)',
    "police": 'Поліція',
    "prison": 'В’язниця',
    # "secret" here is the US Secret Service, a MIL-STD-2525D entity
    # name - not a credential. Suppressions are for the scanners' own
    # keyword heuristics (1.0.0's automated review, 2026-08-17).
    "united_states_secret_service": 'Секретна служба США (USSS)',  # nosec B105 # pragma: allowlist secret
    "transportation_security_administration": 'Управління транспортної безпеки США (TSA)',
    # Table A-XXXVIII prints 131511 as Coast Guard; there is no "Law
    # Enforcement Vessel" row in this table. Key left alone (saved
    # features carry it); the label is what a user reads.
    "law_enforcement_vessel": 'Берегова охорона',
    "us_marshals_service": 'Служба маршалів США',
    "internal_security_force": 'Сили внутрішньої безпеки',
    "fire_event": 'Пожежа',
    "fire_origin": 'Місце виникнення пожежі',
    "smoke": 'Дим',
    "hot_spot": 'Осередок займання',
    "non_residential_fire": 'Пожежа в нежитловій будівлі',
    "residential_fire": 'Пожежа в житловій будівлі',
    "school_fire": 'Пожежа у школі',
    "special_needs_fire": 'Пожежа в закладі для осіб з особливими потребами',
    "wild_fire": 'Природна пожежа',
    "hazardous_materials": 'Небезпечні речовини (загальне позначення)',
    "hazardous_materials_incident": 'Подія з небезпечними речовинами',
    "chemical_agent": 'Хімічна речовина',
    "corrosive_material": 'Корозійна речовина',
    "hazardous_when_wet": 'Небезпека при намоканні',
    "explosive_material": 'Вибухова речовина',
    "flammable_gas": 'Займистий газ',
    "flammable_liquid": 'Займиста рідина',
    "flammable_solid": 'Займиста тверда речовина',
    "non_flammable_gas": 'Незаймистий газ',
    "organic_peroxide": 'Органічний пероксид',
    "oxidizer": 'Окисник',
    "radioactive_material": 'Радіоактивний матеріал',
    "spontaneously_combustible_material": 'Самозаймиста речовина',
    "toxic_gas": 'Токсичний газ',
    "toxic_infectious_material": 'Токсичний інфекційний матеріал',
    "unexploded_ordnance": 'Боєприпас, що не вибухнув',
    "transportation": 'Транспортне забезпечення',
    "hijacking_airplane": 'Захоплення літака',
    "hijacking_boat": 'Захоплення судна',
    "train_locomotive": 'Залізничний локомотив',
    "known_insurgent_vehicle": 'Підтверджений транспортний засіб повстанців',
    "vehicle_explosion": 'Вибух транспортного засобу',
    "natural_event": 'Природне явище',
    "geologic": 'Геологічне явище',
    "aftershock": 'Повторний підземний поштовх',
    "avalanche": 'Лавина',
    "earthquake_epicenter": 'Епіцентр землетрусу',
    "landslide": 'Зсув',
    "subsidence": 'Просідання ґрунту',
    "volcanic_eruption": 'Виверження вулкана',
    "volcanic_threat": 'Вулканічна загроза',
    "cave_entrance": 'Вхід до печери',
    "hydro_meteorological": 'Гідрометеорологічне явище',
    "drought": 'Посуха',
    "flood": 'Повінь',
    "tsunami": 'Цунамі',
    "infestation": 'Масове поширення шкідників',
    "bird": 'Птахи',
    "insect": 'Комахи',
    "microbial": 'Мікробне зараження',
    "reptile": 'Плазуни',
    "rodent": 'Гризуни',
    "personalities": 'Особи (загальне позначення)',
    "religious_leader": 'Релігійний лідер',
    "spokesperson": 'Речник',
    "isolated_personnel": 'Ізольований особовий склад',
}

_SECTOR1_LABELS = {
    "assassination": 'Політичне вбивство',
    "execution": 'Позасудова страта',
    "hijacking_hijacked": 'Захоплення / захоплений транспорт',
    "house_to_house": 'Обхід будинків',
    "kidnapping": 'Викрадення людини',
    "murder": 'Убивство',
    "piracy": 'Піратство',
    "rape": 'Зґвалтування',
    "written_military_information_support_operations": 'Письмові матеріали інформаційної підтримки військових операцій',
    "pirate": 'Пірат',
    "false": 'Хибний',
    "find": 'Знахідка',
    "found_and_cleared": 'Виявлено та знешкоджено',
    "hoax_decoy": 'Хибне повідомлення / макет',
    "attempted": 'Замах',
    "accident": 'Аварія',
    "incident": 'Інцидент',
    "theft_modifier": 'Крадіжка',
}


def add_activities_layer(iface, edition=None):

    """
    Add the "Activities" layer - warns and does
    nothing if one already exists, same data-safety guard as every other
    hand-digitized layer in this plugin.
    """

    return add_single_domain_point_layer(
        iface,
        OUTPUT_LAYER_NAME,
        "activities",
        _ENTITY_LABELS,
        DEFAULT_ENTITY,
        include_echelon=False,
        include_headquarters=False,
        sector1_labels=_SECTOR1_LABELS,
        edition=edition,
    )
