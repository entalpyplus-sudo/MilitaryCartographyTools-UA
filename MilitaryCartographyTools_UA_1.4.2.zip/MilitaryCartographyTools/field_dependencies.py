"""Conditional editability in the standard QGIS attribute form.

Only form metadata is changed. QGIS reevaluates current_value() on every
edit, preserves inactive values and combines these rules with layer editing.
The expressions also work after saving a style/project, without a preview UI.
"""
import json,re
from qgis.core import QgsEditFormConfig,QgsExpression,QgsProperty,QgsExpressionContext,QgsExpressionContextUtils

PROPERTY='MilitaryCartographyTools/field_dependencies'
LOWER_ECHELONS=('team_crew','squad','section','platoon','company','battalion','regiment','brigade','division')
EFFECTS=('destroyed','damaged','planned_destroyed')

def value(name):
    return 'current_value('+QgsExpression.quotedString(name)+')'

def selected(name):
    return "coalesce(trim(to_string("+value(name)+")), '') <> ''"

def one_of(name,options):
    return value(name)+' IN ('+','.join(QgsExpression.quotedString(v) for v in options)+')'

def rules_for(layer):
    fields=set(layer.fields().names()); rules={}
    def add(name,condition,reason):
        if name in fields: rules.setdefault(name,[]).append((condition,reason))
    if layer.customProperty('MilitaryCartographyTools/free_zones',False):
        for field in ['outline_color','outline_width_mm']:
            add(field,'coalesce('+value('outline_enabled')+',true)','Увімкніть «Показувати контур».')
        add('label','coalesce('+value('show_label')+',true)','Увімкніть «Показувати підпис».')
        add('fill_color','coalesce('+value('fill_transparency')+',65) < 100','Зменште прозорість заливки нижче 100 %.')
    # Discover native QGIS cascades, including domain/entity and group/entity.
    for index,field in enumerate(layer.fields()):
        setup=layer.editorWidgetSetup(index)
        if setup.type()!='ValueRelation': continue
        for parent in set(re.findall(r"current_value\s*\(\s*['\"]([^'\"]+)['\"]\s*\)",setup.config().get('FilterExpression',''),re.I)):
            if parent in fields and parent!=field.name():
                alias=layer.attributeAlias(layer.fields().indexFromName(parent)) or parent
                add(field.name(),selected(parent),'Спочатку виберіть значення «'+alias+'».')
    for prefix,hq in [('ua_','headquarters'),('','hq')]:
        if hq in fields:
            add(prefix+'command_label','coalesce('+value(hq)+',false)','Увімкніть «Пункт управління / штаб».')
        effect=prefix+'effect'; mono=prefix+'monochrome'
        if effect in fields:
            add(prefix+'effect_side',one_of(effect,EFFECTS),'Спочатку виберіть стан ураження з перекресленням.')
            if mono in fields:
                add(prefix+'effect_side','NOT coalesce('+value(mono)+',false)','Колір ураження доступний у кольоровому вигляді.')
    if 'ua_png_key' in fields:
        is_png=selected('ua_png_key')
        add('ua_png_size_mm',is_png,'Спочатку виберіть власний PNG.')
        vector_fields={'affiliation','entity','echelon','status','headquarters','sector1_modifier','sector2_modifier','scale'}
        vector_fields.update(f for f in fields if f.startswith('ua_') and f not in ('ua_png_key','ua_png_size_mm'))
        if not layer.labelsEnabled(): vector_fields.add('unique_designation')
        for field in vector_fields:
            add(field,'NOT ('+is_png+')','Застосовується до векторного знака. Для PNG доступні його розмір і поворот.')
    if 'entity' in fields:
        for field in ['echelon','headquarters','sector1_modifier','sector2_modifier','modifier1','modifier2','hq']:
            add(field,selected('entity'),'Спочатку виберіть тип знака.')
    # Paragraph 5.4.8: reinforcement/reduction is for division and below.
    for name in ['ua_reinforcement','reinforcement']:
        if name not in fields: continue
        if 'echelon' in fields:
            add(name,one_of('echelon',LOWER_ECHELONS),'Виберіть рівень підрозділу від групи до дивізії (п. 5.4.8).')
        else: add(name,'false','Посилення / послаблення застосовується до підрозділів із визначеним ешелоном.')
        if 'domain' in fields:
            add(name,value('domain')+" = 'ground_unit'",'Застосовується до сухопутних підрозділів.')
    if 'hq' in fields and 'domain' in fields:
        add('hq',value('domain')+" = 'ground_unit'",'Застосовується до сухопутних підрозділів.')
        add('echelon',value('domain')+" = 'ground_unit'",'Застосовується до сухопутних підрозділів.')
        add('command_label',value('domain')+" = 'ground_unit'",'Застосовується до сухопутних підрозділів.')
    if 'far_designation' in fields:
        for field in ['far_designation','echelon']:
            add(field,one_of('measure_type',['boundary']),'Застосовується до розмежувальної лінії.')
    if 'prepared' in fields:
        add('prepared',one_of('measure_type',['battle_position']),'Застосовується до бойової позиції.')
        add('echelon',one_of('measure_type',['battle_position','strong_point']),'Застосовується до бойової позиції або опорного пункту.')
    if 'supply_class' in fields:
        from .military_symbology.supply_points import SUPPLY_CLASS_FIELD
        add('supply_class',one_of('entity',SUPPLY_CLASS_FIELD['entities']),'Застосовується до багатокласового пункту постачання НАТО.')
    if 'equipment_type' in fields and 'measure_type' in fields:
        from .military_symbology.supply_points import CONVOY_MEASURE_TYPE_LABELS
        for field in ['equipment_type','additional_information','dtg_start','dtg_end']:
            add(field,one_of('measure_type',CONVOY_MEASURE_TYPE_LABELS),'Спочатку виберіть тип колони.')
    if 'mine_indicator' in fields and 'dtg_start' in fields:
        from .military_symbology.obstacle_control_measures import _AREA_DTG_TYPES,_DYNAMIC_MINEFIELD_TYPES
        add('mine_type',one_of('measure_type',('mined_area',)+_DYNAMIC_MINEFIELD_TYPES),'Спочатку виберіть замінований район або мінне поле довільного контуру.')
        for field in ['mine_indicator','self_destruct_dtg']:
            add(field,one_of('measure_type',['mined_area']),'Застосовується до замінованого району.')
        for field in ['dtg_start','dtg_end']:
            add(field,one_of('measure_type',_AREA_DTG_TYPES),'Застосовується до вільної від загороджень зони або зони обмеження загороджень.')
    for field in fields:
        match=re.fullmatch(r'(ring[1-5])_(left|right|alt)',field)
        if match and match[1]+'_range' in fields:
            add(field,'coalesce('+value(match[1]+'_range')+',0) > 0','Спочатку задайте додатну дальність цього сектора.')
    # A dependent control also requires all conditions of its parents.
    # Example: a retained HQ=True does not enable its caption when the
    # vector symbol is inactive or its entity has been cleared.
    def expand(field,seen):
        if field in seen: return []
        result=[]
        for expression,reason in rules.get(field,[]):
            for parent in re.findall(r"current_value\('([^']+)'\)",expression):
                result.extend(expand(parent,seen|{field}))
            result.append((expression,reason))
        return list(dict.fromkeys(result))
    return {field:expand(field,set()) for field in rules}

def configure(layer):
    """Persist idempotent native form rules and retain existing user conditions."""
    rules=rules_for(layer)
    if not rules: return
    config=layer.editFormConfig(); changed=False
    try: saved=json.loads(layer.customProperty(PROPERTY,'{}'))
    except (ValueError,TypeError): saved={}
    for field,conditions in rules.items():
        index=layer.fields().indexFromName(field)
        if config.readOnly(index): continue
        props=config.dataDefinedFieldProperties(field)
        current=props.property(QgsEditFormConfig.DataDefinedProperty.Editable)
        old=saved.get(field,{})
        current_expression=current.asExpression() if current.isActive() else ''
        original=old.get('original','') if current_expression==old.get('applied') else current_expression
        condition=' AND '.join('coalesce(('+expression+'),false)' for expression,_ in conditions)
        expression=('('+original+') AND ('+condition+')') if original else condition
        if current_expression!=expression:
            props.setProperty(QgsEditFormConfig.DataDefinedProperty.Editable,QgsProperty.fromExpression(expression)); changed=True
        # A native field comment explains inactive controls, without extra panels.
        comment_key=getattr(QgsEditFormConfig.DataDefinedProperty,'CustomComment',None)
        if comment_key is not None:
            comment=props.property(comment_key)
            text='CASE '+' '.join('WHEN NOT coalesce(('+test+'),false) THEN '+QgsExpression.quotedString(reason) for test,reason in conditions)+" ELSE '' END"
            if not comment.isActive() or comment.asExpression()==old.get('comment'):
                if comment.asExpression()!=text:
                    props.setProperty(comment_key,QgsProperty.fromExpression(text)); changed=True
                comment_expression=text
            else: comment_expression=old.get('comment','')
        else: comment_expression=''
        config.setDataDefinedFieldProperties(field,props)
        saved[field]={'original':original,'applied':expression,'comment':comment_expression}
    if changed: layer.setEditFormConfig(config)
    encoded=json.dumps(saved,ensure_ascii=False,sort_keys=True)
    if layer.customProperty(PROPERTY,'')!=encoded: layer.setCustomProperty(PROPERTY,encoded)

def refresh_form(form,feature,wrappers):
    """Use uncommitted completer values without emitting recursive editor signals.

    QGIS's cached form feature can lag a ValueRelation editor. Evaluate the
    same saved editability properties against the live editor snapshot.
    setEnabled() on an editor wrapper changes UI state, never its value.
    """
    if getattr(form.mode(),'name','') not in ('SingleEditMode','AddFeatureMode'): return
    layer=form.layer(); config=layer.editFormConfig()
    cached=form.currentFormFeature(); lagged=set()
    def null_or_empty(v): return v is None or str(v) in ('','NULL')
    for wrapper in wrappers:
        index=wrapper.fieldIdx()
        if layer.editorWidgetSetup(index).type()!='ValueRelation': continue
        a,b=cached[index],feature[index]
        if a!=b and not (null_or_empty(a) and null_or_empty(b)): lagged.add(wrapper.field().name())
    previous=set(form.property('mct_dependency_overrides') or [])
    if not lagged and not previous: return
    context=QgsExpressionContext(); context.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(layer))
    context.setFeature(feature)
    editor_context=wrappers[0].context() if wrappers else None
    if editor_context is not None and editor_context.parentFormFeature().isValid():
        parent=editor_context.parentContext()
        context.appendScope(QgsExpressionContextUtils.parentFormScope(editor_context.parentFormFeature(),parent.attributeFormModeString() if parent else ''))
    context.appendScope(QgsExpressionContextUtils.formScope(feature,editor_context.attributeFormModeString() if editor_context else form.mode().name.removesuffix('Mode')))
    try: fields=json.loads(layer.customProperty(PROPERTY,'{}'))
    except (ValueError,TypeError): return
    overridden=[]
    for wrapper in wrappers:
        name=wrapper.field().name()
        if name not in fields: continue
        prop=config.dataDefinedFieldProperties(name).property(QgsEditFormConfig.DataDefinedProperty.Editable)
        if not prop.isActive(): continue
        affected=any(value(field) in prop.asExpression() for field in lagged)
        if not affected and name not in previous: continue
        allowed,ok=prop.valueAsBool(context,False)
        editable=form.editable() and not config.readOnly(wrapper.fieldIdx()) and ok and allowed
        wrapper.setEnabled(editable)
        if affected: overridden.append(name)
        comment_key=getattr(QgsEditFormConfig.DataDefinedProperty,'CustomComment',None)
        if comment_key is not None:
            comment=config.dataDefinedFieldProperties(name).property(comment_key)
            if comment.isActive(): wrapper.widget().setToolTip(comment.valueAsString(context,'')[0])
    form.setProperty('mct_dependency_overrides',overridden)
