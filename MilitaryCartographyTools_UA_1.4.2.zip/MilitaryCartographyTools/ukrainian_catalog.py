"""Native layer builders shared with the classic Military Cartography Tools catalogue."""
from .military_symbology import _point_symbol_layer as point
from .military_symbology import space_layer as m0
from .military_symbology import air_layer as m1
from .military_symbology import land_layer as m2
from .military_symbology import sea_surface_layer as m3
from .military_symbology import subsurface_layer as m4
from .military_symbology import activities_layer as m5
from .military_symbology import sigint_layer as m6
from .military_symbology import cyberspace_layer as m7
from .military_symbology import c2_measures as m8
from .military_symbology import maneuver_control_measures as m9
from .military_symbology import defensive_control_measures as m10
from .military_symbology import offensive_control_measures as m11
from .military_symbology import maneuver_control_measures_2 as m12
from .military_symbology import airspace_control_measures as m13
from .military_symbology import maritime_control_measures as m14
from .military_symbology import deception_control_measures as m15
from .military_symbology import fire_support_coordination_measures as m16
from .military_symbology import target_control_measures as m17
from .military_symbology import cbrn_defense as m18
from .military_symbology import field_fortification as m19
from .military_symbology import obstacle_control_measures as m20
from .military_symbology import target_acquisition_control_measures as m21
from .military_symbology import sustainment_control_measures as m22
from .military_symbology import supply_points as m23
from .military_symbology import mission_task_control_measures as m24
from .military_symbology import intelligence_control_measures as m25

BUILDERS = {
    'space_layer/space_layer': (lambda edition='2525D': point.build_single_domain_point_layer(m0.OUTPUT_LAYER_NAME, 'space', m0._ENTITY_LABELS, m0.DEFAULT_ENTITY, entity_symbol_set_overrides=m0._ENTITY_SYMBOL_SET_OVERRIDES, include_echelon=False, include_headquarters=False, sector1_labels=m0._SECTOR1_LABELS, sector2_labels=m0._SECTOR2_LABELS, edition=edition), 'space'),
    'air_layer/air_layer': (lambda edition='2525D': point.build_single_domain_point_layer(m1.OUTPUT_LAYER_NAME, 'air', m1._ENTITY_LABELS, m1.DEFAULT_ENTITY, entity_symbol_set_overrides=m1._ENTITY_SYMBOL_SET_OVERRIDES, include_echelon=False, include_headquarters=False, sector1_labels=m1._SECTOR1_LABELS, sector2_labels=m1._SECTOR2_LABELS, edition=edition), 'air'),
    'land_layer/land_unit_layer': (lambda edition='2525D': point.build_single_domain_point_layer(m2.UNIT_LAYER_NAME, 'ground_unit', m2._UNIT_ENTITY_LABELS, m2.DEFAULT_UNIT_ENTITY, include_echelon=True, include_headquarters=True, sector1_labels=m2._UNIT_SECTOR1_LABELS, sector2_labels=m2._UNIT_SECTOR2_LABELS, edition=edition), 'ground_unit'),
    'land_layer/land_civilian_layer': (lambda edition='2525D': point.build_single_domain_point_layer(m2.CIVILIAN_LAYER_NAME, 'land_civilian', m2._CIVILIAN_ENTITY_LABELS, m2.DEFAULT_CIVILIAN_ENTITY, include_echelon=False, include_headquarters=True, sector1_labels=m2._CIVILIAN_SECTOR1_LABELS, sector2_labels=m2._CIVILIAN_SECTOR2_LABELS, edition=edition), 'land_civilian'),
    'land_layer/land_equipment_layer': (lambda edition='2525D': point.build_single_domain_point_layer(m2.EQUIPMENT_LAYER_NAME, 'land_equipment', m2._EQUIPMENT_ENTITY_LABELS, m2.DEFAULT_EQUIPMENT_ENTITY, include_echelon=False, include_headquarters=True, sector1_labels=m2._EQUIPMENT_SECTOR1_LABELS, edition=edition), 'land_equipment'),
    'land_layer/land_installation_layer': (lambda edition='2525D': point.build_single_domain_point_layer(m2.INSTALLATION_LAYER_NAME, 'land_installation', m2._INSTALLATION_ENTITY_LABELS, m2.DEFAULT_INSTALLATION_ENTITY, include_echelon=False, include_headquarters=True, sector1_labels=m2._INSTALLATION_SECTOR1_LABELS, sector2_labels=m2._INSTALLATION_SECTOR2_LABELS, edition=edition), 'land_installation'),
    'sea_surface_layer/sea_surface_layer': (lambda edition='2525D': point.build_single_domain_point_layer(m3.OUTPUT_LAYER_NAME, 'sea_surface', m3._ENTITY_LABELS, m3.DEFAULT_ENTITY, include_echelon=False, include_headquarters=False, sector1_labels=m3._SECTOR1_LABELS, sector2_labels=m3._SECTOR2_LABELS, edition=edition), 'sea_surface'),
    'subsurface_layer/subsurface_layer': (lambda edition='2525D': point.build_single_domain_point_layer(m4.SUBSURFACE_LAYER_NAME, 'subsurface', m4._SUBSURFACE_ENTITY_LABELS, m4.DEFAULT_SUBSURFACE_ENTITY, include_echelon=False, include_headquarters=False, sector1_labels=m4._SUBSURFACE_SECTOR1_LABELS, sector2_labels=m4._SUBSURFACE_SECTOR2_LABELS, edition=edition), 'subsurface'),
    'subsurface_layer/mine_warfare_layer': (lambda edition='2525D': point.build_single_domain_point_layer(m4.MINE_WARFARE_LAYER_NAME, 'mine_warfare', m4._MINE_WARFARE_ENTITY_LABELS, m4.DEFAULT_MINE_WARFARE_ENTITY, include_echelon=False, include_headquarters=False, edition=edition), 'mine_warfare'),
    'activities_layer/activities_layer': (lambda edition='2525D': point.build_single_domain_point_layer(m5.OUTPUT_LAYER_NAME, 'activities', m5._ENTITY_LABELS, m5.DEFAULT_ENTITY, include_echelon=False, include_headquarters=False, sector1_labels=m5._SECTOR1_LABELS, edition=edition), 'activities'),
    'sigint_layer/sigint_layer': (lambda edition='2525D': point.build_single_domain_point_layer(m6.OUTPUT_LAYER_NAME, 'sigint_air', m6._ENTITY_LABELS, m6.DEFAULT_ENTITY, include_echelon=False, include_headquarters=False, sector1_labels=m6._SECTOR1_LABELS, dimension_labels=m6._DIMENSION_LABELS, dimension_symbol_sets=m6._DIMENSION_SYMBOL_SETS, default_dimension=m6.DEFAULT_DIMENSION, edition=edition), 'sigint_air'),
    'cyberspace_layer/cyberspace_layer': (lambda edition='2525D': point.build_single_domain_point_layer(m7.OUTPUT_LAYER_NAME, 'cyberspace', m7._ENTITY_LABELS, m7.DEFAULT_ENTITY, include_echelon=False, include_headquarters=False, edition=edition), 'cyberspace'),
    'c2_measures/c2_measures_lines_layer': (lambda : m8.create_c2_measures_lines_layer(), None),
    'c2_measures/c2_measures_areas_layer': (lambda : m8.create_c2_measures_areas_layer(), None),
    'c2_measures/c2_measures_points_layer': (lambda : m8.create_c2_measures_points_layer(), None),
    'maneuver_control_measures/maneuver_control_measures_lines_layer': (lambda : m9.create_maneuver_control_measures_lines_layer(), None),
    'maneuver_control_measures/maneuver_control_measures_areas_layer': (lambda : m9.create_maneuver_control_measures_areas_layer(), None),
    'defensive_control_measures/defensive_control_measures_areas_layer': (lambda : m10.create_defensive_control_measures_areas_layer(), None),
    'defensive_control_measures/defensive_control_measures_lines_layer': (lambda : m10.create_defensive_control_measures_lines_layer(), None),
    'defensive_control_measures/defensive_control_measures_points_layer': (lambda : m10.create_defensive_control_measures_points_layer(), None),
    'offensive_control_measures/offensive_control_measures_lines_layer': (lambda : m11.create_offensive_control_measures_lines_layer(), None),
    'offensive_control_measures/offensive_control_measures_areas_layer': (lambda : m11.create_offensive_control_measures_areas_layer(), None),
    'offensive_control_measures/offensive_control_measures_points_layer': (lambda : m11.create_offensive_control_measures_points_layer(), None),
    'maneuver_control_measures_2/maneuver_control_measures_2_lines_layer': (lambda : m12.create_maneuver_control_measures_2_lines_layer(), None),
    'maneuver_control_measures_2/maneuver_control_measures_2_areas_layer': (lambda : m12.create_maneuver_control_measures_2_areas_layer(), None),
    'airspace_control_measures/airspace_control_measures_lines_layer': (lambda : m13.create_airspace_control_measures_lines_layer(), None),
    'airspace_control_measures/airspace_control_measures_areas_layer': (lambda : m13.create_airspace_control_measures_areas_layer(), None),
    'airspace_control_measures/airspace_control_measures_points_layer': (lambda : m13.create_airspace_control_measures_points_layer(), None),
    'maritime_control_measures/maritime_control_measures_lines_layer': (lambda : m14.create_maritime_control_measures_lines_layer(), None),
    'maritime_control_measures/maritime_control_measures_points_layer': (lambda : m14.create_maritime_control_measures_points_layer(), None),
    'deception_control_measures/deception_control_measures_lines_layer': (lambda : m15.create_deception_control_measures_lines_layer(), None),
    'fire_support_coordination_measures/fire_support_coordination_measures_lines_layer': (lambda : m16.create_fire_support_coordination_measures_lines_layer(), None),
    'fire_support_coordination_measures/fire_support_coordination_measures_areas_layer': (lambda : m16.create_fire_support_coordination_measures_areas_layer(), None),
    'target_control_measures/target_control_measures_lines_layer': (lambda : m17.create_target_control_measures_lines_layer(), None),
    'target_control_measures/target_control_measures_areas_layer': (lambda : m17.create_target_control_measures_areas_layer(), None),
    'target_control_measures/target_control_measures_points_layer': (lambda : m17.create_target_control_measures_points_layer(), None),
    'cbrn_defense/cbrn_defense_points_layer': (lambda : m18.create_cbrn_defense_points_layer(), None),
    'cbrn_defense/cbrn_contaminated_areas_layer': (lambda : m18.create_cbrn_contaminated_areas_layer(), None),
    'cbrn_defense/safe_distance_zones_layer': (lambda : m18.create_safe_distance_zones_layer(), None),
    'cbrn_defense/dose_rate_contours_layer': (lambda : m18.create_dose_rate_contours_layer(), None),
    'field_fortification/field_fortification_points_layer': (lambda : m19.create_field_fortification_points_layer(), None),
    'field_fortification/field_fortification_lines_layer': (lambda : m19.create_field_fortification_lines_layer(), None),
    'obstacle_control_measures/obstacle_control_measures_points_layer': (lambda : m20.create_obstacle_control_measures_points_layer(), None),
    'obstacle_control_measures/obstacle_control_measures_areas_layer': (lambda : m20.create_obstacle_control_measures_areas_layer(), None),
    'obstacle_control_measures/obstacle_control_measures_minefields_layer': (lambda : m20.create_obstacle_control_measures_minefields_layer(), None),
    'obstacle_control_measures/obstacle_control_measures_lines_layer': (lambda : m20.create_obstacle_control_measures_lines_layer(), None),
    'target_acquisition_control_measures/target_acquisition_control_measures_areas_layer': (lambda : m21.create_target_acquisition_control_measures_areas_layer(), None),
    'target_acquisition_control_measures/range_fans_layer': (lambda : m21.create_range_fans_layer(), None),
    'sustainment_control_measures/sustainment_points_layer': (lambda : m22.create_sustainment_points_layer(), None),
    'supply_points/supply_points_layer': (lambda : m23.create_supply_points_layer(), None),
    'supply_points/supply_routes_lines_layer': (lambda : m23.create_supply_routes_lines_layer(), None),
    'supply_points/sustainment_areas_layer': (lambda : m23.create_sustainment_areas_layer(), None),
    'mission_task_control_measures/mission_task_points_layer': (lambda : m24.create_mission_task_points_layer(), None),
    'mission_task_control_measures/mission_task_lines_layer': (lambda : m24.create_mission_task_lines_layer(), None),
    'intelligence_control_measures/intelligence_control_measures_lines_layer': (lambda : m25.create_intelligence_control_measures_lines_layer(), None),
}

GROUPS = {'create_tactical_graphics_space': ['space_layer/space_layer'], 'create_tactical_graphics_air': ['air_layer/air_layer'], 'create_tactical_graphics_land': ['land_layer/land_unit_layer', 'land_layer/land_civilian_layer', 'land_layer/land_equipment_layer', 'land_layer/land_installation_layer'], 'create_tactical_graphics_sea_surface': ['sea_surface_layer/sea_surface_layer'], 'create_tactical_graphics_subsurface': ['subsurface_layer/subsurface_layer', 'subsurface_layer/mine_warfare_layer'], 'create_tactical_graphics_activities': ['activities_layer/activities_layer'], 'create_tactical_graphics_sigint': ['sigint_layer/sigint_layer'], 'create_tactical_graphics_cyberspace': ['cyberspace_layer/cyberspace_layer'], 'create_c2_measures': ['c2_measures/c2_measures_lines_layer', 'c2_measures/c2_measures_areas_layer', 'c2_measures/c2_measures_points_layer'], 'create_maneuver_control_measures': ['maneuver_control_measures/maneuver_control_measures_lines_layer', 'maneuver_control_measures/maneuver_control_measures_areas_layer'], 'create_defensive_control_measures': ['defensive_control_measures/defensive_control_measures_areas_layer', 'defensive_control_measures/defensive_control_measures_lines_layer', 'defensive_control_measures/defensive_control_measures_points_layer'], 'create_offensive_control_measures': ['offensive_control_measures/offensive_control_measures_lines_layer', 'offensive_control_measures/offensive_control_measures_areas_layer', 'offensive_control_measures/offensive_control_measures_points_layer'], 'create_maneuver_control_measures_2': ['maneuver_control_measures_2/maneuver_control_measures_2_lines_layer', 'maneuver_control_measures_2/maneuver_control_measures_2_areas_layer'], 'create_airspace_control_measures': ['airspace_control_measures/airspace_control_measures_lines_layer', 'airspace_control_measures/airspace_control_measures_areas_layer', 'airspace_control_measures/airspace_control_measures_points_layer'], 'create_maritime_control_measures': ['maritime_control_measures/maritime_control_measures_lines_layer', 'maritime_control_measures/maritime_control_measures_points_layer'], 'create_deception_control_measures': ['deception_control_measures/deception_control_measures_lines_layer'], 'create_fire_support_coordination_measures': ['fire_support_coordination_measures/fire_support_coordination_measures_lines_layer', 'fire_support_coordination_measures/fire_support_coordination_measures_areas_layer'], 'create_target_control_measures': ['target_control_measures/target_control_measures_lines_layer', 'target_control_measures/target_control_measures_areas_layer', 'target_control_measures/target_control_measures_points_layer'], 'create_cbrn_defense': ['cbrn_defense/cbrn_defense_points_layer', 'cbrn_defense/cbrn_contaminated_areas_layer', 'cbrn_defense/safe_distance_zones_layer', 'cbrn_defense/dose_rate_contours_layer'], 'create_field_fortification': ['field_fortification/field_fortification_points_layer', 'field_fortification/field_fortification_lines_layer'], 'create_obstacle_control_measures': ['obstacle_control_measures/obstacle_control_measures_points_layer', 'obstacle_control_measures/obstacle_control_measures_areas_layer', 'obstacle_control_measures/obstacle_control_measures_minefields_layer', 'obstacle_control_measures/obstacle_control_measures_lines_layer'], 'create_target_acquisition_control_measures': ['target_acquisition_control_measures/target_acquisition_control_measures_areas_layer', 'target_acquisition_control_measures/range_fans_layer'], 'create_sustainment_points': ['sustainment_control_measures/sustainment_points_layer'], 'create_supply_points': ['supply_points/supply_points_layer', 'supply_points/supply_routes_lines_layer', 'supply_points/sustainment_areas_layer'], 'create_mission_task_points': ['mission_task_control_measures/mission_task_points_layer', 'mission_task_control_measures/mission_task_lines_layer'], 'create_intelligence_control_measures': ['intelligence_control_measures/intelligence_control_measures_lines_layer']}
