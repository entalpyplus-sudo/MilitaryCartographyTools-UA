"""Organize plugin layers in the QGIS tree without changing their data."""
import json,re
from pathlib import Path
from qgis.core import QgsProject,QgsVectorLayer,QgsLayerTreeGroup
from qgis.PyQt.QtCore import QObject,QTimer
from qgis.PyQt import sip

PATH_PROPERTY='MilitaryCartographyTools/layer_group_path'
GROUP_PROPERTY='MilitaryCartographyTools/category_group'
GROUP_PATHS={
    'space_layer': ['Космічні об’єкти'],
    'air_layer': ['Повітряні об’єкти'],
    'land_layer': ['Наземні об’єкти'],
    'sea_surface_layer': ['Надводні об’єкти'],
    'subsurface_layer': ['Підводні об’єкти'],
    'activities_layer': ['Діяльність'],
    'sigint_layer': ['Радіоелектронна розвідка'],
    'cyberspace_layer': ['Кіберпростір'],
    'c2_measures': ['Заходи управління','Командування та управління'],
    'maneuver_control_measures': ['Заходи управління','Маневр'],
    'maneuver_control_measures_2': ['Заходи управління','Маневр'],
    'defensive_control_measures': ['Заходи управління','Оборона'],
    'offensive_control_measures': ['Заходи управління','Наступ'],
    'airspace_control_measures': ['Заходи управління','Повітряний простір'],
    'maritime_control_measures': ['Заходи управління','Морські заходи'],
    'deception_control_measures': ['Заходи управління','Введення в оману'],
    'fire_support_coordination_measures': ['Заходи управління','Координація вогневої підтримки'],
    'target_control_measures': ['Заходи управління','Цілі'],
    'cbrn_defense': ['Заходи управління','РХБ захист'],
    'field_fortification': ['Заходи управління','Польова фортифікація'],
    'obstacle_control_measures': ['Заходи управління','Загородження'],
    'target_acquisition_control_measures': ['Заходи управління','Розвідка та виявлення цілей'],
    'intelligence_control_measures': ['Заходи управління','Розвідка та виявлення цілей'],
    'sustainment_control_measures': ['Заходи управління','Забезпечення'],
    'supply_points': ['Заходи управління','Забезпечення'],
    'mission_task_control_measures': ['Заходи управління','Тактичні завдання'],
}
catalog_path=Path(__file__).with_name('layer_groups_catalog.json')
CATALOG=json.loads(catalog_path.read_text(encoding='utf-8')) if catalog_path.is_file() else []

def base_name(name):
    name=re.sub(r'^ВКДП\s*—\s*','',name).strip()
    for _ in range(2): name=re.sub(r'\s*\((?:2525[DE]/6[DE]|ВКДП)\)$','',name).strip()
    return name

def _codes(layer,field):
    index=layer.fields().indexFromName(field)
    if index<0: return None
    setup=layer.editorWidgetSetup(index)
    if setup.type()!='ValueMap': return None
    entries=setup.config().get('map',{}); entries=[entries] if isinstance(entries,dict) else entries
    return sorted({'' if code is None else str(code) for entry in entries for code in entry.values()})

def path_for(layer):
    if layer is None: return None
    stored=layer.customProperty(PATH_PROPERTY,'')
    if stored:
        try:
            path=json.loads(stored)
            if isinstance(path,list) and path and all(isinstance(p,str) and p for p in path): return path
        except (TypeError,ValueError): pass
    if layer.customProperty('MilitaryCartographyTools/free_zones',False): return ['Довільні зони']
    if layer.customProperty('MilitaryCartographyTools/user_png_layer',False): return ['Власні знаки (PNG)']
    if layer.customProperty('MilitaryCartographyTools/ukrainian_template',''): return ['Наземні об’єкти']
    slot=str(layer.customProperty('MilitaryCartographyTools/ukrainian_slot','') or '')
    if slot.startswith('presets/'): return ['Наземні об’єкти']
    if slot.split('/')[0] in GROUP_PATHS: return GROUP_PATHS[slot.split('/')[0]]
    legacy=layer.customProperty('MilitaryCartographyTools/vkdp_profile','')
    if legacy in ('lines','areas'): return ['Заходи управління','Лінії та райони']
    if legacy=='points': return ['Універсальні знаки ВКДП']
    if layer.customProperty('mct/sensor_coverage_dem_layer_id',''): return ['Аналіз рельєфу','Покриття сенсорів']
    if not isinstance(layer,QgsVectorLayer) or not layer.isSpatial(): return None
    fields=set(layer.fields().names())
    name=base_name(layer.name())
    for record in CATALOG:
        if base_name(record['name'])==name and set(record['fields'])<=fields: return record['path']
    if not ('affiliation' in fields and ('entity' in fields or 'measure_type' in fields)): return None
    # Older renamed plugin layers can also be recognised by their vocabulary.
    if not layer.customProperty('MilitaryCartographyTools/notation_mode',''):
        renderer=layer.renderer()
        if renderer is None or 'mct_' not in renderer.dump(): return None
    candidates=[]
    for field in ['entity','measure_type']:
        codes=_codes(layer,field)
        if not codes: continue
        for record in CATALOG:
            if record['choice_field']==field and record['codes']==codes and set(record['fields'])<=fields:
                if record['path'] not in candidates: candidates.append(record['path'])
    return candidates[0] if len(candidates)==1 else None

def tag_source(layer,position_callback):
    """Tag terrain/import results where a plain layer name carries no provenance."""
    module=getattr(position_callback,'__module__','')
    if '.terrain.' in module:
        path=['Аналіз рельєфу']
        if 'sensor_coverage' in module: path.append('Покриття сенсорів')
    elif '.waypoints.' in module: path=['Маршрутні точки']
    elif '.grid.' in module: path=['Військові координатні сітки']
    else: path=path_for(layer)
    if path: layer.setCustomProperty(PATH_PROPERTY,json.dumps(path,ensure_ascii=False))

class LayerGroups(QObject):
    def __init__(self,iface,parent):
        super().__init__(parent); self.iface=iface; self.pending=set(); self.active=True
        self.timer=QTimer(self); self.timer.setSingleShot(True); self.timer.setInterval(0); self.timer.timeout.connect(self.flush)

    def schedule(self,layers):
        if not self.active: return
        self.pending.update(layer.id() for layer in layers); self.timer.start()

    def sweep(self,*args):
        self.schedule(list(QgsProject.instance().mapLayers().values()))

    def flush(self):
        self.timer.stop()
        if not self.active: return
        project=QgsProject.instance(); root=project.layerTreeRoot(); pending=self.pending; self.pending=set()
        active=self.iface.activeLayer(); moved=False
        # Read the tree order, rather than signal order, to retain relative order.
        for node in list(root.children()):
            if not hasattr(node,'layerId') or node.layerId() not in pending: continue
            layer=node.layer()
            if layer is None: continue
            path=path_for(layer)
            if not path: continue
            parent=root
            for depth,name in enumerate(path):
                group=next((child for child in parent.children() if isinstance(child,QgsLayerTreeGroup) and child.name()==name),None)
                if group is None:
                    index=root.children().index(node) if parent is root else len(parent.children())
                    group=parent.insertGroup(index,name); group.setCustomProperty(GROUP_PROPERTY,True); group.setExpanded(depth==0)
                parent=group
            layer.setCustomProperty(PATH_PROPERTY,json.dumps(path,ensure_ascii=False))
            # Keep a tree node alive while removing the old one, so the registry
            # bridge never removes the underlying layer or its edit buffer.
            parent.addChildNode(node.clone()); root.removeChildNode(node); moved=True
        if moved:
            project.setDirty(True)
            if active is not None and not sip.isdeleted(active) and project.mapLayer(active.id()) is not None and self.iface.activeLayer() is not active:
                self.iface.setActiveLayer(active)

    def stop(self):
        self.active=False; self.timer.stop(); self.pending.clear()

def install(plugin):
    manager=LayerGroups(plugin.iface,plugin.toolbar); plugin._layer_groups=manager
    project=QgsProject.instance(); project.layersAdded.connect(manager.schedule); project.readProject.connect(manager.sweep)
    manager.sweep(); manager.flush()

def uninstall(plugin):
    manager=getattr(plugin,'_layer_groups',None)
    if manager is None: return
    manager.stop(); project=QgsProject.instance()
    for signal,callback in [(project.layersAdded,manager.schedule),(project.readProject,manager.sweep)]:
        try: signal.disconnect(callback)
        except (TypeError,RuntimeError): pass
    manager.deleteLater(); plugin._layer_groups=None
