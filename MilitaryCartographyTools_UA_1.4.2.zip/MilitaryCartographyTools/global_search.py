"""A shared visual catalogue reachable from menus, forms and the toolbar."""
from types import SimpleNamespace
from qgis.core import QgsProject, QgsVectorLayer, QgsExpression, QgsDefaultValue, QgsApplication, QgsMapLayerStyle
from qgis.gui import QgsEditorWidgetWrapper
from qgis.PyQt.QtCore import QObject, QTimer, QEvent, Qt
from qgis.PyQt.QtGui import QAction, QKeySequence
from qgis.PyQt.QtWidgets import (
    QApplication, QDialog, QVBoxLayout, QHBoxLayout, QComboBox, QPushButton, QLabel, QWidget,
)
from . import menu_preview as mp, notation_preview as preview, ukrainian_catalog as cat
from . import ukrainian_workflow as ua, user_png_symbols as png, free_zones
from .military_symbology.edition import current_edition
from .military_symbology.sidc import build_sidc

ALIASES = {
    'пехота':'піхот', 'пехоты':'піхот', 'артиллерия':'артилер', 'артиллерии':'артилер',
    'танки':'танк', 'танковый':'танк', 'разведка':'розвід', 'разведки':'розвід',
    'снабжение':'постач', 'снабжения':'постач', 'зона':'зон', 'зоны':'зон',
    'районы':'район', 'район':'район', 'штаб':'штаб', 'пункт':'пункт',
}


def codes(layer, field):
    setup = layer.editorWidgetSetup(layer.fields().indexFromName(field))
    maps = setup.config().get('map', [])
    if isinstance(maps, dict): maps = [maps]
    return {(type(v).__name__, str(v)) for row in maps for v in row.values()}


class SearchGallery(mp.Gallery):
    def filter_entries(self, *args):
        # Normalise common Russian query words without changing symbol names.
        text = self.search.text()
        terms = [ALIASES.get(t,t) for t in mp.search_key(text).split()]
        if ' '.join(terms) != mp.search_key(text):
            self.search.blockSignals(True)
            self.search.setText(' '.join(terms))
            super().filter_entries()
            self.search.setText(text)
            self.search.blockSignals(False)
        else:
            super().filter_entries()
        if self.visible_entries:
            self.hint.setText('Оберіть зразок, потім натисніть кнопку вибору внизу. Лінії та площі показано на умовній геометрії.')

    def describe_selection(self):
        super().describe_selection()
        self.owner.dialog.selection_changed()


class SearchDialog(QDialog):
    def __init__(self, manager, parent, form=None):
        super().__init__(parent)
        self.manager, self.form = manager, form
        self.reference_only=isinstance(parent,QDialog) and form is None
        self.setObjectName('mctGlobalSearchDialog')
        self.setWindowTitle('Пошук умовних знаків')
        self.resize(940, 660)
        self.mode, self.standard = manager.plugin._menu_preview.context()
        if form is not None:
            self.mode = preview.layer_mode(form.layer())
            self.standard = '2525E' if '2525E' in form.layer().name() else '2525D'
            if self.mode=='nato':
                style=QgsMapLayerStyle(); style.readFromLayer(form.layer())
                self.standard='2525E' if '2525E' in style.xmlData() else '2525D'
        if self.mode not in ('nato','vkdp'): self.mode='vkdp'
        self.all_entries, self.entry_groups, self.sidcs = [], {}, {}
        self.category = QComboBox(self)
        self.category.setObjectName('mctSearchCategory')
        self.category.addItem('Усі категорії', '')
        self.geometry = QComboBox(self)
        self.geometry.setObjectName('mctSearchGeometry')
        for title, value in [('Усі типи',''),('Точки','point'),('Лінії','line'),('Площі','area'),('Власні PNG','png')]:
            self.geometry.addItem(title,value)
        row=QHBoxLayout(); row.addWidget(self.category,2); row.addWidget(self.geometry,1)
        self.gallery=SearchGallery(SimpleNamespace(menu=self,manager=manager,dialog=self))
        self.gallery.setObjectName('mctGlobalSearchGallery')
        self.gallery.title.setText('Пошук у всьому каталозі')
        self.gallery.search.setPlaceholderText('Назва, абревіатура або код: піхота, танк, ACP, MSR…')
        self.status=QLabel('Завантаження каталогу…',self); self.status.setWordWrap(True)
        self.choose=QPushButton('Обрати знак і шар',self); self.choose.setEnabled(False)
        self.choose.setObjectName('mctSearchChoose'); self.choose.setAutoDefault(False)
        close=QPushButton('Закрити',self); close.setAutoDefault(False); close.clicked.connect(self.close)
        buttons=QHBoxLayout(); buttons.addWidget(self.choose); buttons.addStretch(); buttons.addWidget(close)
        layout=QVBoxLayout(self); layout.addLayout(row); layout.addWidget(self.gallery,1)
        layout.addWidget(self.status); layout.addLayout(buttons)
        self.queue=[g for g in cat.GROUPS if manager.actions[g].isVisible()]+['free_zones','png']
        self.loaded=0; self.kinds={}
        self.index_timer=QTimer(self); self.index_timer.setSingleShot(True); self.index_timer.timeout.connect(self.index_next)
        self.filter_timer=QTimer(self); self.filter_timer.setSingleShot(True); self.filter_timer.setInterval(90)
        self.filter_timer.timeout.connect(self.apply_filters)
        self.category.currentIndexChanged.connect(self.apply_filters)
        self.geometry.currentIndexChanged.connect(self.apply_filters)
        self.choose.clicked.connect(self.use_selection)
        self.gallery.list.itemDoubleClicked.connect(lambda *args:self.use_selection())
        # Codes are searchable as well as the Ukrainian labels.
        self.gallery.entry_search_text=self.search_text
        self.finished.connect(self.stop)

    def showEvent(self,event):
        super().showEvent(event)
        if self.queue: self.index_timer.start(0)
        self.gallery.search.setFocus(); self.gallery.search.selectAll()

    def index_next(self):
        if not self.isVisible() or not self.queue: return
        group=self.queue.pop(0)
        try:
            entries=self.manager.catalogue.entries(group,self.mode,self.standard)
            for entry in entries:
                key=self.manager.catalogue.image_key(entry,self.mode,self.standard)
                self.entry_groups[key]=group
                if entry.slot in cat.BUILDERS and entry.field and entry.value is not None:
                    domain=cat.BUILDERS[entry.slot][1] or 'control_measure'
                    try: self.sidcs[key]=build_sidc('friend',entry.value,domain,edition=self.standard if cat.BUILDERS[entry.slot][1] else '2525D')
                    except (KeyError,TypeError,ValueError): pass
                if entry.slot=='png': kind='png'
                else:
                    layer=self.manager.catalogue.layer(entry.slot,self.mode,self.standard)
                    kind={0:'point',1:'line',2:'area'}.get(int(layer.geometryType()),'')
                self.kinds[entry.slot]=kind
            self.all_entries.extend(entries)
            title=self.manager.titles.get(group,group)
            self.category.addItem(title,group)
        except Exception as error:
            self.manager.errors.append((group,str(error)))
        self.loaded+=1
        self.filter_timer.start()
        if self.queue: self.index_timer.start(8)
        else:
            self.apply_filters()
            self.status.setText('Каталог завантажено. Оберіть зразок. Вибір не створює об’єктів і не зберігає дані автоматично.'
                if not self.manager.errors else 'Частину каталогу не завантажено: '+str(self.manager.errors))

    def search_text(self,entry):
        aliases={'entry_control_point':'КПП', 'infantry_amphibious':'морська піхота морської піхоти морпіх морпех'}
        key=self.manager.catalogue.image_key(entry,self.mode,self.standard)
        return ' '.join((entry.title,entry.layer_title,str(entry.value or ''),self.sidcs.get(key,''),aliases.get(entry.value,'')))

    def apply_filters(self,*args):
        group=self.category.currentData(); kind=self.geometry.currentData()
        self.gallery.entries=[e for e in self.all_entries if
            (not group or self.entry_groups[self.manager.catalogue.image_key(e,self.mode,self.standard)]==group)
            and (not kind or self.kinds[e.slot]==kind)]
        self.gallery.context=(self.mode,self.standard)
        self.gallery.filter_entries()
        self.selection_changed()

    def selected(self):
        row=self.gallery.list.currentRow()
        return self.gallery.visible_entries[row] if 0<=row<len(self.gallery.visible_entries) else None

    def matching(self,layer,entry):
        if not isinstance(layer,QgsVectorLayer): return False
        if entry.slot=='png': return png.is_png_layer(layer)
        if entry.slot=='free_zones': return bool(layer.customProperty(free_zones.FLAG,False))
        if preview.layer_mode(layer)!=self.mode: return False
        slot=layer.customProperty(ua.SLOT,'')
        if slot: return slot==entry.slot
        source=self.manager.catalogue.layer(entry.slot,self.mode,self.standard)
        if layer.fields().names()!=source.fields().names(): return False
        if self.mode=='nato':
            stored=QgsMapLayerStyle(); stored.readFromLayer(layer)
            expected=QgsMapLayerStyle(); expected.readFromLayer(source)
            if ('2525E' in stored.xmlData())!=('2525E' in expected.xmlData()): return False
        return not entry.field or codes(layer,entry.field)==codes(source,entry.field)

    def selection_changed(self):
        entry=self.selected()
        can_use=entry is not None
        if self.reference_only:
            can_use=False
            self.choose.setToolTip('Під час цього діалогу пошук доступний для перегляду. Завершіть діалог, щоб обрати робочий шар.')
        if self.form is not None:
            can_use=can_use and self.form.editable() and self.matching(self.form.layer(),entry) and bool(entry.field or entry.slot=='png')
            self.choose.setText('Підставити тип у поточну форму')
            self.choose.setToolTip('У відкритій формі можна обрати тип лише її шару. Інші категорії доступні для перегляду.')
        self.choose.setEnabled(can_use)

    def use_selection(self):
        self.selection_changed()
        entry=self.selected()
        if entry is None or not self.choose.isEnabled(): return
        if self.form is None and self.manager.plugin._menu_preview.context()!=(self.mode,self.standard):
            self.status.setText('Систему позначень змінено. Відкрийте пошук повторно для поточної системи.'); return
        values={entry.field:entry.value} if entry.field and entry.value is not None else {}
        if entry.group_value is not None: values={'group':entry.group_value,**values}
        if self.form is not None:
            if entry.slot=='png':
                data=png.feature_values(next(e for e in png.CATALOG if e['key']==entry.value))
                values={key:data[key] for key in ('symbol_key','icon_path','symbol_title','category')}
            for key,value in values.items(): self.form.changeAttribute(key,value)
            self.accept(); return
        project=QgsProject.instance()
        layer=next((l for l in project.mapLayers().values() if self.matching(l,entry)),None)
        if layer is None:
            group=self.entry_groups[self.manager.catalogue.image_key(entry,self.mode,self.standard)]
            if group=='png': layer=png.build_layer(); project.addMapLayer(layer)
            elif group=='free_zones': layer=free_zones.add_layer(self.manager.plugin.iface)
            else:
                self.manager.actions[group].trigger()
                layer=next((l for l in project.mapLayers().values() if self.matching(l,entry)),None)
        if layer is None:
            self.status.setText('Не вдалося знайти потрібний шар. Перевірте повідомлення QGIS.'); return
        if entry.slot=='png': png.set_defaults(layer,next(e for e in png.CATALOG if e['key']==entry.value),18)
        for key,value in values.items():
            expression=QgsExpression.quotedValue(value)
            layer.setDefaultValueDefinition(layer.fields().indexFromName(key),QgsDefaultValue(expression))
        self.manager.plugin._layer_groups.flush()
        self.manager.plugin.iface.setActiveLayer(layer)
        self.manager.plugin.iface.messageBar().pushInfo('Пошук знаків','Обрано «'+entry.title+'». Увімкніть редагування та додайте об’єкт звичайним інструментом QGIS.')
        self.accept()

    def stop(self,*args):
        self.index_timer.stop(); self.filter_timer.stop(); self.gallery.timer.stop()

    def closeEvent(self,event):
        self.stop(); super().closeEvent(event)


class SearchManager(QObject):
    def __init__(self,plugin):
        super().__init__(plugin.toolbar)
        self.plugin=plugin; self.catalogue=mp.Catalogue(); self.dialog=None; self.errors=[]; self.buttons=[]; self.forms=[]; self.active=True
        self.actions={original.__name__:action for action,original,dispatch in plugin._png_bindings if original.__name__ in cat.GROUPS}
        self.titles={name:action.text().replace('&','') for name,action in self.actions.items()}
        self.titles.update({'png':'Власні знаки (PNG, додаткові)','free_zones':'Довільні зони'})
        self.action=QAction(QgsApplication.getThemeIcon('/search.svg'),'Пошук знаків…',plugin.toolbar)
        self.action.setObjectName('mctGlobalSearchAction')
        self.action.setShortcut(QKeySequence('Ctrl+Alt+F')); self.action.setShortcutContext(Qt.ShortcutContext.ApplicationShortcut)
        self.action.setToolTip('Пошук у всіх категоріях знаків · Ctrl+Alt+F')
        self.action.triggered.connect(self.open)
        plugin.toolbar.addAction(self.action)
        self.menus=list(plugin.group_menus.values())+[plugin.control_measures_menu]
        for menu in self.menus: menu.insertAction(menu.actions()[0] if menu.actions() else None,self.action)
        for controller in plugin._menu_preview.controllers:
            button=QPushButton('Пошук у всьому каталозі…',controller.panel)
            controller.panel.layout().insertWidget(0,button); button.clicked.connect(self.open); self.buttons.append(button)
        QApplication.instance().installEventFilter(self)
        for widget in QApplication.allWidgets():
            form=preview.as_form(widget)
            if form is not None and form.isVisible(): self.attach(form)

    def open(self,*args):
        modal=QApplication.activeModalWidget()
        if preview.alive(self.dialog) and self.dialog.isVisible() and (modal is None or modal is self.dialog or self.dialog.parentWidget() is modal):
            self.dialog.raise_(); self.dialog.activateWindow(); self.dialog.gallery.search.setFocus(); self.dialog.gallery.search.selectAll(); return
        root=QApplication.activeModalWidget() or QApplication.activeWindow() or self.plugin.iface.mainWindow()
        form=next((preview.as_form(w) for w in root.findChildren(QWidget) if preview.as_form(w) is not None
                   and w.isVisible() and preview.layer_mode(preview.as_form(w).layer()) is not None),None)
        parent=QApplication.activeModalWidget() or self.plugin.iface.mainWindow()
        if self.dialog is not None and preview.alive(self.dialog):
            self.dialog.close(); self.dialog.deleteLater()
        self.errors=[]
        self.dialog=SearchDialog(self,parent,form)
        self.dialog.show(); self.dialog.raise_(); self.dialog.activateWindow()

    def attach(self,form):
        if not self.active or not preview.alive(form) or form.property('mct_search_button'): return
        if preview.layer_mode(form.layer()) is None: return
        panel=form.window().findChild(QWidget,'mctLiveSymbolPreview')
        if panel is None or panel.layout() is None: return
        button=QPushButton('Знайти знак… · Ctrl+Alt+F',panel)
        button.clicked.connect(self.open); panel.layout().insertWidget(0,button)
        form.setProperty('mct_search_button',True); self.buttons.append(button)
        self.forms.append(form)

    def eventFilter(self,obj,event):
        if event.type()==QEvent.Type.Show:
            form=preview.as_form(obj)
            if form is not None: QTimer.singleShot(50,lambda f=form:self.attach(f))
        if event.type() in (QEvent.Type.ShortcutOverride,QEvent.Type.KeyPress):
            modifiers=Qt.KeyboardModifier.ControlModifier|Qt.KeyboardModifier.AltModifier
            if event.key()==Qt.Key.Key_F and event.modifiers()==modifiers:
                event.accept()
                if event.type()==QEvent.Type.KeyPress: self.open()
                return True
        return False

    def stop(self):
        self.active=False
        QApplication.instance().removeEventFilter(self)
        if preview.alive(self.dialog): self.dialog.close(); self.dialog.deleteLater()
        for menu in self.menus: menu.removeAction(self.action)
        self.plugin.toolbar.removeAction(self.action)
        for button in self.buttons:
            if preview.alive(button): button.hide(); button.deleteLater()
        for form in self.forms:
            if preview.alive(form): form.setProperty('mct_search_button',False)
        self.catalogue.clear(); self.action.deleteLater(); self.deleteLater()


def install(plugin): plugin._global_search=SearchManager(plugin)
def uninstall(plugin):
    manager=getattr(plugin,'_global_search',None)
    if preview.alive(manager): manager.stop()
    plugin._global_search=None
