"""General-purpose coloured areas, edited with the ordinary QGIS tools."""
from qgis.core import (
    Qgis,QgsApplication,QgsDefaultValue,QgsEditorWidgetSetup,QgsExpression,
    QgsField,QgsFillSymbol,QgsPalLayerSettings,QgsProject,QgsProperty,
    QgsSingleSymbolRenderer,QgsSymbolLayer,QgsTextBufferSettings,QgsTextFormat,
    QgsVectorLayer,QgsVectorLayerSimpleLabeling,QgsCoordinateReferenceSystem,
)
from qgis.PyQt.QtCore import QMetaType
from qgis.PyQt.QtGui import QAction,QColor,QFont
from .core._layer_utils import add_layer_at_default_position
from .military_symbology._control_measure_shared import default_insert_position
from .field_dependencies import configure as configure_dependencies

FLAG='MilitaryCartographyTools/free_zones'
LAYER_NAME='Довільні зони'
FIELDS=[
    ('name','Назва зони',str,''),
    ('fill_color','Колір заливки',str,'#4f91cf'),
    ('fill_transparency','Прозорість заливки (%)',float,65.0),
    ('outline_enabled','Показувати контур',bool,True),
    ('outline_color','Колір контуру',str,'#335577'),
    ('outline_width_mm','Товщина контуру (мм)',float,0.35),
    ('label','Підпис',str,''),
    ('show_label','Показувати підпис',bool,True),
    ('notes','Примітка',str,''),
]

def build_layer(crs=None,name=LAYER_NAME):
    crs=QgsCoordinateReferenceSystem(crs) if crs is not None else QgsProject.instance().crs()
    if not crs.isValid(): crs=QgsCoordinateReferenceSystem('EPSG:3857')
    layer=QgsVectorLayer('Polygon',name,'memory'); layer.setCrs(crs)
    types={str:QMetaType.Type.QString,float:QMetaType.Type.Double,bool:QMetaType.Type.Bool}
    layer.dataProvider().addAttributes([QgsField(key,types[kind]) for key,_,kind,_ in FIELDS]); layer.updateFields()
    for key,caption,kind,default in FIELDS:
        index=layer.fields().indexFromName(key); layer.setFieldAlias(index,caption)
        expression='true' if default is True else 'false' if default is False else str(default) if kind is float else QgsExpression.quotedString(default)
        layer.setDefaultValueDefinition(index,QgsDefaultValue(expression))
        if kind is bool: layer.setEditorWidgetSetup(index,QgsEditorWidgetSetup('CheckBox',{}))
    for key in ['fill_color','outline_color']:
        layer.setEditorWidgetSetup(layer.fields().indexFromName(key),QgsEditorWidgetSetup('Color',{}))
    for key,minimum,maximum,step,precision in [('fill_transparency',0,100,5,0),('outline_width_mm',0.05,10,0.05,2)]:
        layer.setEditorWidgetSetup(layer.fields().indexFromName(key),QgsEditorWidgetSetup('Range',{
            'Min':minimum,'Max':maximum,'Step':step,'Precision':precision,'Style':'SpinBox',
        }))
    layer.setEditorWidgetSetup(layer.fields().indexFromName('notes'),QgsEditorWidgetSetup('TextEdit',{'IsMultiline':True}))
    symbol=QgsFillSymbol.createSimple({'color':'79,145,207,89','outline_color':'51,85,119,255','outline_width':'0.35','outline_width_unit':'MM'})
    drawing=symbol.symbolLayer(0)
    drawing.setDataDefinedProperty(QgsSymbolLayer.Property.FillColor,QgsProperty.fromExpression(
        "set_color_part(coalesce(\"fill_color\",'#4f91cf'),'alpha',round(255*(100-clamp(0,coalesce(\"fill_transparency\",65),100))/100))"))
    drawing.setDataDefinedProperty(QgsSymbolLayer.Property.StrokeColor,QgsProperty.fromExpression('coalesce("outline_color",\'#335577\')'))
    drawing.setDataDefinedProperty(QgsSymbolLayer.Property.StrokeWidth,QgsProperty.fromExpression('clamp(0.05,coalesce("outline_width_mm",0.35),10)'))
    drawing.setDataDefinedProperty(QgsSymbolLayer.Property.StrokeStyle,QgsProperty.fromExpression("if(coalesce(\"outline_enabled\",true),'solid','no')"))
    layer.setRenderer(QgsSingleSymbolRenderer(symbol))
    settings=QgsPalLayerSettings(); settings.isExpression=True
    settings.fieldName='coalesce(nullif(trim("label"),\'\'),"name",\'\')'
    settings.placement=Qgis.LabelPlacement.Horizontal
    settings.dataDefinedProperties().setProperty(QgsPalLayerSettings.Property.Show,QgsProperty.fromExpression('coalesce("show_label",true)'))
    fmt=QgsTextFormat(); fmt.setFont(QFont('Arial',10)); fmt.setSize(10); fmt.setColor(QColor('black'))
    buffer=QgsTextBufferSettings(); buffer.setEnabled(True); buffer.setSize(0.6); buffer.setColor(QColor('white')); fmt.setBuffer(buffer)
    settings.setFormat(fmt); layer.setLabeling(QgsVectorLayerSimpleLabeling(settings)); layer.setLabelsEnabled(True)
    layer.setCustomProperty(FLAG,True)
    configure_dependencies(layer)
    return layer

def add_layer(iface):
    project=QgsProject.instance()
    existing=project.mapLayersByName(LAYER_NAME)
    if existing:
        iface.messageBar().pushInfo(LAYER_NAME,'Шар «Довільні зони» вже є. Використовуйте його або перейменуйте, щоб створити ще один.')
        return None
    layer=build_layer(iface.mapCanvas().mapSettings().destinationCrs())
    if not layer.isValid(): raise RuntimeError('Не вдалося створити шар довільних зон.')
    add_layer_at_default_position(project,layer,default_insert_position)
    iface.messageBar().pushInfo(LAYER_NAME,'Шар створено. Виберіть його, увімкніть олівець і додайте полігон. Колір, прозорість, контур і підпис задаються у звичайній формі об’єкта.')
    return layer

def prepare_form(form):
    """RGB picker plus one explicit transparency control, without double alpha."""
    from qgis.gui import QgsColorButton
    for button in form.findChildren(QgsColorButton):
        button.setAllowOpacity(False); button.setShowNull(False)

def install(plugin):
    menu=plugin.group_menus['nato_symbols']
    separator=menu.addSeparator()
    action=QAction(QgsApplication.getThemeIcon('/mActionAddPolygon.svg'),'Довільні зони',menu)
    action.setObjectName('mctFreeZonesAction')
    action.setToolTip('Звичайні області з власними кольорами, прозорістю, контуром і підписом')
    def create(checked=False):
        try: add_layer(plugin.iface)
        except Exception as error: plugin.iface.messageBar().pushCritical(LAYER_NAME,str(error))
    action.triggered.connect(create); menu.addAction(action)
    plugin._free_zones_action=action; plugin._free_zones_separator=separator

def uninstall(plugin):
    menu=plugin.group_menus.get('nato_symbols')
    for attribute in ['_free_zones_action','_free_zones_separator']:
        action=getattr(plugin,attribute,None)
        if action is not None:
            if menu is not None: menu.removeAction(action)
            action.deleteLater(); setattr(plugin,attribute,None)
