"""User-supplied PNG cartographic symbols. Original images are never modified."""
import json
import re
from pathlib import Path
from qgis.core import (
    QgsProject,QgsSettings,QgsVectorLayer,QgsField,QgsDefaultValue,QgsExpression,
    QgsProperty,QgsSymbolLayer,QgsRasterMarkerSymbolLayer,QgsMarkerSymbol,
    QgsSingleSymbolRenderer,QgsEditorWidgetSetup,QgsPalLayerSettings,QgsTextFormat,
    QgsVectorLayerSimpleLabeling,QgsLayoutItemPicture,QgsLayoutSize,QgsLayoutPoint,
    QgsVectorFileWriter,QgsMapLayerStyle,Qgis,
)
from qgis.PyQt.QtCore import Qt,QSize,QMetaType
from qgis.PyQt.QtGui import QIcon,QPixmap,QAction,QActionGroup,QFont
from qgis.PyQt.QtWidgets import (
    QDialog,QVBoxLayout,QHBoxLayout,QLabel,QLineEdit,QComboBox,QListWidget,
    QListWidgetItem,QSplitter,QWidget,QPushButton,QDoubleSpinBox,QFormLayout,QToolButton,
)

ROOT=Path(__file__).resolve().parent
ASSETS=ROOT/'user_symbols'
CATALOG=json.loads((ROOT/'user_png_catalog.json').read_text(encoding='utf-8'))['entries']
BY_KEY={item['key']:item for item in CATALOG}
SOURCE_SETTING='MilitaryCartographyTools/symbol_source'
LAYER_FLAG='MilitaryCartographyTools/user_png_layer'
LAYER_NAME='Умовні знаки — мої PNG'

def search_text(text):
    return re.sub(r'[-_/.,:;()]+',' ',text.casefold().replace('’','').replace("'",''))

def search_terms(entry):
    text=entry['title']+' '+entry['key']+' '+entry['category_title']
    for source,keywords in {
        'komandno-sposterezh':'КСП командно-спостережний',
        'komandnyi-punkt':'КП командний пункт',
        '-ombr':'окрема механізована бригада',
        '-tb-':'танковий батальйон',
        '-tr-':'танкова рота',
        '-vzv-':'взвод',
    }.items():
        if source in entry['key']: text+=' '+keywords
    return search_text(text)

def asset_path(key):
    if key not in BY_KEY: return ''
    path=(ASSETS/key).resolve()
    if not path.is_relative_to(ASSETS.resolve()) or not path.is_file(): return ''
    return str(path)

def uses_png():
    return QgsSettings().value(SOURCE_SETTING,'vkdp')=='png'

def build_layer(crs='EPSG:32636',name=LAYER_NAME):
    layer=QgsVectorLayer('Point?crs='+crs,name,'memory')
    fields=[
        ('symbol_key',QMetaType.Type.QString,'Ключ знака'),
        ('icon_path',QMetaType.Type.QString,'Файл зображення'),
        ('symbol_title',QMetaType.Type.QString,'Вибраний знак'),
        ('category',QMetaType.Type.QString,'Категорія'),
        ('designation',QMetaType.Type.QString,'Позначення на карті'),
        ('structure',QMetaType.Type.QString,'Структура / підпорядкування'),
        ('notes',QMetaType.Type.QString,'Примітка'),
        ('size_mm',QMetaType.Type.Double,'Розмір (мм)'),
        ('rotation',QMetaType.Type.Double,'Поворот (°)'),
    ]
    layer.dataProvider().addAttributes([QgsField(key,kind) for key,kind,_ in fields])
    layer.updateFields()
    for index,(_,_,label) in enumerate(fields): layer.setFieldAlias(index,label)
    for key in ['symbol_key','icon_path']:
        layer.setEditorWidgetSetup(layer.fields().indexFromName(key),QgsEditorWidgetSetup('Hidden',{}))
    form=layer.editFormConfig()
    for key in ['symbol_title','category']: form.setReadOnly(layer.fields().indexFromName(key),True)
    layer.setEditFormConfig(form)
    for key,minimum,maximum,suffix in [('size_mm',1,200,' мм'),('rotation',-360,360,'°')]:
        layer.setEditorWidgetSetup(layer.fields().indexFromName(key),QgsEditorWidgetSetup('Range',{
            'Min':minimum,'Max':maximum,'Step':1,'Precision':1,'Style':'SpinBox','Suffix':suffix,
        }))
    raster=QgsRasterMarkerSymbolLayer(asset_path(CATALOG[0]['key']))
    raster.setSize(18)
    raster.setDataDefinedProperty(QgsSymbolLayer.Property.Name,QgsProperty.fromField('icon_path'))
    raster.setDataDefinedProperty(QgsSymbolLayer.Property.Size,QgsProperty.fromExpression('coalesce("size_mm",18)'))
    raster.setDataDefinedProperty(QgsSymbolLayer.Property.Angle,QgsProperty.fromExpression('coalesce("rotation",0)'))
    symbol=QgsMarkerSymbol()
    symbol.changeSymbolLayer(0,raster)
    layer.setRenderer(QgsSingleSymbolRenderer(symbol))
    labels=QgsPalLayerSettings()
    labels.fieldName='designation'
    labels.placement=Qgis.LabelPlacement.OrderedPositionsAroundPoint
    labels.offsetType=Qgis.LabelOffsetType.FromSymbolBounds
    labels.dist=2.0
    text=QgsTextFormat()
    text.setFont(QFont('Arial',9))
    text.setSize(9)
    labels.setFormat(text)
    layer.setLabeling(QgsVectorLayerSimpleLabeling(labels))
    layer.setLabelsEnabled(True)
    layer.setCustomProperty(LAYER_FLAG,True)
    set_defaults(layer,CATALOG[0],18)
    return layer

def persist_layer(layer,path):
    path=Path(path)
    if path.exists(): raise FileExistsError('Файл шару вже існує: '+str(path))
    path.parent.mkdir(parents=True,exist_ok=True)
    options=QgsVectorFileWriter.SaveVectorOptions()
    options.driverName='GPKG'
    options.layerName='game_symbols'
    result=QgsVectorFileWriter.writeAsVectorFormatV3(layer,str(path),QgsProject.instance().transformContext(),options)
    if result[0]!=QgsVectorFileWriter.WriterError.NoError:
        raise RuntimeError('Не вдалося зберегти шар: '+str(result[1]))
    stored=QgsVectorLayer(str(path)+'|layername=game_symbols',LAYER_NAME,'ogr')
    if not stored.isValid(): raise RuntimeError('Не вдалося відкрити збережений шар PNG.')
    style=QgsMapLayerStyle()
    style.readFromLayer(layer)
    style.writeToLayer(stored)
    stored.setCustomProperty(LAYER_FLAG,True)
    stored.saveDefaultStyle()
    return stored

def feature_values(entry,size=18):
    return {'symbol_key':entry['key'],'icon_path':asset_path(entry['key']),
        'symbol_title':entry['title'],'category':entry['category_title'],
        'designation':'','structure':'','notes':'','size_mm':float(size),'rotation':0.0}

def set_defaults(layer,entry,size):
    for key,value in feature_values(entry,size).items():
        expression=str(value) if isinstance(value,(int,float)) else QgsExpression.quotedString(value)
        layer.setDefaultValueDefinition(layer.fields().indexFromName(key),QgsDefaultValue(expression))
    layer.setCustomProperty('MilitaryCartographyTools/last_png_key',entry['key'])

def is_png_layer(layer):
    return layer is not None and bool(layer.customProperty(LAYER_FLAG,False))

def get_layer(iface):
    active=iface.activeLayer() if hasattr(iface,'activeLayer') else None
    if is_png_layer(active): return active
    for layer in QgsProject.instance().mapLayers().values():
        if is_png_layer(layer): return layer
    crs=iface.mapCanvas().mapSettings().destinationCrs().authid() or 'EPSG:32636'
    memory=build_layer(crs)
    home=QgsProject.instance().homePath()
    if home:
        folder=Path(home)/'data'
        path=folder/'game_symbols_png.gpkg'
        if path.exists():
            existing=QgsVectorLayer(str(path)+'|layername=game_symbols',LAYER_NAME,'ogr')
            if existing.isValid() and is_png_layer(existing):
                QgsProject.instance().addMapLayer(existing)
                return existing
            number=2
            while path.exists():
                path=folder/f'game_symbols_png_{number}.gpkg'
                number+=1
    else:
        from qgis.PyQt.QtWidgets import QFileDialog
        chosen,_=QFileDialog.getSaveFileName(iface.mainWindow(),'Зберегти шар умовних знаків','','GeoPackage (*.gpkg)')
        if not chosen: return None
        path=Path(chosen)
    layer=persist_layer(memory,path)
    QgsProject.instance().addMapLayer(layer)
    return layer

def replace_selected(layer,entry,size):
    ids=layer.selectedFeatureIds() if is_png_layer(layer) else []
    if not ids: return 0
    if not layer.isEditable() and not layer.startEditing(): return 0
    # Preserve positions, the user's designation, subordination and notes.
    updates={k:v for k,v in feature_values(entry,size).items() if k in {
        'symbol_key','icon_path','symbol_title','category','size_mm',
    }}
    layer.beginEditCommand('Замінити вибрані умовні знаки')
    for fid in ids:
        for key,value in updates.items():
            if not layer.changeAttributeValue(fid,layer.fields().indexFromName(key),value):
                layer.destroyEditCommand()
                raise RuntimeError('Не вдалося змінити знак; зміни цієї операції скасовано.')
    layer.endEditCommand()
    layer.triggerRepaint()
    return len(ids)

def sync_paths(*args):
    """Repair library paths after moving the installed plugin or opening a project."""
    for layer in QgsProject.instance().mapLayers().values():
        if not is_png_layer(layer): continue
        index=layer.fields().indexFromName('icon_path')
        updates={}
        for feature in layer.getFeatures():
            key=feature['symbol_key']
            path=asset_path(key) if isinstance(key,str) else ''
            if path and feature[index]!=path: updates[feature.id()]={index:path}
        if layer.isEditable():
            for fid,values in updates.items():
                for field,value in values.items(): layer.changeAttributeValue(fid,field,value)
        elif updates:
            layer.dataProvider().changeAttributeValues(updates)
        if updates: layer.triggerRepaint()

class SymbolBrowser(QDialog):
    def __init__(self,iface,parent=None,prefix='',layout_mode=False):
        super().__init__(parent)
        self.iface=iface
        self.choice=None
        self.operation='place'
        self.layout_mode=layout_mode
        self.setWindowTitle('Мої знаки — бібліотека PNG')
        self.resize(1140,760)
        self.search=QLineEdit()
        self.search.setPlaceholderText('Пошук за назвою або іменем файлу…')
        self.categories=QComboBox()
        self.categories.addItem('Усі категорії','')
        for caption,code in [('Сухопутні війська — усі','6-02'),('Повітряні сили — усі','6-03'),
            ('Підтримка — усі','6-07'),('Забезпечення — усі','6-08')]: self.categories.addItem(caption,code)
        for code,title in sorted({x['category']:x['category_title'] for x in CATALOG}.items()):
            self.categories.addItem(title,code)
        initial=self.categories.findData(prefix)
        if initial<0 and prefix:
            initial=next((i for i in range(self.categories.count()) if str(self.categories.itemData(i) or '').startswith(prefix)),-1)
        if initial>=0: self.categories.setCurrentIndex(initial)
        self.items=QListWidget()
        self.items.setIconSize(QSize(108,78))
        self.items.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.items.setTextElideMode(Qt.TextElideMode.ElideRight)
        self.items.setStyleSheet('QListWidget {background: white; color:#18241c;} QListWidget::item {padding:7px;} QListWidget::item:selected {background:#dbeadd;color:#102e17;}')
        self.preview=QLabel('Оберіть знак у списку')
        self.preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview.setMinimumSize(420,340)
        self.preview.setStyleSheet('background:white; border:1px solid #c9d0c9; color:#364636;')
        self.details=QLabel()
        self.details.setWordWrap(True)
        self.details.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.counter=QLabel()
        self.size=QDoubleSpinBox()
        self.size.setRange(1,200)
        self.size.setValue(18)
        self.size.setSuffix(' мм')
        self.size.setDecimals(1)
        right=QWidget()
        right_layout=QVBoxLayout(right)
        right_layout.addWidget(self.preview,1)
        right_layout.addWidget(self.details)
        size_form=QFormLayout()
        size_form.addRow('Розмір на карті / сторінці',self.size)
        right_layout.addLayout(size_form)
        hint=QLabel('Використовується ваше оригінальне зображення з усіма його елементами. Позначення на карті можна додати окремим підписом.')
        hint.setWordWrap(True)
        right_layout.addWidget(hint)
        split=QSplitter()
        split.addWidget(self.items)
        split.addWidget(right)
        split.setSizes([570,520])
        self.place=QPushButton('Вставити в макет' if layout_mode else 'Розмістити на карті')
        self.place.setEnabled(False)
        self.replace=QPushButton('Замінити вибрані об’єкти')
        active=iface.activeLayer() if hasattr(iface,'activeLayer') else None
        self.can_replace=not layout_mode and is_png_layer(active) and active.selectedFeatureCount()>0
        self.replace.setEnabled(self.can_replace)
        self.replace.setToolTip('Заміна зображення у вибраних об’єктах шару «Умовні знаки — мої PNG». Положення та ваші примітки зберігаються.')
        self.replace.setVisible(not layout_mode)
        close=QPushButton('Скасувати')
        bottom=QHBoxLayout()
        bottom.addWidget(self.counter)
        bottom.addStretch()
        bottom.addWidget(self.replace)
        bottom.addWidget(self.place)
        bottom.addWidget(close)
        layout=QVBoxLayout(self)
        layout.addWidget(self.categories)
        layout.addWidget(self.search)
        layout.addWidget(split,1)
        layout.addLayout(bottom)
        self.search.textChanged.connect(self.filter_items)
        self.categories.currentIndexChanged.connect(self.filter_items)
        self.items.currentItemChanged.connect(self.select_item)
        self.items.itemDoubleClicked.connect(lambda item:self.accept_choice('place'))
        self.place.clicked.connect(lambda:self.accept_choice('place'))
        self.replace.clicked.connect(lambda:self.accept_choice('replace'))
        close.clicked.connect(self.reject)
        self.filter_items()

    def filter_items(self,*args):
        self.items.clear()
        prefix=self.categories.currentData() or ''
        words=search_text(self.search.text()).split()
        for entry in CATALOG:
            haystack=search_terms(entry)
            if prefix and not entry['category'].startswith(prefix): continue
            if not all(word in haystack for word in words): continue
            item=QListWidgetItem(QIcon(asset_path(entry['key'])),entry['title'])
            item.setData(Qt.ItemDataRole.UserRole,entry['key'])
            item.setToolTip(entry['category_title']+'\n'+entry['filename'])
            self.items.addItem(item)
        self.counter.setText(f'Показано {self.items.count()} із {len(CATALOG)} знаків')
        if self.items.count(): self.items.setCurrentRow(0)
        else:
            self.choice=None
            self.place.setEnabled(False)
            self.replace.setEnabled(False)
            self.preview.clear()
            self.details.setText('За цим запитом знаків немає. Змініть пошук або категорію.')

    def select_item(self,item,*args):
        if item is None: return
        self.choice=BY_KEY[item.data(Qt.ItemDataRole.UserRole)]
        pixmap=QPixmap(asset_path(self.choice['key']))
        self.preview.setPixmap(pixmap.scaled(QSize(480,410),Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation))
        self.details.setText(self.choice['title']+'\n'+self.choice['category_title']+'\n'+self.choice['filename']+f"\n{self.choice['width']} × {self.choice['height']} пікселів")
        self.place.setEnabled(True)
        self.replace.setEnabled(self.can_replace)

    def accept_choice(self,operation):
        if not self.choice: return
        self.operation=operation
        self.accept()

def show_browser(iface,prefix=''):
    dialog=SymbolBrowser(iface,iface.mainWindow(),prefix)
    if dialog.exec()!=QDialog.DialogCode.Accepted: return None
    if dialog.operation=='replace':
        count=replace_selected(iface.activeLayer(),dialog.choice,dialog.size.value())
        iface.messageBar().pushInfo('Мої знаки',f'Замінено знаків: {count}. Збережіть зміни шару.')
        return iface.activeLayer()
    layer=get_layer(iface)
    if layer is None: return None
    set_defaults(layer,dialog.choice,dialog.size.value())
    if not layer.isEditable() and not layer.startEditing():
        iface.messageBar().pushWarning('Мої знаки','Не вдалося увімкнути редагування шару.')
        return None
    iface.setActiveLayer(layer)
    iface.actionAddFeature().trigger()
    iface.messageBar().pushInfo('Мої знаки','Клацніть на карті, щоб розмістити вибраний PNG. Після розміщення збережіть зміни шару та проєкт.')
    return layer

def add_layout_picture(layout,entry,width=20):
    picture=QgsLayoutItemPicture(layout)
    picture.setPicturePath(asset_path(entry['key']))
    picture.setResizeMode(QgsLayoutItemPicture.ResizeMode.ZoomResizeFrame)
    layout.addLayoutItem(picture)
    picture.attemptResize(QgsLayoutSize(width,width*entry['height']/entry['width']))
    picture.attemptMove(QgsLayoutPoint(10,10))
    picture.setId(entry['title'])
    picture.refreshPicture()
    return picture

def install(plugin):
    menu=plugin.group_menus['nato_symbols']
    menu.setTitle('Умовні знаки')
    for button in plugin.toolbar.findChildren(QToolButton):
        if button.menu() is menu:
            button.setText('Умовні знаки')
            button.setToolTip('Ваші PNG або стандартні знаки НАТО')
    quick=QAction(QIcon(asset_path(CATALOG[0]['key'])),'Мої знаки (PNG)',plugin.toolbar)
    quick.setToolTip(f'Ваша бібліотека: {len(CATALOG)} знаків із папки Symbols')
    quick.triggered.connect(lambda checked=False:show_browser(plugin.iface))
    plugin.toolbar.addAction(quick)
    first=menu.actions()[0]
    menu.insertAction(first,quick)
    from qgis.PyQt.QtWidgets import QMenu
    source=QMenu('Джерело нових знаків',menu)
    group=QActionGroup(source)
    group.setExclusive(True)
    for text,value in [('Мої PNG — умовні знаки','png'),('Стандартні знаки НАТО','nato')]:
        action=source.addAction(text)
        action.setCheckable(True)
        action.setChecked(uses_png()==(value=='png'))
        group.addAction(action)
        action.triggered.connect(lambda checked=False,v=value:QgsSettings().setValue(SOURCE_SETTING,v))
    menu.insertMenu(first,source)
    bindings=[]
    mapping=[
        ('tactical_graphics_space_action','create_tactical_graphics_space','6-13'),
        ('tactical_graphics_air_action','create_tactical_graphics_air','6-03'),
        ('tactical_graphics_land_action','create_tactical_graphics_land','6-02'),
        ('tactical_graphics_sea_surface_action','create_tactical_graphics_sea_surface','6-04'),
        ('tactical_graphics_subsurface_action','create_tactical_graphics_subsurface','6-04'),
        ('tactical_graphics_activities_action','create_tactical_graphics_activities','6-12'),
        ('tactical_graphics_sigint_action','create_tactical_graphics_sigint','6-07-02'),
        ('tactical_graphics_cyberspace_action','create_tactical_graphics_cyberspace',''),
        ('c2_measures_action','create_c2_measures','6-01'),
        ('maneuver_control_measures_action','create_maneuver_control_measures','6-02-01'),
        ('defensive_control_measures_action','create_defensive_control_measures','6-02-01'),
        ('offensive_control_measures_action','create_offensive_control_measures','6-02-01'),
        ('maneuver_control_measures_2_action','create_maneuver_control_measures_2','6-02-01'),
        ('airspace_control_measures_action','create_airspace_control_measures','6-03'),
        ('maritime_control_measures_action','create_maritime_control_measures','6-04'),
        ('deception_control_measures_action','create_deception_control_measures','6-02-01'),
        ('fire_support_coordination_measures_action','create_fire_support_coordination_measures','6-02-02'),
        ('target_control_measures_action','create_target_control_measures','6-02-02'),
        ('obstacle_control_measures_action','create_obstacle_control_measures','6-07-01'),
        ('field_fortification_action','create_field_fortification','6-07-01'),
        ('cbrn_defense_action','create_cbrn_defense','6-07-03'),
        ('target_acquisition_control_measures_action','create_target_acquisition_control_measures','6-02-02'),
        ('sustainment_points_action','create_sustainment_points','6-08'),
        ('supply_points_action','create_supply_points','6-08-03'),
        ('mission_task_points_action','create_mission_task_points','6-02-01'),
        ('intelligence_control_measures_action','create_intelligence_control_measures','6-02-03'),
    ]
    for attr,method,prefix in mapping:
        action=getattr(plugin,attr,None)
        original=getattr(plugin,method,None)
        if action is None or original is None: continue
        action.triggered.disconnect()
        def dispatch(checked=False,callback=original,category=prefix):
            return show_browser(plugin.iface,category) if uses_png() else callback()
        action.triggered.connect(dispatch)
        bindings.append((action,original,dispatch))
    plugin._png_bindings=bindings
    for action in menu.actions():
        if action.text()=='Українські підрозділи та служби…':
            from .ukrainian_presets import UkrainianUnitsDialog
            def original_uk():
                dialog=UkrainianUnitsDialog(plugin.iface,plugin.iface.mainWindow())
                if dialog.exec()==QDialog.DialogCode.Accepted: return dialog.create_layer()
            def dispatch_uk(checked=False):
                return show_browser(plugin.iface) if uses_png() else original_uk()
            action.triggered.disconnect()
            action.triggered.connect(dispatch_uk)
            bindings.append((action,original_uk,dispatch_uk))
    plugin._png_original_insert=plugin._insert_symbol
    def insert_picture(designer):
        if not uses_png(): return plugin._png_original_insert(designer)
        dialog=SymbolBrowser(plugin.iface,designer.window(),layout_mode=True)
        if designer.layout() is not None and dialog.exec()==QDialog.DialogCode.Accepted:
            return add_layout_picture(designer.layout(),dialog.choice,dialog.size.value())
    plugin._insert_symbol=insert_picture
    plugin._png_project_callback=sync_paths
    QgsProject.instance().readProject.connect(plugin._png_project_callback)
    sync_paths()

def uninstall(plugin):
    callback=getattr(plugin,'_png_project_callback',None)
    if callback:
        try: QgsProject.instance().readProject.disconnect(callback)
        except (TypeError,RuntimeError): pass
    for action,original,dispatch in getattr(plugin,'_png_bindings',[]):
        try:
            action.triggered.disconnect(dispatch)
            action.triggered.connect(original)
        except (TypeError,RuntimeError): pass
    plugin._png_bindings=[]
    if hasattr(plugin,'_png_original_insert'): plugin._insert_symbol=plugin._png_original_insert
