"""Ukrainian display labels. Stored field names and SIDC values remain unchanged."""
import json
import re
from pathlib import Path

_TEXT = json.loads((Path(__file__).parent / 'translations_uk.json').read_text(encoding='utf-8'))
_CASEFOLD = {key.casefold(): value for key,value in _TEXT.items()}

def tr(text):
    result=_TEXT.get(text, _CASEFOLD.get(text.casefold(), text))
    if result!=text: return result
    m=re.fullmatch(r'(.+?)( \(2525[DE]/6[DE]\))',text)
    if m: return tr(m[1])+m[2]
    m=re.fullmatch(r'MGRS (\d+)km Grid',text)
    if m: return f'MGRS {m[1]} км'
    for prefix in ['Sensor Points - ','Sensor Coverage - ']:
        if text.startswith(prefix): return tr(prefix)+tr(text[len(prefix):])
    return text

FIELD_ALIASES = {
    'affiliation': 'Належність',
    'entity': 'Тип об’єкта',
    'echelon': 'Організаційний рівень',
    'status': 'Стан',
    'headquarters': 'Штаб',
    'sector1_modifier': 'Модифікатор сектора 1',
    'sector2_modifier': 'Модифікатор сектора 2',
    'unique_designation': 'Унікальне позначення',
    'rotation': 'Поворот (°)',
    'scale': 'Масштаб (%)',
    'dimension': 'Середовище',
    'measure_type': 'Тип заходу управління',
    'group': 'Група',
    'colour': 'Колір',
    'color': 'Колір',
    'label': 'Підпис',
    'name': 'Назва',
    'description': 'Опис',
    'dtg_start': 'Дата й час початку',
    'dtg_end': 'Дата й час завершення',
    'additional_information': 'Додаткова інформація',
    'higher_formation': 'Вище формування',
    'altitude_depth': 'Висота / глибина',
    'altitude': 'Висота',
    'depth': 'Глибина',
    'speed': 'Швидкість',
    'quantity': 'Кількість',
    'staff_comments': 'Примітки штабу',
    'evaluation_rating': 'Оцінка достовірності',
    'combat_effectiveness': 'Боєздатність',
    'signature_equipment': 'Характерне обладнання',
    'hostile': 'Противник',
    'iff_sif': 'Розпізнавання «свій — чужий»',
    'direction_of_movement': 'Напрямок руху',
    'location': 'Місцеположення',
    'mine_type': 'Тип міни',
    'scatterable': 'Дистанційне встановлення',
    'self_destruct': 'Час самоліквідації',
    'sensor_height_m': 'Висота сенсора (м)',
    'max_range_m': 'Максимальна дальність (м)',
    'detection_height_m': 'Висота виявлення (м)',
    'latitude': 'Широта',
    'longitude': 'Довгота',
    'mgrs': 'Координати MGRS',
    'ELEV': 'Висота',
    'LENGTH': 'Довжина',
    'DIST': 'Відстань',
    'TERRAIN_ELEV': 'Висота рельєфу',
    'VISIBLE': 'Видимість',
    'sensor_height': 'Висота сенсора (м)',
    'detection_height': 'Висота виявлення (м)',
    'max_distance': 'Максимальна дальність (м)',
    'area_km2': 'Площа (км²)',
    'length_km': 'Довжина (км)',
    'perimeter_km': 'Периметр (км)',
    'equipment_type': 'Тип техніки',
    'far_designation': 'Позначення суміжного підрозділу',
    'mine_indicator': 'Ознака дистанційного мінування',
    'prepared': 'Підготовлена позиція',
    'self_destruct_dtg': 'Дата й час самоліквідації',
}

def localize_layer(layer):
    if not hasattr(layer, 'setFieldAlias'):
        return
    for index, field in enumerate(layer.fields()):
        alias=layer.attributeAlias(index)
        if alias and tr(alias)!=alias:
            layer.setFieldAlias(index,tr(alias))
        elif not alias and field.name() in FIELD_ALIASES:
            layer.setFieldAlias(index,FIELD_ALIASES[field.name()])
        elif not alias:
            m=re.fullmatch(r'(?:ring_?|r)(\d+)_?(left|right|range|alt)',field.name())
            if m:
                caption={'left':'лівий азимут (°)','right':'правий азимут (°)','range':'дальність (м)','alt':'висота / глибина'}[m[2]]
                layer.setFieldAlias(index,f'Кільце {m[1]}: {caption}')
        widget=layer.editorWidgetSetup(index)
        if widget.type()=='ValueMap':
            from qgis.core import QgsEditorWidgetSetup
            config=widget.config()
            mapping=config.get('map',{})
            def translate_map(items):
                out={}
                for label,value in items.items():
                    caption=tr(label) if isinstance(label,str) else label
                    if caption in out and out[caption]!=value: caption+=' ('+label+')'
                    out[caption]=value
                return out
            translated=translate_map(mapping) if isinstance(mapping,dict) else [translate_map(x) for x in mapping]
            if translated!=mapping:
                config['map']=translated
                layer.setEditorWidgetSetup(index,QgsEditorWidgetSetup('ValueMap',config))

def localize_existing_layers(*args):
    """Translate presentation on already-loaded plugin layers without changing codes."""
    from qgis.core import QgsProject,QgsEditorWidgetSetup
    project=QgsProject.instance()
    for group in project.layerTreeRoot().findGroups():
        if group.name() in ('Military Grids','MGRS Sub Grid'): group.setName(tr(group.name()))
    for layer in project.mapLayers().values():
        if not hasattr(layer,'fields'): continue
        names={f.name() for f in layer.fields()}
        is_plugin=('affiliation' in names and 'unique_designation' in names and bool({'entity','measure_type'} & names))
        if not is_plugin:
            if layer.name() in ('UTM Grid','MGRS 100km Grid') or re.fullmatch(r'MGRS \d+km Grid',layer.name()):
                layer.setName(tr(layer.name()))
            continue
        name=tr(layer.name())
        if name!=layer.name(): layer.setName(name)
        localize_layer(layer)
        for index in range(len(layer.fields())):
            widget=layer.editorWidgetSetup(index)
            config=widget.config()
            if widget.type()=='ValueMap':
                mapping=config.get('map',{})
                def translated_map(items):
                    out={}
                    for label,value in items.items():
                        label_uk=tr(label)
                        # Preserve every option even in older custom layers with synonyms.
                        if label_uk in out and out[label_uk]!=value:
                            label_uk+=' ('+label+')'
                        out[label_uk]=value
                    return out
                translated=translated_map(mapping) if isinstance(mapping,dict) else [translated_map(x) for x in mapping]
                if translated!=mapping:
                    config['map']=translated
                    layer.setEditorWidgetSetup(index,QgsEditorWidgetSetup('ValueMap',config))
            elif widget.type()=='ValueRelation':
                lookup=project.mapLayer(config.get('Layer',''))
                if lookup is None or tr(lookup.name())==lookup.name(): continue
                display=lookup.fields().indexFromName(config.get('Value',''))
                if display<0: continue
                updates={}
                for feature in lookup.getFeatures():
                    value=feature[display]
                    if isinstance(value,str) and tr(value)!=value:
                        updates[feature.id()]={display:tr(value)}
                if updates: lookup.dataProvider().changeAttributeValues(updates)
                lookup.setName(tr(lookup.name()))

def entity_display_label(key,symbol_set,edition):
    """Use the actual translated vocabulary, rather than title-casing an internal key."""
    from .military_symbology import land_layer,subsurface_layer
    from .military_symbology import air_layer,space_layer,activities_layer,sea_surface_layer,cyberspace_layer,sigint_layer
    from .military_symbology.sidc_2525e import ENTITY_LABELS_2525E
    if symbol_set=='control_measure':
        import importlib
        global _CONTROL_LABELS
        if '_CONTROL_LABELS' not in globals():
            _CONTROL_LABELS={}
            for name in ['c2_measures','defensive_control_measures','offensive_control_measures',
                'airspace_control_measures','maritime_control_measures','obstacle_control_measures',
                'field_fortification','cbrn_defense','sustainment_control_measures','supply_points',
                'mission_task_control_measures','target_control_measures']:
                module=importlib.import_module('.military_symbology.'+name,__package__)
                _CONTROL_LABELS.update(module.POINT_ENTITY_LABELS)
        if key=='tacan': return 'Радіонавігаційний пункт TACAN'
        return _CONTROL_LABELS.get(key,tr(key.replace('_',' ').title()))
    if edition=='2525E' and key in ENTITY_LABELS_2525E.get(symbol_set,{}):
        return ENTITY_LABELS_2525E[symbol_set][key]
    dictionaries={
        'ground_unit':land_layer._UNIT_ENTITY_LABELS,
        'land_civilian':land_layer._CIVILIAN_ENTITY_LABELS,
        'land_equipment':land_layer._EQUIPMENT_ENTITY_LABELS,
        'land_installation':land_layer._INSTALLATION_ENTITY_LABELS,
        'subsurface':subsurface_layer._SUBSURFACE_ENTITY_LABELS,
        'mine_warfare':subsurface_layer._MINE_WARFARE_ENTITY_LABELS,
        'air':air_layer._ENTITY_LABELS,'air_missile':air_layer._ENTITY_LABELS,
        'space':space_layer._ENTITY_LABELS,'space_missile':space_layer._ENTITY_LABELS,
        'activities':activities_layer._ENTITY_LABELS,
        'sea_surface':sea_surface_layer._ENTITY_LABELS,
        'cyberspace':cyberspace_layer._ENTITY_LABELS,
    }
    if symbol_set.startswith('sigint'): return sigint_layer._ENTITY_LABELS.get(key,tr(key.replace('_',' ').title()))
    return dictionaries.get(symbol_set,{}).get(key,tr(key.replace('_',' ').title()))
